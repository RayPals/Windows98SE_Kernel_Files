/*
 * Windows 95 Reconstruction - Common Types and Macros
 * 
 * This header provides the CPU register model, memory access macros,
 * flag manipulation, and interrupt/system call wrappers used by all
 * reconstructed modules.
 *
 * AUTO-GENERATED support header for Windows 95 assembly-to-C conversion.
 */

#ifndef W95TYPES_H
#define W95TYPES_H

#include <stdint.h>
#include <stddef.h>
#include <string.h>

/* ============================================================================
 * BASIC TYPES
 * ============================================================================ */

typedef uint8_t   BYTE;
typedef uint16_t  WORD;
typedef uint32_t  DWORD;
typedef int8_t    SBYTE;
typedef int16_t   SWORD;
typedef int32_t   SDWORD;
typedef void     *LPVOID;
typedef uint16_t  SELECTOR;
typedef uint32_t  FLAT_ADDR;

/* ============================================================================
 * CPU REGISTER MODEL
 * Supports both 16-bit and 32-bit register access via unions.
 * ============================================================================ */

typedef struct CPU_REGS {
    /* General purpose registers (32-bit with 16/8-bit sub-access) */
    union {
        uint32_t eax;
        struct { union { struct { uint8_t al; uint8_t ah; }; uint16_t ax; }; };
    };
    union {
        uint32_t ebx;
        struct { union { struct { uint8_t bl; uint8_t bh; }; uint16_t bx; }; };
    };
    union {
        uint32_t ecx;
        struct { union { struct { uint8_t cl; uint8_t ch; }; uint16_t cx; }; };
    };
    union {
        uint32_t edx;
        struct { union { struct { uint8_t dl; uint8_t dh; }; uint16_t dx; }; };
    };

    /* Index registers */
    union { uint32_t esi; uint16_t si; };
    union { uint32_t edi; uint16_t di; };

    /* Stack registers */
    union { uint32_t ebp; uint16_t bp; };
    union { uint32_t esp; uint16_t sp; };

    /* Segment registers */
    uint16_t cs;
    uint16_t ds;
    uint16_t es;
    uint16_t ss;
    uint16_t fs;
    uint16_t gs;

    /* Flags */
    uint32_t flags;
    
    /* Instruction pointer */
    uint32_t eip;
} CPU_REGS;

/* ============================================================================
 * FLAGS
 * ============================================================================ */

#define FLAG_CF    0x0001   /* Carry Flag */
#define FLAG_PF    0x0004   /* Parity Flag */
#define FLAG_AF    0x0010   /* Auxiliary Carry Flag */
#define FLAG_ZF    0x0040   /* Zero Flag */
#define FLAG_SF    0x0080   /* Sign Flag */
#define FLAG_TF    0x0100   /* Trap Flag */
#define FLAG_IF    0x0200   /* Interrupt Enable Flag */
#define FLAG_DF    0x0400   /* Direction Flag */
#define FLAG_OF    0x0800   /* Overflow Flag */

/* Flag access macros using local CPU state */
#define CF         ((regs->flags >> 0) & 1)
#define PF         ((regs->flags >> 2) & 1)
#define AF         ((regs->flags >> 4) & 1)
#define ZF         ((regs->flags >> 6) & 1)
#define SF         ((regs->flags >> 7) & 1)
#define IF_FLAG    ((regs->flags >> 9) & 1)
#define DF         ((regs->flags >> 10) & 1)
#define OF         ((regs->flags >> 11) & 1)

#define SET_CF(v)  do { regs->flags = (regs->flags & ~FLAG_CF) | ((v) ? FLAG_CF : 0); } while(0)
#define SET_ZF(v)  do { regs->flags = (regs->flags & ~FLAG_ZF) | ((v) ? FLAG_ZF : 0); } while(0)
#define SET_SF(v)  do { regs->flags = (regs->flags & ~FLAG_SF) | ((v) ? FLAG_SF : 0); } while(0)
#define SET_OF(v)  do { regs->flags = (regs->flags & ~FLAG_OF) | ((v) ? FLAG_OF : 0); } while(0)
#define SET_PF(v)  do { regs->flags = (regs->flags & ~FLAG_PF) | ((v) ? FLAG_PF : 0); } while(0)

/* Bulk flag updates */
#define UPDATE_FLAGS_ADD()     /* flags set by ALU op */
#define UPDATE_FLAGS_ADC()     /* flags set by ALU op */
#define UPDATE_FLAGS_SUB()     /* flags set by ALU op */
#define UPDATE_FLAGS_SBB()     /* flags set by ALU op */
#define UPDATE_FLAGS_INC()     /* flags set except CF */
#define UPDATE_FLAGS_DEC()     /* flags set except CF */
#define UPDATE_FLAGS_NEG()     /* flags set by negate */
#define UPDATE_FLAGS_LOGIC()   /* CF=0, OF=0, update ZF/SF/PF */

/* ============================================================================
 * MEMORY MODEL
 * Flat memory with segment emulation.
 * ============================================================================ */

extern uint8_t g_memory[];  /* Flat memory space */
#define MEMORY_SIZE  (16 * 1024 * 1024)  /* 16MB flat address space */

/* Segment to linear address */
#define SEGMENT(seg)           ((uint32_t)(seg) << 4)
#define FLAT(seg, off)         (SEGMENT(seg) + (uint32_t)(off))

/* Memory access macros */
#define MEM                    g_memory
#define MEM_BYTE(addr)         (*(uint8_t  *)&g_memory[(uint32_t)(addr)])
#define MEM_WORD(addr)         (*(uint16_t *)&g_memory[(uint32_t)(addr)])
#define MEM_DWORD(addr)        (*(uint32_t *)&g_memory[(uint32_t)(addr)])

/* ============================================================================
 * STACK OPERATIONS
 * ============================================================================ */

#define PUSH(val) do { \
    regs->sp -= 2; \
    MEM_WORD(FLAT(regs->ss, regs->sp)) = (uint16_t)(val); \
} while(0)

#define PUSH32(val) do { \
    regs->esp -= 4; \
    MEM_DWORD(FLAT(regs->ss, regs->esp)) = (uint32_t)(val); \
} while(0)

#define POP() ( \
    regs->sp += 2, \
    MEM_WORD(FLAT(regs->ss, regs->sp - 2)) \
)

#define POP32() ( \
    regs->esp += 4, \
    MEM_DWORD(FLAT(regs->ss, regs->esp - 4)) \
)

static inline void PUSH_ALL(CPU_REGS *regs) {
    uint16_t tmp_sp = regs->sp;
    PUSH(regs->ax); PUSH(regs->cx); PUSH(regs->dx); PUSH(regs->bx);
    PUSH(tmp_sp);   PUSH(regs->bp); PUSH(regs->si); PUSH(regs->di);
}

static inline void POP_ALL(CPU_REGS *regs) {
    regs->di = POP(); regs->si = POP(); regs->bp = POP();
    POP(); /* skip SP */
    regs->bx = POP(); regs->dx = POP(); regs->cx = POP(); regs->ax = POP();
}

#define STACK_ADJUST(n) do { regs->sp += (uint16_t)(n); } while(0)

#define ENTER_FRAME(size, level) do { \
    PUSH(regs->bp); \
    regs->bp = regs->sp; \
    regs->sp -= (uint16_t)(size); \
} while(0)

#define LEAVE_FRAME() do { \
    regs->sp = regs->bp; \
    regs->bp = POP(); \
} while(0)

/* ============================================================================
 * COMPARISON & TEST
 * ============================================================================ */

#define CMP(a, b) do { \
    uint32_t _a = (uint32_t)(a), _b = (uint32_t)(b); \
    uint32_t _r = _a - _b; \
    SET_CF(_a < _b); \
    SET_ZF((_r & 0xFFFF) == 0); \
    SET_SF((_r >> 15) & 1); \
    SET_OF(((_a ^ _b) & (_a ^ _r)) >> 15 & 1); \
} while(0)

#define TEST(a, b) do { \
    uint32_t _r = (uint32_t)(a) & (uint32_t)(b); \
    SET_CF(0); \
    SET_OF(0); \
    SET_ZF(_r == 0); \
    SET_SF((_r >> 15) & 1); \
} while(0)

/* ============================================================================
 * EXCHANGE
 * ============================================================================ */

#define XCHG(a, b) do { \
    typeof(a) _tmp = (a); \
    (a) = (b); \
    (b) = _tmp; \
} while(0)

/* ============================================================================
 * FAR POINTER LOADING
 * ============================================================================ */

#define LOAD_FAR_PTR(seg_p, off_p, mem_addr) do { \
    *(off_p) = MEM_WORD(mem_addr); \
    *(seg_p) = MEM_WORD((mem_addr) + 2); \
} while(0)

/* ============================================================================
 * ROTATE OPERATIONS
 * ============================================================================ */

#define ROL(val, count) do { (val) = ((val) << (count)) | ((val) >> (sizeof(val)*8 - (count))); } while(0)
#define ROR(val, count) do { (val) = ((val) >> (count)) | ((val) << (sizeof(val)*8 - (count))); } while(0)
#define RCL(val, count) /* rotate through carry left */
#define RCR(val, count) /* rotate through carry right */

/* ============================================================================
 * BIT OPERATIONS
 * ============================================================================ */

static inline int BSF(uint32_t val) {
    for (int i = 0; i < 32; i++) if (val & (1u << i)) return i;
    return -1;
}

static inline int BSR(uint32_t val) {
    for (int i = 31; i >= 0; i--) if (val & (1u << i)) return i;
    return -1;
}

static inline uint32_t BSWAP(uint32_t val) {
    return ((val >> 24) & 0xFF) | ((val >> 8) & 0xFF00) |
           ((val << 8) & 0xFF0000) | ((val << 24) & 0xFF000000);
}

/* ============================================================================
 * STRING OPERATIONS
 * ============================================================================ */

#define STRING_MOVE_BYTE(r) do { \
    MEM_BYTE(FLAT(r->es, r->di)) = MEM_BYTE(FLAT(r->ds, r->si)); \
    r->si += DF ? -1 : 1; r->di += DF ? -1 : 1; \
} while(0)

#define STRING_MOVE_WORD(r) do { \
    MEM_WORD(FLAT(r->es, r->di)) = MEM_WORD(FLAT(r->ds, r->si)); \
    r->si += DF ? -2 : 2; r->di += DF ? -2 : 2; \
} while(0)

#define STRING_MOVE_DWORD(r) do { \
    MEM_DWORD(FLAT(r->es, r->di)) = MEM_DWORD(FLAT(r->ds, r->si)); \
    r->si += DF ? -4 : 4; r->di += DF ? -4 : 4; \
} while(0)

#define STRING_STORE_BYTE(r) do { \
    MEM_BYTE(FLAT(r->es, r->di)) = r->al; \
    r->di += DF ? -1 : 1; \
} while(0)

#define STRING_STORE_WORD(r) do { \
    MEM_WORD(FLAT(r->es, r->di)) = r->ax; \
    r->di += DF ? -2 : 2; \
} while(0)

#define STRING_STORE_DWORD(r) do { \
    MEM_DWORD(FLAT(r->es, r->di)) = r->eax; \
    r->di += DF ? -4 : 4; \
} while(0)

#define STRING_LOAD_BYTE(r) do { \
    r->al = MEM_BYTE(FLAT(r->ds, r->si)); \
    r->si += DF ? -1 : 1; \
} while(0)

#define STRING_LOAD_WORD(r) do { \
    r->ax = MEM_WORD(FLAT(r->ds, r->si)); \
    r->si += DF ? -2 : 2; \
} while(0)

#define STRING_LOAD_DWORD(r) do { \
    r->eax = MEM_DWORD(FLAT(r->ds, r->si)); \
    r->si += DF ? -4 : 4; \
} while(0)

#define STRING_CMP_BYTE(r)   /* cmpsb: compare DS:[SI] with ES:[DI] */
#define STRING_CMP_WORD(r)   /* cmpsw */
#define STRING_CMP_DWORD(r)  /* cmpsd */
#define STRING_SCAN_BYTE(r)  /* scasb: compare AL with ES:[DI] */
#define STRING_SCAN_WORD(r)  /* scasw */
#define STRING_SCAN_DWORD(r) /* scasd */

/* ============================================================================
 * I/O PORT ACCESS
 * ============================================================================ */

static inline uint8_t PORT_IN(uint16_t port) {
    /* Hardware port read - platform specific */
    (void)port;
    return 0;
}

static inline void PORT_OUT(uint16_t port, uint8_t val) {
    /* Hardware port write - platform specific */
    (void)port; (void)val;
}

static inline void PORT_OUTPUT_STRING_BYTE(CPU_REGS *regs) { (void)regs; }
static inline void PORT_INPUT_STRING_BYTE(CPU_REGS *regs) { (void)regs; }

/* ============================================================================
 * MULTIPLY / DIVIDE
 * ============================================================================ */

#define MUL_UNSIGNED(src) do { \
    uint32_t _r = (uint32_t)regs->ax * (uint32_t)(src); \
    regs->ax = (uint16_t)_r; \
    regs->dx = (uint16_t)(_r >> 16); \
} while(0)

#define IMUL_SIGNED(src) do { \
    int32_t _r = (int32_t)(int16_t)regs->ax * (int32_t)(int16_t)(src); \
    regs->ax = (uint16_t)_r; \
    regs->dx = (uint16_t)(_r >> 16); \
} while(0)

#define DIV_UNSIGNED(src) do { \
    uint32_t _num = ((uint32_t)regs->dx << 16) | regs->ax; \
    uint16_t _div = (uint16_t)(src); \
    if (_div != 0) { regs->ax = (uint16_t)(_num / _div); regs->dx = (uint16_t)(_num % _div); } \
} while(0)

#define IDIV_SIGNED(src) do { \
    int32_t _num = ((int32_t)regs->dx << 16) | regs->ax; \
    int16_t _div = (int16_t)(src); \
    if (_div != 0) { regs->ax = (int16_t)(_num / _div); regs->dx = (int16_t)(_num % _div); } \
} while(0)

/* ============================================================================
 * BCD ARITHMETIC
 * ============================================================================ */

static inline void AAA(CPU_REGS *regs) { (void)regs; /* ASCII adjust after add */ }
static inline void AAS(CPU_REGS *regs) { (void)regs; /* ASCII adjust after sub */ }
static inline void AAD(CPU_REGS *regs) { regs->al = regs->ah * 10 + regs->al; regs->ah = 0; }
static inline void AAM(CPU_REGS *regs) { regs->ah = regs->al / 10; regs->al = regs->al % 10; }
static inline void DAA(CPU_REGS *regs) { (void)regs; /* Decimal adjust after add */ }
static inline void DAS(CPU_REGS *regs) { (void)regs; /* Decimal adjust after sub */ }

/* ============================================================================
 * DOS / BIOS INTERRUPT SERVICES
 * ============================================================================ */

/* INT 21h - DOS Services */
static inline void dos_int21(CPU_REGS *regs) {
    switch (regs->ah) {
        case 0x00: /* Terminate program */ break;
        case 0x01: /* Read character with echo */ break;
        case 0x02: /* Write character */ break;
        case 0x06: /* Direct console I/O */ break;
        case 0x09: /* Write string ($ terminated) */ break;
        case 0x0D: /* Disk reset */ break;
        case 0x19: /* Get current drive */ break;
        case 0x1A: /* Set DTA address */ break;
        case 0x25: /* Set interrupt vector */ break;
        case 0x2F: /* Get DTA address */ break;
        case 0x30: /* Get DOS version */ regs->al = 7; regs->ah = 0; break;
        case 0x33: /* Get/set break flag */ break;
        case 0x35: /* Get interrupt vector */ break;
        case 0x3C: /* Create file */ break;
        case 0x3D: /* Open file */ break;
        case 0x3E: /* Close file */ break;
        case 0x3F: /* Read file */ break;
        case 0x40: /* Write file */ break;
        case 0x41: /* Delete file */ break;
        case 0x42: /* Seek file */ break;
        case 0x43: /* Get/set file attributes */ break;
        case 0x44: /* IOCTL */ break;
        case 0x48: /* Allocate memory */ break;
        case 0x49: /* Free memory */ break;
        case 0x4A: /* Resize memory */ break;
        case 0x4B: /* Load/execute program (EXEC) */ break;
        case 0x4C: /* Terminate with return code */ break;
        case 0x4D: /* Get return code */ break;
        case 0x50: /* Set PSP */ break;
        case 0x51: /* Get PSP */ break;
        case 0x52: /* Get SysVars */ break;
        case 0x56: /* Rename file */ break;
        case 0x57: /* Get/set file date */ break;
        case 0x58: /* Get/set allocation strategy */ break;
        case 0x5D: /* Critical error info */ break;
        case 0x62: /* Get PSP address */ break;
        case 0x65: /* Get extended country info */ break;
        case 0x67: /* Set handle count */ break;
        default: break;
    }
}

/* INT 10h - BIOS Video Services */
static inline void bios_video_int(CPU_REGS *regs) {
    switch (regs->ah) {
        case 0x00: /* Set video mode */ break;
        case 0x01: /* Set cursor shape */ break;
        case 0x02: /* Set cursor position */ break;
        case 0x03: /* Get cursor position */ break;
        case 0x05: /* Set active page */ break;
        case 0x06: /* Scroll up */ break;
        case 0x07: /* Scroll down */ break;
        case 0x08: /* Read char/attr */ break;
        case 0x09: /* Write char/attr */ break;
        case 0x0E: /* Write character (teletype) */ break;
        case 0x0F: /* Get video mode */ break;
        case 0x10: /* Set palette */ break;
        case 0x11: /* Character generator */ break;
        case 0x12: /* Alternate select */ break;
        case 0x13: /* Write string */ break;
        case 0x1A: /* Get/set display combination */ break;
        case 0x4F: /* VESA BIOS extensions */ break;
        default: break;
    }
}

/* INT 13h - BIOS Disk Services */
static inline void bios_disk_int(CPU_REGS *regs) {
    switch (regs->ah) {
        case 0x00: /* Reset disk system */ break;
        case 0x01: /* Get disk status */ break;
        case 0x02: /* Read sectors */ break;
        case 0x03: /* Write sectors */ break;
        case 0x04: /* Verify sectors */ break;
        case 0x08: /* Get drive parameters */ break;
        case 0x15: /* Get disk type */ break;
        case 0x41: /* Check extensions present */ break;
        case 0x42: /* Extended read */ break;
        case 0x43: /* Extended write */ break;
        default: break;
    }
}

/* INT 15h - BIOS Miscellaneous Services */
static inline void bios_misc_int(CPU_REGS *regs) { (void)regs; }

/* INT 16h - BIOS Keyboard Services */
static inline void bios_keyboard_int(CPU_REGS *regs) { (void)regs; }

/* INT 1Ah - BIOS Time Services */
static inline void bios_time_int(CPU_REGS *regs) { (void)regs; }

/* INT 20h - DOS Terminate */
static inline void dos_terminate(CPU_REGS *regs) { (void)regs; }

/* INT 2Fh - DOS Multiplex */
static inline void dos_multiplex_int(CPU_REGS *regs) { (void)regs; }

/* INT 31h - DPMI */
static inline void dpmi_int(CPU_REGS *regs) { (void)regs; }

/* INT 33h - Mouse */
static inline void mouse_int(CPU_REGS *regs) { (void)regs; }

/* INT 3Fh - NE Relocation */
static inline void ne_relocation_fixup(CPU_REGS *regs) { (void)regs; }

/* INT 67h - EMS */
static inline void ems_int(CPU_REGS *regs) { (void)regs; }

/* Generic software interrupt */
static inline void software_interrupt(CPU_REGS *regs, uint8_t intno) {
    (void)regs; (void)intno;
}

/* ============================================================================
 * PROTECTED MODE / SYSTEM OPERATIONS
 * ============================================================================ */

static inline void HLT(void) { /* halt processor */ }
static inline void DEBUG_BREAK(void) { /* int 3 */ }
static inline void OVERFLOW_TRAP(void) { /* int 4 if OF set */ }
static inline void UNDEFINED_OPCODE(void) { /* ud2 */ }
static inline void IRET(void) { /* return from interrupt */ }

/* GDT/IDT/LDT/TSS */
#define LGDT(src)   /* Load Global Descriptor Table register */
#define SGDT(dst)   /* Store GDT register */
#define LIDT(src)   /* Load Interrupt Descriptor Table register */
#define SIDT(dst)   /* Store IDT register */
#define LLDT(src)   /* Load Local Descriptor Table register */
#define SLDT(dst)   /* Store LDT register */
#define LTR(src)    /* Load Task Register */
#define STR(dst)    /* Store Task Register */
#define LMSW(src)   /* Load Machine Status Word */
#define SMSW(dst)   /* Store Machine Status Word */
#define ARPL(d,s)   /* Adjust RPL field */
#define VERR(sel)   /* Verify segment for reading */
#define VERW(sel)   /* Verify segment for writing */
#define CLTS()      /* Clear Task Switch flag in CR0 */
#define INVD()      /* Invalidate cache */
#define WBINVD()    /* Write back and invalidate cache */
#define INVLPG(a)   /* Invalidate TLB entry */

/* MSR / CPUID / TSC */
static inline void WRMSR(uint32_t msr, uint32_t hi, uint32_t lo) { (void)msr; (void)hi; (void)lo; }
static inline void RDMSR(uint32_t msr, uint32_t *hi, uint32_t *lo) { (void)msr; *hi = 0; *lo = 0; }
static inline void RDTSC(uint32_t *hi, uint32_t *lo) { *hi = 0; *lo = 0; }
static inline void CPUID(CPU_REGS *regs) { (void)regs; }

/* ============================================================================
 * VxD SERVICES (VMM32.VXD specific)
 * ============================================================================ */

#define VXD_CALL(...)  /* VxD service call */

/* Indirect call/jump */
#define CALL_INDIRECT(target)  /* indirect call */
#define JMP_INDIRECT(target)   /* indirect jump */

/* ============================================================================
 * FPU STUBS
 * All FPU operations are stubbed. Link with a FPU emulation library
 * for actual floating-point support.
 * ============================================================================ */

#define FPU_FILD(...)
#define FPU_FIST(...)
#define FPU_FISTP(...)
#define FPU_FLD(...)
#define FPU_FSTP(...)
#define FPU_FST(...)
#define FPU_FADD(...)
#define FPU_FSUB(...)
#define FPU_FMUL(...)
#define FPU_FDIV(...)
#define FPU_FCHS(...)
#define FPU_FABS(...)
#define FPU_FCOM(...)
#define FPU_FCOMP(...)
#define FPU_FCOMPP(...)
#define FPU_FICOM(...)
#define FPU_FICOMP(...)
#define FPU_FTST(...)
#define FPU_FXAM(...)
#define FPU_FLDZ(...)
#define FPU_FLD1(...)
#define FPU_FLDPI(...)
#define FPU_FLDL2T(...)
#define FPU_FLDL2E(...)
#define FPU_FLDLG2(...)
#define FPU_FLDLN2(...)
#define FPU_FINIT(...)
#define FPU_FNINIT(...)
#define FPU_FNSTSW(...)
#define FPU_FSTSW(...)
#define FPU_FNSTCW(...)
#define FPU_FSTCW(...)
#define FPU_FLDCW(...)
#define FPU_FSTENV(...)
#define FPU_FLDENV(...)
#define FPU_FSAVE(...)
#define FPU_FRSTOR(...)
#define FPU_FXCH(...)
#define FPU_FFREE(...)
#define FPU_FDECSTP(...)
#define FPU_FINCSTP(...)
#define FPU_FNOP(...)
#define FPU_FCLEX(...)
#define FPU_FNCLEX(...)
#define FPU_FWAIT(...)
#define FPU_FPATAN(...)
#define FPU_FPTAN(...)
#define FPU_FSQRT(...)
#define FPU_FSIN(...)
#define FPU_FCOS(...)
#define FPU_FSINCOS(...)
#define FPU_FPREM(...)
#define FPU_FPREM1(...)
#define FPU_FRNDINT(...)
#define FPU_FSCALE(...)
#define FPU_FXTRACT(...)
#define FPU_FYL2X(...)
#define FPU_FYL2XP1(...)
#define FPU_F2XM1(...)
#define FPU_FBLD(...)
#define FPU_FBSTP(...)
#define FPU_FIADD(...)
#define FPU_FISUB(...)
#define FPU_FIMUL(...)
#define FPU_FIDIV(...)
#define FPU_FISUBR(...)
#define FPU_FIDIVR(...)
#define FPU_FSUBR(...)
#define FPU_FDIVR(...)
#define FPU_FADDP(...)
#define FPU_FSUBP(...)
#define FPU_FMULP(...)
#define FPU_FDIVP(...)
#define FPU_FSUBRP(...)
#define FPU_FDIVRP(...)
#define FPU_FUCOMI(...)
#define FPU_FUCOMIP(...)
#define FPU_FCOMI(...)
#define FPU_FCOMIP(...)
#define FPU_FUCOM(...)
#define FPU_FUCOMP(...)
#define FPU_FUCOMPP(...)

/* Generic FPU catch-all for any not listed above */
#define FPU_UNKNOWN(...)

/* ============================================================================
 * SSE/MMX STUBS
 * ============================================================================ */

#define SSE_MOVUPS(...)    #define SSE_MOVAPS(...)    #define SSE_ADDPS(...)
#define SSE_SUBPS(...)     #define SSE_MULPS(...)     #define SSE_DIVPS(...)
#define SSE_SQRTPS(...)    #define SSE_ANDPS(...)     #define SSE_ANDNPS(...)
#define SSE_ORPS(...)      #define SSE_XORPS(...)     #define SSE_CMPPS(...)
#define SSE_SHUFPS(...)    #define SSE_UNPCKLPS(...)  #define SSE_UNPCKHPS(...)
#define SSE_RCPPS(...)     #define SSE_RSQRTPS(...)   #define SSE_CVTPS2PI(...)
#define SSE_CVTPI2PS(...)  #define SSE_CVTPS2PD(...)  #define SSE_CVTDQ2PS(...)
#define SSE_MOVD(...)      #define SSE_MOVQ(...)      #define SSE_EMMS(...)
#define SSE_SFENCE(...)    #define SSE_LFENCE(...)    #define SSE_MFENCE(...)
#define SSE_PAUSE(...)     #define SSE_PREFETCHNTA(...) #define SSE_PREFETCHT0(...)
#define SSE_XRELEASE(...)  #define SSE_XACQUIRE(...)
#define SSE_PAND(...)      #define SSE_PANDN(...)     #define SSE_POR(...)
#define SSE_PXOR(...)      #define SSE_PADDB(...)     #define SSE_PADDW(...)
#define SSE_PADDD(...)     #define SSE_PADDQ(...)     #define SSE_PADDUSW(...)
#define SSE_PSUBB(...)     #define SSE_PSUBW(...)     #define SSE_PSUBD(...)
#define SSE_PMULLW(...)    #define SSE_PMULHW(...)    #define SSE_PMULHUW(...)
#define SSE_PMAXSW(...)    #define SSE_PAVGW(...)     #define SSE_PINSRW(...)
#define SSE_PCMPEQB(...)   #define SSE_PCMPEQW(...)   #define SSE_PCMPEQD(...)
#define SSE_PCMPGTB(...)   #define SSE_PCMPGTW(...)   #define SSE_PCMPGTD(...)
#define SSE_PSLLW(...)     #define SSE_PSLLD(...)     #define SSE_PSLLQ(...)
#define SSE_PSRLW(...)     #define SSE_PSRLD(...)     #define SSE_PSRLQ(...)
#define SSE_PSRAW(...)     #define SSE_PSRAD(...)
#define SSE_PUNPCKLBW(...) #define SSE_PUNPCKLWD(...) #define SSE_PUNPCKLDQ(...)
#define SSE_PUNPCKHBW(...) #define SSE_PUNPCKHWD(...) #define SSE_PUNPCKHDQ(...)
#define SSE_PACKSSWB(...)  #define SSE_PACKSSDW(...)  #define SSE_PACKUSWB(...)
#define SSE_POPAW(...)     #define SSE_GENERIC(...)

/* ============================================================================
 * ADDITIONAL SYSTEM OPERATIONS
 * ============================================================================ */

#define BOUND_CHECK(idx, bounds)
#define SHLD(dst, src, cnt)
#define SHRD(dst, src, cnt)
#define CMPXCHG(dst, src, r)
#define CMPXCHG8B(dst, r)
#define SYSENTER(r)
#define SYSEXIT(r)
#define SYSCALL(r)
#define SYSRET(r)
#define DEBUG_MONITOR_INT()
#define XABORT(imm)
#define XBEGIN(target)
#define XEND()

/* ============================================================================
 * MEMORY ALLOCATION
 * ============================================================================ */

uint8_t g_memory[MEMORY_SIZE];

#endif /* W95TYPES_H */
