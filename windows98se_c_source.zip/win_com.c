/*
 * Windows Startup Loader (WIN.COM)
 * DOS stub that loads Windows 95. Initializes environment, checks memory, and launches the Windows kernel.
 *
 * AUTO-GENERATED from annotated disassembly.
 * Original binary reconstructed into C function structure.
 *
 * Architecture: 16-bit real/protected mode
 */

#include "w95types.h"
#include "win_com.h"


/* Code block at 0x00000000 */
void code_00000000(CPU_REGS *regs)
{
loc_00000000:
    goto loc_00000F73;
loc_00000003:
    PUSH(regs->cs);
    regs->ds = POP();
    PUSH(regs->cs);
    regs->es = POP();
    func_00000241(regs);
    if (CF) goto loc_00000027;
loc_0000000C:
    regs->dl = 0; CF = 0; ZF = 1;  /* ZERO DL: XOR with itself = 0 */
    regs->ax = 0x1231;
    dos_multiplex_int(regs);  /* AH=12h: DOS internal */
    regs->dx = 0x6ef;
    regs->di = 0x80;
    regs->si = regs->ds;
    func_0000027A(regs);
    if (!CF) goto loc_00000027;
    regs->cx = MEM[0x430];
    func_000002A1(regs);
loc_00000027:
    CMP(regs->al, 0x43);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_0000004D;
loc_0000002B:
    func_0000011C(regs);
    IF_FLAG = 0; /* disable interrupts */
    regs->ax = 0; CF = 0; ZF = 1;
    regs->ds = regs->ax;
    MEM[0x472] = 0x1234;
    CMP(MEM[0x60a], 0x0);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00000048;
    regs->al = 0xfe;
    PORT_OUT(0x64, regs->al);
loc_00000045:
    HLT(); /* halt until interrupt */
    goto loc_00000045;
loc_00000048:
    goto loc_000FFFF0;
loc_0000004D:
    CMP(regs->al, 0x42);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00000058;
    CMP(regs->al, 0x44);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00000085;
    func_00000134(regs);
loc_00000058:
    MEM[0x80] = 0xd00;
    regs->dx = 0x63d;
    regs->ah = 0x9;
    dos_int21(regs);  /* AH=09h: Write string to stdout */
    regs->ax = 0x1611;
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00000074;
    regs->bx = regs->dx;
    regs->bx--; UPDATE_FLAGS_DEC();
    MEM[regs->bx] &= 0x78; UPDATE_FLAGS_LOGIC();
loc_00000074:
    regs->ah = 0x48;
    regs->bx = 0xffff;
    dos_int21(regs);  /* AH=48h: Allocate memory */
    CMP(regs->bx, MEM[0x42c]);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_0000002B;
    goto loc_00000003;
loc_00000085:
    PUSH(regs->ax);
    PUSH(regs->ds);
    regs->ax = 0x4a10;
    regs->bx = 0x8;
    dos_multiplex_int(regs);  /* AH=4Ah: HMA */
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00000099;
    regs->es = regs->bx;
    regs->ah = 0x49;
    dos_int21(regs);  /* AH=49h: Free memory */
loc_00000099:
    LOAD_FAR_PTR(&regs->ds, &regs->dx, MEM[0x44b]);
    regs->ax = regs->ds;
    regs->ax |= regs->dx; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_000000BD;
    regs->ax = 0x252f;
    dos_int21(regs);  /* AH=25h: Set interrupt vector */
    LOAD_FAR_PTR(&regs->ds, &regs->dx, MEM[0x441]);
    regs->ax = 0x2513;
    dos_int21(regs);  /* AH=25h: Set interrupt vector */
    LOAD_FAR_PTR(&regs->ds, &regs->dx, MEM[0x446]);
    regs->ax = 0x2521;
    dos_int21(regs);  /* AH=25h: Set interrupt vector */
loc_000000BD:
    regs->ds = POP();
    func_0000011C(regs);
    regs->cx = 0x7;
    regs->si = 0x602;
    regs->di = 0x6ef;
    func_000002B8(regs);
    regs->dx = 0x6ef;
    regs->di = 0x4d1;
    MEM[regs->di] = 0x3;
    MEM[regs->di + 0x1] = 0x2f20;
    MEM[regs->di + 0x3] = 0xd7a;
    regs->si = 0; CF = 0; ZF = 1;
    func_0000027A(regs);
    PUSH(regs->ax);
    func_0000011C(regs);
    regs->ax = POP();
    TEST(regs->al, regs->al);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000000FA;
    regs->ax = 0x3;
    bios_video_int(regs);  /* AH=00h: Set video mode */
    regs->dx = 0x66f;
    regs->ah = 0x9;
    dos_int21(regs);  /* AH=09h: Write string to stdout */
loc_000000FA:
    regs->dx = 0x3da;
    regs->al = PORT_IN(regs->dx);
    regs->dl = 0xc0;
    regs->al = 0x20;
    PORT_OUT(regs->dx, regs->al);
    regs->ax = regs->cs;
    CMP(regs->ax, MEM[0x16]);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00000116;
loc_0000010C:
    regs->bl = 0x3;
    regs->ax = 0x160e;
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
loc_00000113:
    /* nop */
    goto loc_00000113;
loc_00000116:
    regs->ax = POP();
    regs->ah = 0x4c;
    dos_int21(regs);  /* AH=4Ch: Terminate with return code */
    return; /* far */
}

/*
 * Function at 0x0000011C
 */
void func_0000011C(CPU_REGS *regs)
{
    regs->ah = 0xd;
    dos_int21(regs);  /* AH=0Dh: Disk reset */
    PUSH(regs->ds);
    regs->cx = 0; CF = 0; ZF = 1;
    regs->ds = regs->cx;
    regs->cl = MEM[0x475];
    regs->ds = POP();
    regs->dl = 0x80;
loc_0000012C:
    regs->ah = 0x0;
    bios_disk_int(regs);  /* AH=00h: Reset disk system */
    regs->dx++; UPDATE_FLAGS_INC();
    regs->cx--; if (regs->cx != 0) goto loc_0000012C;
    return;
}

/*
 * Function at 0x00000134
 */
void func_00000134(CPU_REGS *regs)
{
    PUSH(regs->cs);
    regs->ds = POP();
    PUSH(regs->ds);
    regs->ds = MEM[0x2c];
    DF = 0;
    regs->si = 0; CF = 0; ZF = 1;  /* ZERO SI: XOR with itself = 0 */
    regs->di = 0; CF = 0; ZF = 1;  /* ZERO DI: XOR with itself = 0 */
loc_00000140:
    CMP(MEM[regs->si], 0x0);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_0000014E;
    regs->di = regs->si;
loc_00000147:
    STRING_LOAD_BYTE(regs);
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00000147;
    goto loc_00000140;
loc_0000014E:
    CMP(MEM[regs->di], 0x77);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00000158;
    regs->di = 0; CF = 0; ZF = 1;  /* ZERO DI: XOR with itself = 0 */
    regs->di--; UPDATE_FLAGS_DEC();
    goto loc_0000015B;
loc_00000158:
    MEM[regs->di] = 0x0;
loc_0000015B:
    regs->ds = POP();
    PUSH(regs->di);
    regs->cx = 0xc;
    regs->si = 0x5f5;
    regs->di = 0x85;
    func_000002B8(regs);
    XCHG(regs->ax, regs->bx);
    regs->dx = regs->di;
    regs->ax = 0x4300;
    dos_int21(regs);  /* AH=43h: Get/set file attributes */
    if (CF) goto loc_0000019C;
    MEM[regs->bx + regs->di] = 0xd;
    regs->bx += 0x4; UPDATE_FLAGS_ADD();
    MEM[regs->di - 0x5] = regs->bl;
    MEM[regs->di - 0x4] = 0x2f20;
    MEM[regs->di - 0x2] = 0x2043;
    regs->cx = 0xb;
    regs->si = 0x5e9;
    regs->di = 0x551;
    func_000002B8(regs);
    regs->dx = regs->di;
    regs->di = 0x80;
    regs->si = 0; CF = 0; ZF = 1;
    func_0000027A(regs);
loc_0000019C:
    DF = 0;
    MEM[0x80] = 0x5cff;
    regs->si = 0x451;
loc_000001A6:
    regs->bp = regs->si;
    STRING_LOAD_WORD(regs);
    CMP(regs->ah, 0x3a);  /* COMPARISON: Testing condition for branch */
}

/* String data at 0x000001AC */
static const char str_000001AC[] = "um,A< ";


/* Code at 0x000001B2 */
void code_000001B2(CPU_REGS *regs)
{
    if (CF) goto loc_000001B6;
    regs->al -= 0x20; UPDATE_FLAGS_SUB();
loc_000001B6:
    XCHG(regs->ax, regs->dx);
    regs->bx = regs->si;
loc_000001B9:
    STRING_LOAD_BYTE(regs);
    TEST(regs->al, regs->al);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000001CE;
    CMP(regs->al, 0x20);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000001CE;
    CMP(regs->al, 0x5c);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000001CA;
    CMP(regs->al, 0x2f);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000001B9;
loc_000001CA:
    regs->bx = regs->si;
    goto loc_000001B9;
loc_000001CE:
    regs->si = regs->bx;
    regs->di = 0x5e9;
    regs->cx = 0xb;
    STRING_CMP_BYTE(regs);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000001EE;
    regs->si = 0x4d1;
    STRING_LOAD_BYTE(regs);
    CMP(regs->al, 0x5);  /* COMPARISON: Testing condition for branch */
    if (CF) goto loc_000001EE;
    STRING_LOAD_WORD(regs);
    CMP(regs->ax, 0x2f20);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000001EE;
    STRING_LOAD_WORD(regs);
    CMP(regs->ax, 0x2063);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000001A6;
loc_000001EE:
    regs->si = regs->bp + 0x3;
    CMP(regs->bx, regs->si);  /* COMPARISON: Testing condition for branch */
    if (CF) goto loc_0000021B;
    if (ZF) goto loc_000001F8;
    regs->bx--; UPDATE_FLAGS_DEC();
loc_000001F8:
    regs->ah = 0x19;
    dos_int21(regs);  /* AH=19h: Get current disk */
    regs->si = 0x80;
    MEM[regs->si] = regs->al;
    regs->si++; UPDATE_FLAGS_INC();
    regs->si++; UPDATE_FLAGS_INC();
    PUSH(regs->dx);
    regs->dl = 0x0;
    regs->ah = 0x47;
    dos_int21(regs);  /* AH=47h: Get current directory */
    regs->dx = POP();
    regs->ah = 0xe;
    dos_int21(regs);  /* AH=0Eh: Select disk */
    regs->cl = 0x0;
    XCHG(regs->cl, MEM[regs->bx]);
    regs->dx = regs->bp;
    regs->ah = 0x3b;
    dos_int21(regs);  /* AH=3Bh: Change directory */
    MEM[regs->bx] = regs->cl;
loc_0000021B:
    func_00000272(regs);
    DF = 0;
    regs->si = 0x80;
    STRING_LOAD_BYTE(regs);
    CMP(regs->al, 0xff);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00000232;
    XCHG(regs->ax, regs->dx);
    regs->ah = 0xe;
    dos_int21(regs);  /* AH=0Eh: Select disk */
    regs->dx = regs->si;
    regs->ah = 0x3b;
    dos_int21(regs);  /* AH=3Bh: Change directory */
loc_00000232:
    regs->di = POP();
    regs->di++; UPDATE_FLAGS_INC();
    if (ZF) goto loc_00000240;
    regs->di--; UPDATE_FLAGS_DEC();
    PUSH(regs->ds);
    regs->ds = MEM[0x2c];
    MEM[regs->di] = 0x77;
    regs->ds = POP();
loc_00000240:
    return;
}

/*
 * Function at 0x00000241
 */
void func_00000241(CPU_REGS *regs)
{
    regs->cx = 0xb;
    regs->si = 0x5dd;
    regs->di = 0x451;
    func_000002B8(regs);
    regs->dx = regs->di;
    regs->ax = 0x4300;
    dos_int21(regs);  /* AH=43h: Get/set file attributes */
    CF = !CF;
    if (!CF) goto loc_00000271;
    MEM[0x4d1] = 0x0;
    regs->cx = 0xb;
    regs->si = 0x5d1;
    regs->di = 0x451;
    func_000002B8(regs);
    XCHG(regs->ax, regs->cx);
    func_00000272(regs);
    if (!CF) goto loc_00000271;
    func_000002A1(regs);
loc_00000271:
    return;
}

/*
 * Function at 0x00000272
 */
void func_00000272(CPU_REGS *regs)
{
    regs->dx = 0x451;
    regs->di = 0x4d1;
    regs->si = 0; CF = 0; ZF = 1;
}

/*
 * Function at 0x0000027A
 */
void func_0000027A(CPU_REGS *regs)
{
    regs->ah = 0x48;
    regs->bx = 0xffff;
    dos_int21(regs);  /* AH=48h: Allocate memory */
    PUSH(regs->cs);
    regs->es = POP();
    regs->bx = 0x432;
    MEM[regs->bx + 0x2] = regs->di;
    MEM[regs->bx] = regs->si;
    regs->ax = 0x4b00;
    PUSH(regs->dx);
    dos_int21(regs);  /* AH=4Bh: Execute program */
    regs->dx = POP();
    if (CF) goto loc_000002A0;
    regs->ah = 0x4d;
    dos_int21(regs);  /* AH=4Dh: Get return code of child process */
    TEST(regs->ah, regs->ah);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000002A0;
loc_0000029C:
    regs->ax = 0xffff;
    CF = 1;
loc_000002A0:
    return;
}

/*
 * Function at 0x000002A1
 */
void func_000002A1(CPU_REGS *regs)
{
    regs->ah = 0x9;
    regs->si = regs->dx;
    regs->si += regs->cx; UPDATE_FLAGS_ADD();
    MEM[regs->si] = 0x24;
    dos_int21(regs);  /* AH=09h: Write string to stdout */
    MEM[regs->si] = 0x0;
    regs->dx = 0x60b;
    regs->ah = 0x9;
    dos_int21(regs);  /* AH=09h: Write string to stdout */
    goto loc_0000029C;
}

/*
 * Function at 0x000002B8
 */
void func_000002B8(CPU_REGS *regs)
{
    DF = 0;
}

/* String data at 0x000002B9 */
static const char str_000002B9[] = "QRVWQV";


/* Code at 0x000002BF */
void code_000002BF(CPU_REGS *regs)
{
    PUSH(regs->ds);
    PUSH(regs->ds);
    regs->es = POP();
    regs->cx = MEM[0x100];
    if (regs->cx == 0) goto loc_000002E6;
    regs->ax = regs->cx;
    LOAD_FAR_PTR(&regs->ds, &regs->si, MEM[0x428]);
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->ds = POP();
    regs->si = POP();
    regs->cx = POP();
    regs->di--; UPDATE_FLAGS_DEC();
    CMP(MEM[regs->di], 0x5c);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000002E3;
    CMP(MEM[regs->di], 0x2f);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000002E3;
    regs->di++; UPDATE_FLAGS_INC();
    MEM[regs->di] = 0x5c;
    regs->ax++; UPDATE_FLAGS_INC();
loc_000002E3:
    regs->di++; UPDATE_FLAGS_INC();
    goto loc_000002EB;
loc_000002E6:
    regs->ds = POP();
    regs->si = POP();
    regs->cx = POP();
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
loc_000002EB:
    regs->ax += regs->cx; UPDATE_FLAGS_ADD();
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    MEM[regs->di] = regs->cl;
    regs->di = POP();
    regs->si = POP();
    regs->dx = POP();
    regs->cx = POP();
    return;
    CMP(regs->ax, 0x4b20);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00000317;
    CMP(regs->ax, 0x4b21);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_0000031F;
    CMP(regs->ax, 0x4b22);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_0000030A;
    JMP_INDIRECT(far [cs:0x44b]);
loc_0000030A:
    regs->ax = 0; CF = 0; ZF = 1;
    regs->cl = MEM[0x424];
    regs->dx = MEM[0x425];
    IRET(); return;
loc_00000317:
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
    PUSH(regs->cs);
    regs->dx = POP();
    regs->cx = 0x451;
    IRET(); return;
loc_0000031F:
    regs->ax = MEM[0x42e];
    IRET(); return;
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si + 0x0] += regs->dl; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->ax; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += 0x0; UPDATE_FLAGS_ADD();
    MEM[regs->si + 0x0] += regs->bl; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    PORT_INPUT_STRING_BYTE(regs);
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    regs->dl += regs->ch; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    goto loc_00000000;
    goto loc_00000000;
    MEM[regs->si] += regs->ax; UPDATE_FLAGS_ADD();
}

/* Zero-initialized data at 0x00000351 (384 bytes) */
static uint8_t data_00000351[384] = {0};


/* Code at 0x000004D1 */
void code_000004D1(CPU_REGS *regs)
{
    PUSH(regs->di);
    regs->cx--; UPDATE_FLAGS_DEC();
    regs->si--; UPDATE_FLAGS_DEC();
    regs->cx--; UPDATE_FLAGS_DEC();
    regs->si--; UPDATE_FLAGS_DEC();
    regs->cx--; UPDATE_FLAGS_DEC();
    PUSH(regs->sp);
    regs->bp++; UPDATE_FLAGS_INC();
    regs->ax = POP();
    regs->bp++; UPDATE_FLAGS_INC();
    MEM[regs->bx + 0x49] += regs->dl; UPDATE_FLAGS_ADD();
    regs->si--; UPDATE_FLAGS_DEC();
    regs->cx--; UPDATE_FLAGS_DEC();
    regs->si--; UPDATE_FLAGS_DEC();
    regs->cx--; UPDATE_FLAGS_DEC();
    PUSH(regs->sp);
    regs->cx--; UPDATE_FLAGS_DEC();
    regs->si--; UPDATE_FLAGS_DEC();
    regs->cx--; UPDATE_FLAGS_DEC();
    MEM[regs->bp + regs->di + 0x4f] += regs->al; UPDATE_FLAGS_ADD();
    regs->bp--; UPDATE_FLAGS_DEC();
    regs->bp--; UPDATE_FLAGS_DEC();
    regs->cx++; UPDATE_FLAGS_INC();
    regs->si--; UPDATE_FLAGS_DEC();
    regs->sp++; UPDATE_FLAGS_INC();
    regs->bx++; UPDATE_FLAGS_INC();
    regs->di--; UPDATE_FLAGS_DEC();
    regs->bp--; UPDATE_FLAGS_DEC();
    MEM[regs->si + 0x4f] += regs->al; UPDATE_FLAGS_ADD();
    PUSH(regs->bx);
    PUSH(regs->bx);
    PUSH(regs->sp);
    regs->cx++; UPDATE_FLAGS_INC();
    PUSH(regs->dx);
    PUSH(regs->sp);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->cx++; UPDATE_FLAGS_INC();
    PUSH(regs->sp);
    MEM[regs->bx + 0x69] += regs->dh; UPDATE_FLAGS_ADD();
    PORT_OUTPUT_STRING_BYTE(regs);
    ARPL(MEM[regs->bx + 0x6d], regs->bp);
}

/* Zero-initialized data at 0x00000509 (486 bytes) */
static uint8_t data_00000509[486] = {0};


/* Code at 0x000006EF */
void code_000006EF(CPU_REGS *regs)
{
    MEM[regs->di + 0x0] += regs->ah; UPDATE_FLAGS_ADD();
    PUSH(0x6900);
    MEM[regs->bp + regs->di + 0x0] += regs->ch; UPDATE_FLAGS_ADD();
    PORT_INPUT_STRING_BYTE(regs);
    MEM[regs->di + 0x0] += regs->ch; UPDATE_FLAGS_ADD();
    PORT_OUTPUT_STRING_BYTE(regs);
    MEM[regs->bx + 0x0] += regs->ch; UPDATE_FLAGS_ADD();
    if (OF) goto loc_00000702;
loc_00000702:
    if (!OF) goto loc_00000704;
loc_00000704:
    if (CF) goto loc_00000706;
loc_00000706:
    if (!CF) goto loc_00000708;
loc_00000708:
    if (ZF) goto loc_0000070A;
loc_0000070A:
    if (!ZF) goto loc_0000070C;
loc_0000070C:
    if (CF || ZF) goto loc_0000070E;
loc_0000070E:
    if (!CF && !ZF) goto loc_00000710;
loc_00000710:
    if (SF) goto loc_00000712;
loc_00000712:
    if (!SF) goto loc_00000714;
loc_00000714:
    if (PF) goto loc_00000716;
loc_00000716:
    if (!PF) goto loc_00000718;
loc_00000718:
    if (SF != OF) goto loc_0000071A;
loc_0000071A:
    if (SF == OF) goto loc_0000071C;
loc_0000071C:
    if (ZF || SF != OF) goto loc_0000071E;
loc_0000071E:
    if (!ZF && SF == OF) goto loc_00000720;
loc_00000720:
    MEM[regs->bx + regs->si] += 0x81; UPDATE_FLAGS_ADD();
    MEM[regs->bp + regs->si - 0x7d00] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->si - 0x7b00] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bp - 0x7900] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si - 0x7700] += regs->cl; UPDATE_FLAGS_ADD();
    MEM[regs->bp + regs->si - 0x7500] += regs->cl; UPDATE_FLAGS_ADD();
}

/* Zero-initialized data at 0x00000737 (8 bytes) */
static uint8_t data_00000737[8] = {0};


/* Code at 0x0000073F */
void code_0000073F(CPU_REGS *regs)
{
    MEM[regs->si] += regs->ah; UPDATE_FLAGS_ADD();
}

/* Zero-initialized data at 0x00000741 (26 bytes) */
static uint8_t data_00000741[26] = {0};


/* Code at 0x0000075B */
void code_0000075B(CPU_REGS *regs)
{
    MEM[regs->si] += regs->ah; UPDATE_FLAGS_ADD();
    IF_FLAG = 1; /* enable interrupts */
    PUSH(regs->ds);
    PUSH(regs->es);
    PUSH(regs->si);
    PUSH(regs->cx);
    PUSH(regs->cs);
    regs->ds = POP();
    PUSH(regs->ds);
    regs->es = POP();
    regs->al += 0x41; UPDATE_FLAGS_ADD();
    MEM[0x846] = regs->al;
    MEM[0x84f] = regs->di;
    MEM[0x845] = regs->ah;
    regs->ds = regs->bp;
    regs->di = 0x838;
    regs->cx = 0x8;
    regs->al = MEM[regs->si + 0x5];
    regs->si += 0xa; UPDATE_FLAGS_ADD();
    DF = 0;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    PUSH(regs->es);
    regs->ds = POP();
    MEM[0x84b] = regs->al;
    func_0000096E(regs);
    func_000009A7(regs);
    TEST(regs->ah, 0x80);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_0000079A;
    TEST(regs->al, 0x80);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00000947;
loc_0000079A:
    regs->si = MEM[0x800];
    TEST(regs->ah, 0x1);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000007A7;
    regs->si = MEM[0x802];
loc_000007A7:
    PUSH(regs->es);
    PUSH(regs->ds);
    PUSH(regs->bp);
    PUSH(regs->si);
    PUSH(regs->dx);
    PUSH(regs->bx);
    regs->ah = 0x59;
    dos_int21(regs);  /* AH=59h: Get extended error info */
    regs->bx = POP();
    regs->dx = POP();
    regs->si = POP();
    regs->bp = POP();
    regs->ds = POP();
    MEM[0x847] = regs->di;
    MEM[0x849] = regs->es;
    regs->es = POP();
    regs->ah = 0; CF = 0; ZF = 1;  /* ZERO AH: XOR with itself = 0 */
    regs->di = regs->ax;
    regs->di -= 0x13; UPDATE_FLAGS_SUB();
    if (!CF) goto loc_000007CB;
    regs->di = 0xc;
loc_000007CB:
    MEM[0x84c] = 0x0;
    CMP(regs->di, 0x10);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000007DA;
    CMP(regs->di, 0x11);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000007DE;
loc_000007DA:
    MEM[0x84c]++; UPDATE_FLAGS_INC();
loc_000007DE:
    MEM[0x84d] = regs->di;
    CMP(regs->di, 0x14);  /* COMPARISON: Testing condition for branch */
    if (CF || ZF) goto loc_00000827;
    XCHG(regs->ax, regs->di);
    regs->ax = 0x500;
    dos_multiplex_int(regs);  /* AH=05h: Unknown multiplex function 0x05 */
    CMP(regs->al, 0xff);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_0000081A;
    PUSH(regs->bx);
    regs->bx = regs->di;
    regs->ax = 0x501;
    dos_multiplex_int(regs);  /* AH=05h: Unknown multiplex function 0x05 */
    regs->bx = POP();
    if (CF) goto loc_0000081A;
    MEM[0x84c] = regs->al;
    PUSH(regs->ds);
    PUSH(regs->es);
    regs->ds = POP();
    regs->dx = regs->di;
    regs->cx = 0xffff;
    regs->al = 0; CF = 0; ZF = 1;  /* ZERO AL: XOR with itself = 0 */
    DF = 0;
    STRING_SCAN_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    MEM[regs->di - 0x1] = 0x24;
    func_000009AB(regs);
    MEM[regs->di - 0x1] = 0x0;
    regs->ds = POP();
    goto loc_0000082F;
loc_0000081A:
    MEM[0x84c] = 0x0;
    regs->di = MEM[0x84f];
    MEM[0x84d] = regs->di;
loc_00000827:
    regs->di += 0x13; UPDATE_FLAGS_ADD();
    XCHG(regs->di, regs->dx);
    func_000009B2(regs);
loc_0000082F:
    CMP(MEM[0x84c], 0x0);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_0000083B;
    func_000009A7(regs);
    goto loc_0000086B;
loc_0000083B:
    regs->dx = regs->si;
    func_000009AB(regs);
    TEST(MEM[0x84b], 0x80);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00000859;
    regs->dx = MEM[0x806];
    func_000009AB(regs);
    regs->dx = 0x838;
    func_000009AB(regs);
    func_000009A7(regs);
    goto loc_0000086B;
loc_00000859:
    regs->dx = MEM[0x804];
    func_000009AB(regs);
    regs->dl = MEM[0x846];
    regs->ah = 0x2;
    dos_int21(regs);  /* AH=02h: Write character to stdout */
    func_000009A7(regs);
loc_0000086B:
    CMP(MEM[0x84d], 0xf);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000008BB;
    PUSH(regs->ds);
    regs->es = POP();
    LOAD_FAR_PTR(&regs->ds, &regs->si, MEM[0x847]);
    PUSH(regs->di);
    regs->di = 0x851;
    regs->cx = 0xb;
    DF = 0;
loc_00000880:
    STRING_LOAD_BYTE(regs);
    STRING_STORE_BYTE(regs);
    TEST(regs->al, regs->al);
    regs->cx--; if (regs->cx != 0 && !ZF) goto loc_00000880;
    regs->al = 0x24;
    STRING_STORE_BYTE(regs);
    regs->si += regs->cx; UPDATE_FLAGS_ADD();
    regs->si++; UPDATE_FLAGS_INC();
    STRING_LOAD_WORD(regs);
    XCHG(regs->ax, regs->cx);
    STRING_LOAD_WORD(regs);
    regs->di = POP();
    PUSH(regs->es);
    regs->ds = POP();
    regs->dx = MEM[0x808];
    func_000009AB(regs);
    regs->dx = 0x851;
    func_000009AB(regs);
    regs->dx = MEM[0x80c];
    func_000009AB(regs);
    func_000009C5(regs);
    regs->si = MEM[0x7f0];
    regs->dl = MEM[regs->si + 0x4];
    regs->ah = 0x2;
    dos_int21(regs);  /* AH=02h: Write character to stdout */
    XCHG(regs->ax, regs->cx);
    func_000009C5(regs);
    func_000009A7(regs);
loc_000008BB:
    regs->dx = MEM[0x7f6];
    func_000009AB(regs);
    TEST(MEM[0x845], 0x10);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000008D0;
    regs->dx = MEM[0x7f8];
    func_000009AB(regs);
loc_000008D0:
    TEST(MEM[0x845], 0x20);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000008DE;
    regs->dx = MEM[0x7fa];
    func_000009AB(regs);
loc_000008DE:
    TEST(MEM[0x845], 0x8);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000008EC;
    regs->dx = MEM[0x7fc];
    func_000009AB(regs);
loc_000008EC:
    regs->dx = MEM[0x7fe];
    func_000009AB(regs);
    regs->ax = 0xc01;
    dos_int21(regs);  /* AH=0Ch: Flush buffer and read keyboard */
    func_000009A7(regs);
    func_000009E8(regs);
    regs->si = MEM[0x7f0];
    regs->ah = 0x0;
    TEST(MEM[0x845], 0x20);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00000910;
    CMP(regs->al, MEM[regs->si + 0x2]);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00000962;
loc_00000910:
    regs->ah++; UPDATE_FLAGS_INC();
    TEST(MEM[0x845], 0x10);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_0000091E;
    CMP(regs->al, MEM[regs->si + 0x1]);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00000962;
loc_0000091E:
    regs->ah++; UPDATE_FLAGS_INC();
    CMP(regs->al, MEM[regs->si]);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00000935;
    regs->ah++; UPDATE_FLAGS_INC();
    TEST(MEM[0x845], 0x8);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00000932;
    CMP(regs->al, MEM[regs->si + 0x3]);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00000962;
loc_00000932:
    goto loc_0000086B;
loc_00000935:
    regs->dx = regs->cs;
    CMP(regs->dx, MEM[0x841]);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_0000095D;
    regs->dx = MEM[0x7f4];
    func_000009AB(regs);
    goto loc_0000010C;
loc_00000947:
    regs->dx = MEM[0x80a];
    func_000009AB(regs);
    regs->dl = MEM[0x846];
    regs->ah = 0x2;
    dos_int21(regs);  /* AH=02h: Write character to stdout */
    func_000009A7(regs);
    regs->al = 0x2;
    goto loc_00000966;
loc_0000095D:
    regs->ax = 0x4cff;
    dos_int21(regs);  /* AH=4Ch: Terminate with return code */
loc_00000962:
    regs->al = regs->ah;
    regs->dx = regs->di;
loc_00000966:
    func_00000991(regs);
    regs->cx = POP();
    regs->si = POP();
    regs->es = POP();
    regs->ds = POP();
    IRET(); return;
}

/*
 * Function at 0x0000096E
 */
void func_0000096E(CPU_REGS *regs)
{
    PUSH(regs->ax);
    PUSH(regs->bx);
    PUSH(regs->ds);
    regs->ah = 0x51;
    dos_int21(regs);  /* AH=51h: Get current PSP */
    MEM[0x841] = regs->bx;
    regs->ds = regs->bx;
    LOAD_FAR_PTR(&regs->ds, &regs->bx, MEM[0x34]);
    regs->ax = MEM[regs->bx];
    MEM[0x843] = regs->ax;
    regs->al = MEM[0x1a];
    regs->ah = regs->al;
    MEM[regs->bx] = regs->ax;
    regs->ds = POP();
    regs->bx = POP();
    regs->ax = POP();
    return;
}

/*
 * Function at 0x00000991
 */
void func_00000991(CPU_REGS *regs)
{
    PUSH(regs->ds);
    PUSH(regs->bx);
    PUSH(regs->ax);
    regs->ah = 0x51;
    dos_int21(regs);  /* AH=51h: Get current PSP */
    regs->ax = MEM[0x843];
    regs->ds = regs->bx;
    LOAD_FAR_PTR(&regs->ds, &regs->bx, MEM[0x34]);
    MEM[regs->bx] = regs->ax;
    regs->ax = POP();
    regs->bx = POP();
    regs->ds = POP();
    return;
}

/*
 * Function at 0x000009A7
 */
void func_000009A7(CPU_REGS *regs)
{
    regs->dx = MEM[0x7f2];
}

/*
 * Function at 0x000009AB
 */
void func_000009AB(CPU_REGS *regs)
{
    PUSH(regs->ax);
    regs->ah = 0x9;
    dos_int21(regs);  /* AH=09h: Write string to stdout */
    regs->ax = POP();
    return;
}

/*
 * Function at 0x000009B2
 */
void func_000009B2(CPU_REGS *regs)
{
    PUSH(regs->dx);
    XCHG(regs->bx, regs->dx);
    regs->bx -= 0x13; UPDATE_FLAGS_SUB();
    regs->bx <<= 1;
    regs->bx = MEM[regs->bx + 0x80e];
    XCHG(regs->bx, regs->dx);
    func_000009AB(regs);
    regs->dx = POP();
    return;
}

/*
 * Function at 0x000009C5
 */
void func_000009C5(CPU_REGS *regs)
{
    PUSH(regs->ax);
    PUSH(regs->cx);
    regs->cx = 0x4;
loc_000009CA:
    ROL(regs->ax, 0x4);
    regs->dl = regs->al;
    regs->dl &= 0xf; UPDATE_FLAGS_LOGIC();
    regs->dl += 0x30; UPDATE_FLAGS_ADD();
    CMP(regs->dl, 0x39);  /* COMPARISON: Testing condition for branch */
    if (CF || ZF) goto loc_000009DD;
    regs->dl += 0x7; UPDATE_FLAGS_ADD();
loc_000009DD:
    PUSH(regs->ax);
    regs->ah = 0x2;
    dos_int21(regs);  /* AH=02h: Write character to stdout */
    regs->ax = POP();
    regs->cx--; if (regs->cx != 0) goto loc_000009CA;
    regs->cx = POP();
    regs->ax = POP();
    return;
}

/*
 * Function at 0x000009E8
 */
void func_000009E8(CPU_REGS *regs)
{
    PUSH(regs->ax);
    regs->ax = 0x1213;
    dos_multiplex_int(regs);  /* AH=12h: DOS internal */
    regs->sp++; UPDATE_FLAGS_INC();
    regs->sp++; UPDATE_FLAGS_INC();
    return;
}

/* Zero-initialized data at 0x000009F1 (768 bytes) */
static uint8_t data_000009F1[768] = {0};


/* Code at 0x00000CF1 */
void code_00000CF1(CPU_REGS *regs)
{
    DEBUG_BREAK(); /* ICEBP/INT1 */
    regs->al |= MEM[regs->bx + regs->si]; UPDATE_FLAGS_LOGIC();
    MEM[regs->bx + regs->si + 0x41] += regs->dl; UPDATE_FLAGS_ADD();
    PUSH(regs->sp);
    regs->ax--; UPDATE_FLAGS_DEC();
    if (!CF) goto loc_00000D74;
    if (!CF) goto loc_00000D71;
    /* segment override: gs */
    regs->sp = POP();
    if (CF || ZF) goto loc_00000D6F;
    /* 00000D02  6D                insw                   ; Input string word from port DX to ES:[DI] */
    regs->si ^= MEM[regs->bp + regs->si]; UPDATE_FLAGS_LOGIC();
    if (CF || ZF) goto loc_00000D80;
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
}

/* Zero-initialized data at 0x00000D0B (78 bytes) */
static uint8_t data_00000D0B[78] = {0};

/* String data at 0x00000D59 */
static const char str_00000D5A[] = "windir=";
static const char str_00000D62[] = "SMARTDRV.EXE";


/* Code at 0x00000D6E */
void code_00000D6E(CPU_REGS *regs)
{
    MEM[regs->bx + regs->si] += regs->cl; UPDATE_FLAGS_ADD();
}

/* String data at 0x00000D70 */
static const char str_00000D70[] = "/L /U //";


/* Code at 0x00000D78 */
void code_00000D78(CPU_REGS *regs)
{
    regs->ax |= 0x0; UPDATE_FLAGS_LOGIC();
}

/* Zero-initialized data at 0x00000D7B (62 bytes) */
static uint8_t data_00000D7B[62] = {0};


/* Code at 0x00000DB9 */
void code_00000DB9(CPU_REGS *regs)
{
    MEM[regs->bx] &= regs->ch; UPDATE_FLAGS_LOGIC();
    regs->sp++; UPDATE_FLAGS_INC();
    CMP(regs->cl, MEM[regs->di + 0x20]);
    DAS(regs);
    regs->sp++; UPDATE_FLAGS_INC();
    CMP(regs->cl, MEM[regs->bp + 0x0]);
}

/* Zero-initialized data at 0x00000DC4 (10 bytes) */
static uint8_t data_00000DC4[10] = {0};


/* Code at 0x00000DCE */
void code_00000DCE(CPU_REGS *regs)
{
    regs->bh += regs->bh; UPDATE_FLAGS_ADD();
    regs->bh += regs->bh; UPDATE_FLAGS_ADD();
}

/* String data at 0x00000DD2 */
static const char str_00000DD5[] = "FUTURE DOMAIN CORP. (C) 1986-1990 1800-V2USER.DAT";
static const char str_00000E07[] = "SYSTEM.DAT";
static const char str_00000E12[] = "COMMAND\\SCANREG.EXE";


/* Code at 0x00000E25 */
void code_00000E25(CPU_REGS *regs)
{
    MEM[regs->bx + regs->di] += regs->cl; UPDATE_FLAGS_ADD();
}

/* String data at 0x00000E27 */
static const char str_00000E27[] = " /AUTORUN";


/* Code at 0x00000E30 */
void code_00000E30(CPU_REGS *regs)
{
    regs->ax |= 0x200e; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00000E33 */
static const char str_00000E33[] = "/AUTORUN /OPT";


/* Code at 0x00000E40 */
void code_00000E40(CPU_REGS *regs)
{
    regs->ax |= 0x4353; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00000E43 */
static const char str_00000E43[] = "ANDISK.ALT";


/* Code at 0x00000E4D */
void code_00000E4D(CPU_REGS *regs)
{
    MEM[regs->bp + regs->si] += regs->dl; UPDATE_FLAGS_ADD();
}

/* String data at 0x00000E4F */
static const char str_00000E4F[] = " /CUSTOM /SIMPLEUI";


/* Code at 0x00000E61 */
void code_00000E61(CPU_REGS *regs)
{
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0xd0d; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00000ED9 */
static const char str_00000ED9[] = " /SURFACE  :\\";


/* Code at 0x00000EE9 */
void code_00000EE9(CPU_REGS *regs)
{
    MEM[regs->bx + regs->si]++; UPDATE_FLAGS_INC();
    regs->ax++; UPDATE_FLAGS_INC();
}

/* Zero-initialized data at 0x00000EEC (118 bytes) */
static uint8_t data_00000EEC[118] = {0};


/* Code at 0x00000F62 */
void code_00000F62(CPU_REGS *regs)
{
    MEM[regs->bx + regs->di] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
}

/* String data at 0x00000F68 */
static const char str_00000F6A[] = "EMMXXXX0";


/* Code block at 0x00000F73 */
void code_00000F73(CPU_REGS *regs)
{
loc_00000F73:
    regs->ah = 0x2c;
    dos_int21(regs);  /* AH=2Ch: Get system time */
    MEM[0x424] = regs->cl;
    MEM[0x425] = regs->dx;
    regs->ax = regs->ds;
    MEM[0x43a] = regs->ax;
    MEM[0x43e] = regs->ax;
    MEM[0x436] = regs->ax;
    PUSH(regs->ax);
    regs->ax = MEM[0x2];
    MEM[0xdf3] = regs->ax;
    regs->ax = POP();
    func_00001E11(regs);
    PUSH(regs->es);
    func_00003AE2(regs);
    regs->es = POP();
    regs->di = 0x80;
    regs->cl = MEM[regs->di];
    regs->di++; UPDATE_FLAGS_INC();
    regs->ch = 0x0;
    if (regs->cx == 0) goto loc_00000FCB;
    DF = 0;
    PUSH(regs->cx);
    PUSH(regs->di);
    regs->al = 0x2f;
    STRING_SCAN_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->al = MEM[regs->di];
    regs->di = POP();
    regs->cx = POP();
    if (ZF) goto loc_00000FB9;
    regs->al = 0x2d;
    STRING_SCAN_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->al = MEM[regs->di];
    if (!ZF) goto loc_00000FCB;
loc_00000FB9:
    CMP(regs->al, 0x3f);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001001;
    regs->al |= 0x20; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00000FBF */
static const char str_00000FBF[] = "<zt><mt:<wt6";


/* Code block at 0x00000FCB */
void code_00000FCB(CPU_REGS *regs)
{
loc_00000FCB:
    PUSH(regs->ds);
    regs->ax = 0x1611;
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
    regs->ds = POP();
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00000FDB;
    TEST(regs->bl, 0x80);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00001032;
loc_00000FDB:
    regs->bx = 0x5bcd;
    regs->bl &= 0xf0; UPDATE_FLAGS_LOGIC();
    regs->sp = regs->bx;
    regs->bx >>= 0x4;
    MEM[0xdf3] = regs->bx;
    regs->ah = 0x4a;
    dos_int21(regs);  /* AH=4Ah: Resize memory block */
    regs->ax = 0x160a;
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
    regs->ax |= regs->ax; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_00001001;
    func_00001474(regs);
    func_00000241(regs);
    if (CF) goto loc_00000027;
loc_00001001:
    func_0000108E(regs);
    regs->ah = 0x48;
    regs->bx = 0xffff;
    dos_int21(regs);  /* AH=48h: Allocate memory */
    MEM[0x42c] = regs->bx;
    func_0000182B(regs);
    func_000016CB(regs);
    regs->sp = 0x7f0;
    regs->bx = MEM[0xdf1];
    regs->bx += 0xf; UPDATE_FLAGS_ADD();
    regs->bx >>= 0x4;
    regs->ax = MEM[0xdf3];
    regs->ax -= regs->bx; UPDATE_FLAGS_SUB();
    MEM[0x42c] += regs->ax; UPDATE_FLAGS_ADD();
    regs->ah = 0x4a;
    dos_int21(regs);  /* AH=4Ah: Resize memory block */
    goto loc_0000000C;
loc_00001032:
    PUSH(regs->es);
    func_00003AE2(regs);
    regs->es = POP();
    regs->ax = 0x42;
    func_000013D0(regs);
loc_0000103D:
    regs->ax = 0xc08;
    dos_int21(regs);  /* AH=0Ch: Flush buffer and read keyboard */
    CMP(regs->al, 0xd);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001070;
    CMP(regs->al, 0x1b);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001086;
    func_000009E8(regs);
    CMP(regs->al, 0x9);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001070;
    regs->dl = regs->al;
    regs->ax = 0x6523;
    dos_int21(regs);  /* AH=65h: Get extended country info */
    if (CF) goto loc_0000103D;
    TEST(regs->al, 0x2);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_0000103D;
    PUSH(regs->ax);
    regs->ah = 0x2;
    dos_int21(regs);  /* AH=02h: Write character to stdout */
    regs->ax = 0x68;
    func_000013D0(regs);
    regs->ax = POP();
    TEST(regs->al, regs->al);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_0000107D;
    goto loc_00001076;
loc_00001070:
    regs->ax = 0x66;
    func_000013D0(regs);
loc_00001076:
    regs->ax = 0; CF = 0; ZF = 1;
    regs->si = 0; CF = 0; ZF = 1;
    func_00001F2D(regs);
loc_0000107D:
    regs->ax = 0x43;
    func_000013D0(regs);
    goto loc_000013CB;
loc_00001086:
    regs->ax = 0x67;
    func_000013D0(regs);
    goto loc_0000107D;
}

/*
 * Function at 0x0000108E
 */
void func_0000108E(CPU_REGS *regs)
{
    MEM[0x0] = 0x0;
    func_00001D05(regs);
    if (!CF) goto loc_0000109C;
    goto loc_000013A0;
loc_0000109C:
    regs->ax = 0x64;
    regs->dh = 0x3;
    func_00003D99(regs);
    CMP(regs->cx, 0x32);  /* COMPARISON: Testing condition for branch */
    if (CF || ZF) goto loc_000010AF;
loc_000010A9:
    regs->ax = 0x63;
    goto loc_000013A0;
loc_000010AF:
    DF = 0;
    regs->di = 0x60b;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->ax = 0x6a;
    regs->dh = 0x3;
    func_00003D99(regs);
    CMP(regs->cx, 0x32);  /* COMPARISON: Testing condition for branch */
    if (!CF && !ZF) goto loc_000010A9;
    DF = 0;
    regs->di = 0x63d;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->ax = 0x8c;
    regs->dh = 0x3;
    func_00003D99(regs);
    CMP(regs->cx, 0x80);  /* COMPARISON: Testing condition for branch */
    if (!CF && !ZF) goto loc_000010A9;
    DF = 0;
    regs->di = 0x66f;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->cx = MEM[0x16];
    if (regs->cx == 0) goto loc_000010EE;
    PUSH(regs->es);
    regs->es = regs->cx;
    CMP(MEM[0x16], 0x0);
    regs->es = POP();
    if (!ZF) goto loc_000010F3;
loc_000010EE:
    func_000018CE(regs);
    goto loc_000010F9;
loc_000010F3:
    MEM[0xdf1] = 0x7f0;
loc_000010F9:
    func_0000192A(regs);
    if (!CF) goto loc_00001101;
    goto loc_000013A0;
loc_00001101:
    PUSH(regs->es);
    regs->ax = 0x70;
    regs->es = regs->ax;
    regs->es = MEM[0x108];
    regs->di = 0x5;
    regs->si = 0xed5;
    DF = 0;
    regs->cx = 0x29;
    STRING_CMP_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->es = POP();
    if (!ZF) goto loc_00001120;
    MEM[0x220] = 0xc3;
loc_00001120:
    func_00001CE6(regs);
    regs->cx = 0; CF = 0; ZF = 1;
    regs->di = 0x80;
    regs->cl = MEM[regs->di];
    TEST(regs->cx, regs->cx);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00001186;
    regs->cx++; UPDATE_FLAGS_INC();
    regs->di += regs->cx; UPDATE_FLAGS_ADD();
    regs->ax = 0x1611;
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
    DF = 0;
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_0000113E;
    goto loc_000011D7;
loc_0000113E:
    XCHG(regs->bx, regs->dx);
    PUSH(regs->ds);
    regs->es = POP();
    regs->bx--; UPDATE_FLAGS_DEC();
    PUSH(regs->cs);
    regs->ds = POP();
    TEST(regs->dl, 0x8);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000011B1;
    TEST(regs->dl, 0x4);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_000011B7;
    TEST(regs->dl, 0x1);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_000011C2;
    regs->ax = 0x46;
    func_000013D0(regs);
loc_0000115A:
    regs->ax = 0xc08;
    dos_int21(regs);  /* AH=0Ch: Flush buffer and read keyboard */
    TEST(regs->al, regs->al);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00001171;
    regs->ah = 0x8;
    dos_int21(regs);  /* AH=08h: Character input without echo */
    CMP(regs->al, 0x3f);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001188;
    CMP(regs->al, 0x58);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001188;
    goto loc_0000115A;
loc_00001171:
    CMP(regs->al, 0xd);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001180;
    CMP(regs->al, 0x1b);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001188;
    func_000009E8(regs);
    CMP(regs->al, 0x9);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001190;
loc_00001180:
    regs->ax = 0x66;
    func_000013D0(regs);
loc_00001186:
    goto loc_000011D7;
loc_00001188:
    regs->ax = 0x67;
    func_000013D0(regs);
    goto loc_000011AD;
loc_00001190:
    regs->dl = regs->al;
    regs->ax = 0x6523;
    dos_int21(regs);  /* AH=65h: Get extended country info */
    if (CF) goto loc_0000115A;
    TEST(regs->al, 0x2);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_0000115A;
    PUSH(regs->ax);
    regs->ah = 0x2;
    dos_int21(regs);  /* AH=02h: Write character to stdout */
    regs->ax = 0x68;
    func_000013D0(regs);
    regs->ax = POP();
    TEST(regs->al, regs->al);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_000011D7;
loc_000011AD:
    MEM[regs->bx] |= 0x1; UPDATE_FLAGS_LOGIC();
loc_000011B1:
    TEST(MEM[regs->bx], 0x4);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000011BC;
loc_000011B7:
    regs->si = 0xebe;
    goto loc_000011C9;
loc_000011BC:
    TEST(MEM[regs->bx], 0x1);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000011D7;
loc_000011C2:
    MEM[regs->bx] &= 0xf7; UPDATE_FLAGS_LOGIC();
    regs->si = 0xeb9;
loc_000011C9:
    CMP(regs->di, 0x81);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000011D7;
    PUSH(regs->ds);
    regs->es = POP();
    regs->cx = 0x5;
    func_00001ECB(regs);
loc_000011D7:
    PUSH(regs->ds);
    regs->es = POP();
    regs->cx = 0; CF = 0; ZF = 1;  /* ZERO CX: XOR with itself = 0 */
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
    regs->si = 0x80;
    STRING_LOAD_BYTE(regs);
    regs->cl = regs->al;
    CMP(regs->cl, 0x0);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000011EB;
    goto loc_0000135B;
loc_000011EB:
    STRING_LOAD_BYTE(regs);
    regs->cx--; UPDATE_FLAGS_DEC();
    if (!ZF) goto loc_000011F2;
    goto loc_0000135B;
loc_000011F2:
    CMP(regs->al, 0x20);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000011EB;
    CMP(regs->al, 0x9);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000011EB;
    CMP(regs->al, 0x2d);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001205;
    CMP(regs->al, 0x2f);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001205;
    goto loc_0000135B;
loc_00001205:
    STRING_LOAD_BYTE(regs);
    regs->cx--; UPDATE_FLAGS_DEC();
    regs->al |= 0x20; UPDATE_FLAGS_LOGIC();
    CMP(regs->al, 0x6e);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_0000122A;
    CMP(regs->al, 0x6c);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_0000122A;
    CMP(regs->al, 0x65);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_0000122A;
    CMP(regs->al, 0x72);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001231;
    CMP(regs->al, 0x73);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001231;
    CMP(regs->al, 0x61);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001237;
    MEM[0x60a]++; UPDATE_FLAGS_INC();
    MEM[0x213] = 0xf4;
loc_0000122A:
    MEM[regs->si - 0x2] = 0x2020;
    goto loc_000011EB;
loc_00001231:
    regs->ax = 0x1e;
    goto loc_000013A0;
loc_00001237:
    CMP(regs->al, 0x7a);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_0000123E;
    goto loc_0000130D;
loc_0000123E:
    func_00001DA9(regs);
    regs->dx |= regs->dx; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_0000122A;
    func_00004099(regs);
    PUSH(regs->ds);
    regs->es = POP();
    if (CF) goto loc_00001251;
    MEM[0xed1] = 0x0;
loc_00001251:
    func_0000011C(regs);
    regs->ax = 0x201;
    regs->bx = 0x3fbe;
    regs->cx = 0x1;
    regs->dx = 0x80;
    bios_disk_int(regs);  /* AH=02h: Read sectors */
    regs->ax = 0x5300;
    regs->bx = 0; CF = 0; ZF = 1;  /* ZERO BX: XOR with itself = 0 */
    bios_misc_int(regs);
    if (!CF) goto loc_0000126E;
    goto loc_0000130A;
loc_0000126E:
    CMP(regs->bx, 0x504d);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001277;
    goto loc_0000130A;
loc_00001277:
    CMP(regs->ax, 0x101);  /* COMPARISON: Testing condition for branch */
    if (!CF) goto loc_0000127F;
    goto loc_0000130A;
loc_0000127F:
    PUSH(regs->cx);
    MEM[0xed3] = regs->ax;
    regs->ax = 0x5400;
    regs->bx = 0; CF = 0; ZF = 1;  /* ZERO BX: XOR with itself = 0 */
    dos_multiplex_int(regs);  /* AH=54h: Unknown multiplex function 0x54 */
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
    CMP(regs->bx, 0x504d);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_0000129F;
    PUSH(regs->ax);
    regs->ax = 0x5401;
    regs->bx = 0x100;
    dos_multiplex_int(regs);  /* AH=54h: Unknown multiplex function 0x54 */
    regs->ax = POP();
    if (CF) goto loc_0000129F;
    regs->ax++; UPDATE_FLAGS_INC();
loc_0000129F:
    regs->cx = POP();
    PUSH(regs->ax);
    PUSH(regs->bx);
    PUSH(regs->cx);
    regs->ax = 0x5301;
    regs->bx = 0; CF = 0; ZF = 1;  /* ZERO BX: XOR with itself = 0 */
    bios_misc_int(regs);
    regs->ax = 0x530e;
    regs->bx = 0; CF = 0; ZF = 1;  /* ZERO BX: XOR with itself = 0 */
    regs->cx = 0x101;
    bios_misc_int(regs);
    regs->ax = 0x530f;
    regs->bx = 0x1;
    regs->cx = regs->bx;
    bios_misc_int(regs);
    regs->ax = 0x5308;
    regs->bx = 0x1;
    regs->cx = regs->bx;
    bios_misc_int(regs);
    regs->ax = 0x5307;
    regs->bx = 0x1;
    regs->cx = 0x3;
    bios_misc_int(regs);
    regs->cx = POP();
    TEST(regs->cl, 0x8);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000012E5;
    PUSH(regs->cx);
    regs->ax = 0x5308;
    regs->bx = 0x1;
    regs->cx = 0; CF = 0; ZF = 1;  /* ZERO CX: XOR with itself = 0 */
    bios_misc_int(regs);
    regs->cx = POP();
loc_000012E5:
    TEST(regs->cl, 0x10);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000012F4;
    regs->ax = 0x530f;
    regs->bx = 0x1;
    regs->cx = 0; CF = 0; ZF = 1;  /* ZERO CX: XOR with itself = 0 */
    bios_misc_int(regs);
loc_000012F4:
    regs->ax = 0x5304;
    regs->bx = 0; CF = 0; ZF = 1;  /* ZERO BX: XOR with itself = 0 */
    bios_misc_int(regs);
    regs->bx = POP();
    regs->ax = POP();
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_0000130A;
    regs->ax = 0x5401;
    regs->bl = regs->bh;
    regs->bh = 0x1;
    dos_multiplex_int(regs);  /* AH=54h: Unknown multiplex function 0x54 */
loc_0000130A:
    goto loc_000013BA;
loc_0000130D:
    CMP(regs->al, 0x6d);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001319;
    regs->ax = 0x1;
    func_00001F2D(regs);
    goto loc_0000135B;
loc_00001319:
    CMP(regs->al, 0x77);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001324;
    regs->ax = 0; CF = 0; ZF = 1;
    func_00001F2D(regs);
    goto loc_0000135B;
loc_00001324:
    regs->si--; UPDATE_FLAGS_DEC();
    STRING_LOAD_BYTE(regs);
    CMP(regs->al, 0x32);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_0000132D;
    goto loc_00001231;
loc_0000132D:
    CMP(regs->al, 0x33);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001334;
    goto loc_0000122A;
loc_00001334:
    CMP(regs->al, 0x3f);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_0000135B;
    func_00001DA9(regs);
    regs->dx |= regs->dx; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001351;
    MEM[0xed1] = 0x3;
    func_000019A8(regs);
    if (CF) goto loc_0000134C;
    func_0000190B(regs);
loc_0000134C:
    regs->ax = 0x1f;
    goto loc_000013A0;
loc_00001351:
    regs->ax = 0x1f;
    MEM[0xed1] = 0x5;
    goto loc_000013A0;
loc_0000135B:
    func_00001DA9(regs);
    regs->dx |= regs->dx; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_00001389;
    regs->ax = regs->dx;
    regs->dh = 0x3;
    func_00003D99(regs);
    regs->dx = regs->si;
    regs->ah = 0x9;
    dos_int21(regs);  /* AH=09h: Write string to stdout */
    CMP(regs->ax, 0x41);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001382;
    regs->ax = 0x3d;
    regs->dh = 0x3;
    func_00003D99(regs);
    regs->dx = regs->si;
    regs->ah = 0x9;
    dos_int21(regs);  /* AH=09h: Write string to stdout */
loc_00001382:
    MEM[0xed1] = 0x0;
    goto loc_000013BA;
loc_00001389:
    regs->ax = 0x4b21;
    dos_multiplex_int(regs);  /* AH=4Bh: Task switcher */
    TEST(regs->ah, regs->ah);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00001399;
    CMP(regs->al, 0x1);
    regs->ax = 0x47;
    if (!CF && !ZF) goto loc_000013A0;
loc_00001399:
    func_0000190B(regs);
    if (CF) goto loc_000013A0;
    goto loc_000013DE;
loc_000013A0:
    CMP(regs->ax, 0x1f);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000013B7;
    regs->ax = 0x1f;
    regs->bx = 0x2d;
loc_000013AB:
    PUSH(regs->ax);
    func_000013D0(regs);
    regs->ax = POP();
    regs->ax++; UPDATE_FLAGS_INC();
    CMP(regs->ax, regs->bx);  /* COMPARISON: Testing condition for branch */
    if (ZF || SF != OF) goto loc_000013AB;
    goto loc_000013BA;
loc_000013B7:
    func_000013D0(regs);
loc_000013BA:
    regs->ax = regs->ds;
    CMP(regs->ax, MEM[0x16]);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000013CB;
    regs->ax = 0x69;
    func_000013D0(regs);
    goto loc_0000010C;
loc_000013CB:
    regs->ax = MEM[0xed1];
    dos_int21(regs);
}

/*
 * Function at 0x000013D0
 */
void func_000013D0(CPU_REGS *regs)
{
    PUSH(regs->ds);
    regs->dh = 0x3;
    func_00003D99(regs);
    regs->dx = regs->si;
    regs->ah = 0x9;
    dos_int21(regs);  /* AH=09h: Write string to stdout */
    regs->ds = POP();
    return;
loc_000013DE:
    regs->si = 0x81;
loc_000013E1:
    STRING_LOAD_BYTE(regs);
    CMP(regs->al, 0x20);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000013E1;
    CMP(regs->al, 0x9);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000013E1;
    CMP(regs->al, 0xd);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000013F3;
    MEM[0xecf] = 0x0;
loc_000013F3:
    regs->di |= byte -0x1; UPDATE_FLAGS_LOGIC();
    regs->ax = 0x5500;
    dos_multiplex_int(regs);  /* AH=55h: Unknown multiplex function 0x55 */
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00001416;
    CMP(regs->di, byte -0x1);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001416;
    LOAD_FAR_PTR(&regs->ds, &regs->di, MEM[regs->di]);
    PUSH(regs->cs);
    PUSH(0x150d);
    PUSH(regs->ds);
    PUSH(regs->di);
    return; /* far */
    PUSH(regs->cs);
    regs->ds = POP();
    MEM[0x16] = regs->ds;
    func_000018CE(regs);
loc_00001416:
    regs->ax = regs->cs;
    regs->ds = regs->ax;
    regs->es = regs->ax;
    func_000041E1(regs);
    regs->ax = 0x4b21;
    dos_multiplex_int(regs);  /* AH=4Bh: Task switcher */
    TEST(regs->ah, regs->ah);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_0000142C;
    MEM[0x42e] += regs->ax; UPDATE_FLAGS_ADD();
loc_0000142C:
    PUSH(regs->es);
    regs->ax = 0x352f;
    dos_int21(regs);  /* AH=35h: Get interrupt vector */
    MEM[0x44b] = regs->bx;
    MEM[0x44d] = regs->es;
    regs->ax = 0x252f;
    regs->dx = 0x3f6;
    dos_int21(regs);  /* AH=25h: Set interrupt vector */
    regs->ax = 0x3513;
    dos_int21(regs);  /* AH=35h: Get interrupt vector */
    MEM[0x441] = regs->bx;
    MEM[0x443] = regs->es;
    regs->ax = 0x2513;
    regs->dx = 0x440;
    dos_int21(regs);  /* AH=25h: Set interrupt vector */
    regs->ax = 0x3521;
    dos_int21(regs);  /* AH=35h: Get interrupt vector */
    MEM[0x446] = regs->bx;
    MEM[0x448] = regs->es;
    regs->ax = 0x2521;
    regs->dx = 0x445;
    dos_int21(regs);  /* AH=25h: Set interrupt vector */
    regs->es = POP();
    func_00001D3A(regs);
    return;
    regs->al = 0x3;
    IRET(); return;
}

/*
 * Function at 0x00001474
 */
void func_00001474(CPU_REGS *regs)
{
    PUSH(regs->es);
    regs->ax = 0x3524;
    dos_int21(regs);  /* AH=35h: Get interrupt vector */
    MEM[0x1037] = regs->bx;
    MEM[0x1039] = regs->es;
    regs->dx = 0x1571;
    regs->ax = 0x2524;
    dos_int21(regs);  /* AH=25h: Set interrupt vector */
    regs->ax = 0x5200;
    dos_int21(regs);  /* AH=52h: Get DOS internal pointers */
    TEST(MEM[regs->bx + 0x60], 0x80);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00001499;
    goto loc_000016BE;
loc_00001499:
    TEST(MEM[regs->bx + 0x60], 0x2);
    PUSH(regs->ds);
    regs->es = POP();
    if (ZF) goto loc_000014A6;
    MEM[0xfea]++; UPDATE_FLAGS_INC();
loc_000014A6:
    PUSH(regs->es);
    LOAD_FAR_PTR(&regs->es, &regs->di, MEM[0x428]);
    CMP(MEM[regs->di + 0x1], 0x3a);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000014C8;
    regs->al = MEM[regs->di];
    regs->al |= 0x20; UPDATE_FLAGS_LOGIC();
    regs->al -= 0x61; UPDATE_FLAGS_SUB();
    if (CF) goto loc_000014C8;
    CMP(regs->al, 0x19);  /* COMPARISON: Testing condition for branch */
    if (!CF && !ZF) goto loc_000014C8;
    CMP(regs->al, 0x2);  /* COMPARISON: Testing condition for branch */
    if (CF) goto loc_000014C8;
    regs->al++; UPDATE_FLAGS_INC();
    MEM[0xfe9] = regs->al;
loc_000014C8:
    regs->es = POP();
    regs->bx = 0x3;
loc_000014CC:
    regs->ax = 0x4409;
    dos_int21(regs);  /* AH=44h: I/O control */
    if (!CF) goto loc_000014D6;
    goto loc_00001614;
loc_000014D6:
    TEST(regs->dx, 0x1000);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000014DF;
    goto loc_00001614;
loc_000014DF:
    CMP(regs->bl, MEM[0xfe9]);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000014F6;
    regs->ax = 0x4408;
    dos_int21(regs);  /* AH=44h: I/O control */
    if (!CF) goto loc_000014EF;
    goto loc_00001614;
loc_000014EF:
    regs->ax |= regs->ax; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_000014F6;
    goto loc_00001614;
loc_000014F6:
    regs->ax = 0x7302;
    regs->dl = regs->bl;
    regs->cx = 0x42;
    regs->di = 0xfeb;
    dos_int21(regs);  /* AH=73h: Unknown DOS function 0x73 */
    if (!CF) goto loc_00001508;
    goto loc_00001614;
loc_00001508:
    regs->di = regs->di + 0x2;
    PUSH(regs->bx);
    PUSH(regs->dx);
    CMP(MEM[regs->di + 0x2d], 0xff6);  /* COMPARISON: Testing condition for branch */
    if (!CF) goto loc_0000151A;
    goto loc_00001612;
loc_0000151A:
    regs->bx = MEM[regs->di + 0x2];
    regs->bx |= regs->bx; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001524;
    goto loc_00001612;
loc_00001524:
    regs->bx += 0xf; UPDATE_FLAGS_ADD();
    regs->bx >>= 0x4;
    regs->ax = 0x4800;
    dos_int21(regs);  /* AH=48h: Allocate memory */
    if (!CF) goto loc_00001534;
    goto loc_00001612;
loc_00001534:
    MEM[0x1035] = regs->ax;
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
    MEM[0x1033] = regs->ax;
    MEM[0x102f] = regs->ax;
    MEM[0x1031] = 0x1;
    regs->ax = MEM[regs->di + 0x6];
    regs->ax |= regs->ax; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_0000154F;
    goto loc_00001607;
loc_0000154F:
    MEM[0x102d] = regs->ax;
    CMP(MEM[regs->di + 0xf], 0x0);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001577;
    TEST(MEM[regs->di + 0x23], 0x80);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00001577;
    TEST(MEM[regs->di + 0x23], 0xf);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00001577;
    regs->eax = (uint32_t)MEM[regs->di + 0x23];
    regs->ax &= 0xf; UPDATE_FLAGS_LOGIC();
    MUL_UNSIGNED(MEM[regs->di + 0x31]);
    MEM[0x102d] += regs->eax; UPDATE_FLAGS_ADD();
loc_00001577:
    regs->si = 0xfe3;
    MEM[regs->si] = regs->dl;
    MEM[regs->si] += 0x40; UPDATE_FLAGS_ADD();
    regs->di = 0x6ef;
    regs->ax = 0x6000;
    dos_int21(regs);  /* AH=60h: Canonicalize filename */
    if (!CF) goto loc_00001593;
    regs->ax = MEM[regs->si];
    MEM[regs->di] = regs->ax;
    regs->ax = MEM[regs->si + 0x2];
    MEM[regs->di + 0x2] = regs->ax;
loc_00001593:
    CMP(MEM[regs->di + 0x1], 0x3a);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_0000159F;
    CMP(MEM[regs->di + 0x2], 0x2f);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000015A2;
loc_0000159F:
    MEM[regs->di] = 0x0;
loc_000015A2:
    regs->al = MEM[regs->si];
    CMP(regs->al, MEM[regs->di]);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001607;
    regs->ax = 0x5601;
    regs->bl = regs->dl;
    regs->bl--; UPDATE_FLAGS_DEC();
    XCHG(regs->bh, regs->bl);
    PUSH(regs->dx);
    regs->dx = 0xffff;
    dos_multiplex_int(regs);  /* AH=56h: Unknown multiplex function 0x56 */
    regs->dx = POP();
    CMP(regs->al, 0xff);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001607;
    regs->bx = 0x102d;
    regs->cx = 0xffff;
    regs->si = 0; CF = 0; ZF = 1;  /* ZERO SI: XOR with itself = 0 */
    regs->ax = 0x7305;
    dos_int21(regs);  /* AH=73h: Unknown DOS function 0x73 */
    if (CF) goto loc_00001607;
    PUSH(regs->es);
    LOAD_FAR_PTR(&regs->es, &regs->si, MEM[0x1033]);
    regs->di = 0xfed;
    CMP(MEM[regs->di + 0xf], 0x0);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000015DF;
    regs->al = MEM[regs->si + 0x3];
    goto loc_000015E6;
loc_000015DF:
    regs->al = MEM[regs->si + 0x7];
    regs->al <<= 0x4;
loc_000015E6:
    TEST(regs->al, 0x80);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_000015F8;
    MEM[0xfe7]++; UPDATE_FLAGS_INC();
    TEST(regs->al, 0x40);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00001600;
    MEM[0xfe8]++; UPDATE_FLAGS_INC();
    goto loc_00001600;
loc_000015F8:
    TEST(regs->al, 0x40);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00001606;
    MEM[0xfe8]++; UPDATE_FLAGS_INC();
loc_00001600:
    regs->es = POP();
    func_0000181A(regs);
    goto loc_00001607;
loc_00001606:
    regs->es = POP();
loc_00001607:
    PUSH(regs->es);
    regs->es = MEM[0x1035];
    regs->ax = 0x4900;
    dos_int21(regs);  /* AH=49h: Free memory */
    regs->es = POP();
loc_00001612:
    regs->dx = POP();
    regs->bx = POP();
loc_00001614:
    regs->bx++; UPDATE_FLAGS_INC();
    CMP(regs->bx, 0x1a);  /* COMPARISON: Testing condition for branch */
    if (!CF && !ZF) goto loc_0000161D;
    goto loc_000014CC;
loc_0000161D:
    CMP(MEM[0xfe8], 0x0);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_0000162D;
    regs->si = 0xfd9;
    regs->cx = 0x9;
    func_00001808(regs);
loc_0000162D:
    regs->al = MEM[0xfe7];
    regs->al |= MEM[0xfe8]; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001639;
    goto loc_000016BE;
loc_00001639:
    CMP(MEM[0xfe7], 0x0);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_0000165C;
    regs->ax = 0x2f;
    CMP(MEM[0xfea], 0x0);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_0000165C;
    func_000013D0(regs);
    regs->dl = 0x7;
    regs->ah = 0x2;
    dos_int21(regs);  /* AH=02h: Write character to stdout */
    func_00002180(regs);
    regs->ax = 0x68;
    func_000013D0(regs);
loc_0000165C:
    regs->bx = 0xf41;
    func_00001B33(regs);
    if (!CF) goto loc_00001691;
    CMP(MEM[0xf4a], 0x4c41);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001677;
    MEM[0xf4a] = 0x455845;
    goto loc_0000165C;
loc_00001677:
    CMP(MEM[0xfe7], 0x0);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000016BE;
    regs->ax = 0x30;
    func_000013D0(regs);
    regs->ax = 0xc08;
    dos_int21(regs);  /* AH=0Ch: Flush buffer and read keyboard */
    regs->ax = 0x68;
    func_000013D0(regs);
    goto loc_000016BE;
loc_00001691:
    regs->dx = 0x6ef;
    regs->di = 0xf4e;
    regs->si = 0; CF = 0; ZF = 1;
    func_0000027A(regs);
    if (CF) goto loc_000016A6;
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_000016BE;
    CMP(regs->al, 0xfe);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000016BE;
loc_000016A6:
    CMP(MEM[0xfe7], 0x0);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000016BE;
    regs->ax = 0x31;
    func_000013D0(regs);
    regs->ax = 0xc08;
    dos_int21(regs);  /* AH=0Ch: Flush buffer and read keyboard */
    regs->ax = 0x68;
    func_000013D0(regs);
loc_000016BE:
    PUSH(regs->ds);
    LOAD_FAR_PTR(&regs->ds, &regs->dx, MEM[0x1037]);
    regs->ax = 0x2524;
    dos_int21(regs);  /* AH=25h: Set interrupt vector */
    regs->ds = POP();
    regs->es = POP();
    return;
}

/*
 * Function at 0x000016CB
 */
void func_000016CB(CPU_REGS *regs)
{
    PUSH(regs->es);
    PUSH(regs->ds);
    regs->ax = 0x1611;
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
    regs->ds = POP();
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_000016DC;
    TEST(regs->bl, 0x7);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00001714;
loc_000016DC:
    regs->cx = 0x8;
    regs->si = 0xefe;
    regs->di = 0xe0a;
    func_000002B8(regs);
    regs->dx = 0xe0a;
    func_00001752(regs);
    regs->ax |= regs->ax; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001714;
    PUSH(regs->ds);
    regs->es = POP();
    regs->di = 0xe0a;
    regs->cx = 0x50;
    regs->ax = 0x1613;
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
    regs->ax |= regs->ax; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001714;
    regs->dx = 0xe0a;
    func_00001752(regs);
    regs->ax |= regs->ax; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001714;
    func_000017B1(regs);
    regs->ax |= regs->ax; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_00001736;
loc_00001714:
    regs->cx = 0x13;
    regs->si = 0xf12;
    regs->di = 0xe0a;
    func_000002B8(regs);
    regs->dx = 0xe0a;
    regs->di = 0xf31;
    TEST(MEM[0x184c], 0x80);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00001731;
    regs->di = 0xf26;
loc_00001731:
    regs->si = 0; CF = 0; ZF = 1;
    func_0000027A(regs);
loc_00001736:
    regs->es = POP();
    return;
}

/* Zero-initialized data at 0x00001738 (26 bytes) */
static uint8_t data_00001738[26] = {0};

/*
 * Function at 0x00001752
 */
void func_00001752(CPU_REGS *regs)
{
    PUSH(regs->dx);
    MEM[0x1838] = 0xffff;
    regs->ax = 0x3d00;
    dos_int21(regs);  /* AH=3Dh: Open file */
    if (CF) goto loc_00001788;
    MEM[0x1838] = regs->ax;
    regs->bx = MEM[0x1838];
    regs->cx = 0x18;
    regs->dx = 0x183a;
    regs->ah = 0x3f;
    dos_int21(regs);  /* AH=3Fh: Read from file/device */
    if (CF) goto loc_00001788;
    CMP(regs->ax, 0x18);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001788;
    CMP(MEM[0x183a], 0x5243);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001788;
    CMP(MEM[0x183c], 0x4745);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001794;
loc_00001788:
    MEM[0x184c] = 0x8;
    MEM[0x184c] = 0x0;
loc_00001794:
    regs->bx = MEM[0x1838];
    CMP(regs->bx, byte -0x1);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000017A1;
    regs->ah = 0x3e;
    dos_int21(regs);  /* AH=3Eh: Close file */
loc_000017A1:
    regs->ax = 0x1;
    TEST(MEM[0x184c], 0xd8);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_000017AF;
    regs->ax = 0x0;
loc_000017AF:
    regs->dx = POP();
    return;
}

/*
 * Function at 0x000017B1
 */
void func_000017B1(CPU_REGS *regs)
{
    PUSH(regs->dx);
    MEM[0x1838] = 0xffff;
    regs->cx = 0x2;
    regs->ax = 0x4301;
    dos_int21(regs);  /* AH=43h: Get/set file attributes */
    if (CF) goto loc_000017EB;
    regs->ax = 0x3d01;
    dos_int21(regs);  /* AH=3Dh: Open file */
    if (CF) goto loc_000017EB;
    MEM[0x1838] = regs->ax;
    MEM[0x184c] |= 0x40; UPDATE_FLAGS_LOGIC();
    regs->bx = MEM[0x1838];
    regs->cx = 0x18;
    regs->dx = 0x183a;
    regs->ah = 0x40;
    dos_int21(regs);  /* AH=40h: Write to file/device */
    if (CF) goto loc_000017EB;
    CMP(regs->ax, 0x18);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000017EB;
    regs->dx = 0x0;
    goto loc_000017EE;
loc_000017EB:
    regs->dx = 0x1;
loc_000017EE:
    regs->bx = MEM[0x1838];
    CMP(regs->bx, byte -0x1);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001804;
    regs->ah = 0x68;
    dos_int21(regs);  /* AH=68h: Commit file */
    if (!CF) goto loc_00001800;
    regs->dx = 0x1;
loc_00001800:
    regs->ah = 0x3e;
    dos_int21(regs);  /* AH=3Eh: Close file */
loc_00001804:
    regs->ax = regs->dx;
    regs->dx = POP();
    return;
}

/*
 * Function at 0x00001808
 */
void func_00001808(CPU_REGS *regs)
{
    regs->di = 0xf4e;
    MEM[regs->di] += regs->cl; UPDATE_FLAGS_ADD();
    regs->di++; UPDATE_FLAGS_INC();
loc_0000180E:
    CMP(MEM[regs->di], 0xd);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001816;
    regs->di++; UPDATE_FLAGS_INC();
    goto loc_0000180E;
loc_00001816:
    DF = 0;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    return;
}

/*
 * Function at 0x0000181A
 */
void func_0000181A(CPU_REGS *regs)
{
    regs->si = 0xfe2;
    MEM[regs->si + 0x1] = regs->dl;
    MEM[regs->si + 0x1] += 0x40; UPDATE_FLAGS_ADD();
    regs->cx = 0x3;
    func_00001808(regs);
    return;
}

/*
 * Function at 0x0000182B
 */
void func_0000182B(CPU_REGS *regs)
{
    PUSH(regs->es);
    regs->ah = 0x8;
    func_00001D13(regs);
    if (!CF) goto loc_00001836;
    goto loc_000018CC;
loc_00001836:
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_0000183D;
    goto loc_000018CC;
loc_0000183D:
    CMP(regs->dx, 0x1c00);  /* COMPARISON: Testing condition for branch */
    if (!CF) goto loc_00001846;
    goto loc_000018CC;
loc_00001846:
    PUSH(regs->ds);
    regs->ax = 0x1611;
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
    regs->ds = POP();
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00001856;
    TEST(regs->bl, 0x7);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_000018CC;
loc_00001856:
    regs->ax = 0x4a10;
    regs->bx = 0; CF = 0; ZF = 1;  /* ZERO BX: XOR with itself = 0 */
    regs->bp = 0; CF = 0; ZF = 1;  /* ZERO BP: XOR with itself = 0 */
    dos_multiplex_int(regs);  /* AH=4Ah: HMA */
    TEST(regs->bp, regs->bp);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_000018CC;
    regs->ax = 0x4a11;
    regs->bx = 0; CF = 0; ZF = 1;  /* ZERO BX: XOR with itself = 0 */
    dos_multiplex_int(regs);  /* AH=4Ah: HMA */
    CMP(regs->ax, 0x444d);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_000018CC;
    regs->bx = 0xffff;
    regs->ah = 0x48;
    dos_int21(regs);  /* AH=48h: Allocate memory */
    CMP(regs->bx, 0x6000);  /* COMPARISON: Testing condition for branch */
    if (CF) goto loc_000018CC;
    regs->bx -= 0x1800; UPDATE_FLAGS_SUB();
    regs->ah = 0x48;
    dos_int21(regs);  /* AH=48h: Allocate memory */
    if (CF) goto loc_000018CC;
    PUSH(regs->ax);
    regs->ax = 0xcdcd;
    regs->di = regs->ds;
    regs->ds = POP();
    PUSH(regs->ds);
    regs->bx = 0; CF = 0; ZF = 1;  /* ZERO BX: XOR with itself = 0 */
    regs->dx = 0; CF = 0; ZF = 1;  /* ZERO DX: XOR with itself = 0 */
    regs->cx = 0x1;
    MEM[regs->bx] = regs->bx;
    software_interrupt_0x25(regs);
    regs->cx = POP();
    CMP(MEM[regs->bx], 0xcdcd);
    regs->ds = regs->di;
    if (ZF) goto loc_000018C7;
    regs->cx = 0xc;
    regs->si = 0xe62;
    regs->di = 0xe0a;
    func_000002B8(regs);
    regs->dl = 0x1;
    regs->ax = 0x1231;
    dos_multiplex_int(regs);  /* AH=12h: DOS internal */
    regs->dx = 0xe0a;
    regs->di = 0xe6f;
    regs->si = 0; CF = 0; ZF = 1;
    func_0000027A(regs);
    regs->dl = 0x2;
    regs->ax = 0x1231;
    dos_multiplex_int(regs);  /* AH=12h: DOS internal */
loc_000018C7:
    regs->es = POP();
    regs->ah = 0x49;
    dos_int21(regs);  /* AH=49h: Free memory */
loc_000018CC:
    regs->es = POP();
    return;
}

/*
 * Function at 0x000018CE
 */
void func_000018CE(CPU_REGS *regs)
{
    MEM[0x16] = regs->ds;
    regs->di = 0xaf1;
    MEM[0xdf1] = regs->di;
    regs->bp = 0x7f0;
    regs->dl = 0x24;
loc_000018DE:
    regs->ax = MEM[regs->bp + 0x0];
    regs->dh = 0x3;
    func_00003D99(regs);
    regs->ax = regs->di;
    regs->ax += regs->cx; UPDATE_FLAGS_ADD();
    CMP(regs->ax, 0xdf1);  /* COMPARISON: Testing condition for branch */
    if (CF || ZF) goto loc_000018F2;
    goto loc_000010A9;
loc_000018F2:
    MEM[regs->bp + 0x0] = regs->di;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->bp += 0x2; UPDATE_FLAGS_ADD();
    regs->dl--; UPDATE_FLAGS_DEC();
    if (!ZF) goto loc_000018DE;
    MEM[0xdf1] = regs->di;
    regs->ax = 0x2524;
    regs->dx = 0x85d;
    dos_int21(regs);  /* AH=25h: Set interrupt vector */
    return;
}

/*
 * Function at 0x0000190B
 */
void func_0000190B(CPU_REGS *regs)
{
    func_00001D85(regs);
    CMP(regs->ax, 0x386);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001925;
    func_0000193F(regs);
    if (CF) goto loc_00001929;
    regs->bx = 0xdf9;
    func_00001B33(regs);
    if (!CF) goto loc_00001929;
    regs->ax = 0x16;
    goto loc_00001929;
loc_00001925:
    CF = 1;
    regs->ax = 0x14;
loc_00001929:
    return;
}

/*
 * Function at 0x0000192A
 */
void func_0000192A(CPU_REGS *regs)
{
    CF = 0;
    regs->ax = MEM[0x2];
    regs->bx = regs->cs;
    regs->ax -= regs->bx; UPDATE_FLAGS_SUB();
    CMP(regs->ax, 0x53c0);  /* COMPARISON: Testing condition for branch */
    if (CF) goto loc_0000193A;
    goto loc_0000193E;
loc_0000193A:
    CF = 1;
    regs->ax = 0x1a;
loc_0000193E:
    return;
}

/*
 * Function at 0x0000193F
 */
void func_0000193F(CPU_REGS *regs)
{
    PUSH(regs->bx);
    regs->ah = 0x0;
    func_00001D13(regs);
    if (CF) goto loc_0000195B;
    regs->ax |= regs->ax; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_0000195B;
    CMP(regs->ah, 0x2);  /* COMPARISON: Testing condition for branch */
    if (CF) goto loc_00001961;
    if (!CF && !ZF) goto loc_00001958;
    CMP(regs->bx, 0x228);  /* COMPARISON: Testing condition for branch */
    if (CF) goto loc_00001961;
loc_00001958:
    CF = 0;
    goto loc_00001965;
loc_0000195B:
    regs->ax = 0x18;
    CF = 1;
    goto loc_00001965;
loc_00001961:
    regs->ax = 0x17;
    CF = 1;
loc_00001965:
    regs->bx = POP();
    return;
}

/* String data at 0x00001967 */
static const char str_00001967[] = "PSQRVW";


/* Code at 0x0000196D */
void code_0000196D(CPU_REGS *regs)
{
    PUSH(regs->es);
    PUSH(regs->ds);
    PUSH(regs->flags);
    regs->ax = 0x1605;
    regs->bx = 0; CF = 0; ZF = 1;  /* ZERO BX: XOR with itself = 0 */
    regs->si = regs->bx;
    regs->es = regs->bx;
    regs->ds = regs->bx;
    regs->di = 0x30a;
    regs->cx = regs->bx;
    regs->dx = regs->bx;
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
    regs->flags = POP();
    regs->ds = POP();
    regs->es = POP();
}

/* String data at 0x00001987 */
static const char str_00001987[] = "_^ZY[X";


/* Code at 0x0000198D */
void code_0000198D(CPU_REGS *regs)
{
    return;
}

/* String data at 0x0000198E */
static const char str_0000198E[] = "PSQRVW";


/* Code at 0x00001994 */
void code_00001994(CPU_REGS *regs)
{
    PUSH(regs->es);
    PUSH(regs->ds);
    PUSH(regs->flags);
    regs->ax = 0x1606;
    regs->dx = 0; CF = 0; ZF = 1;  /* ZERO DX: XOR with itself = 0 */
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
    regs->flags = POP();
    regs->ds = POP();
    regs->es = POP();
}

/* String data at 0x000019A1 */
static const char str_000019A1[] = "_^ZY[X";


/* Code at 0x000019A7 */
void code_000019A7(CPU_REGS *regs)
{
    return;
}

/*
 * Function at 0x000019A8
 */
void func_000019A8(CPU_REGS *regs)
{
    MEM[0xed0] = 0x0;
    func_00001A47(regs);
    if (CF) goto loc_000019E3;
    regs->dx += regs->cx; UPDATE_FLAGS_ADD();
    CMP(regs->dx, 0x400);  /* COMPARISON: Testing condition for branch */
    if (!CF) goto loc_000019D6;
    MEM[0xed0] = 0x1;
    func_00001A47(regs);
    regs->dx += regs->cx; UPDATE_FLAGS_ADD();
    CMP(regs->dx, 0x400);  /* COMPARISON: Testing condition for branch */
    if (!CF) goto loc_000019D6;
    func_00001A86(regs);
    if (CF) goto loc_000019E3;
    regs->ax += regs->dx; UPDATE_FLAGS_ADD();
    CMP(regs->ax, 0x400);  /* COMPARISON: Testing condition for branch */
    if (CF) goto loc_000019E3;
loc_000019D6:
    func_00001AEF(regs);
    if (!CF) goto loc_000019DE;
    CF = 0;
    goto loc_000019E4;
loc_000019DE:
    func_000019E5(regs);
    if (!CF) goto loc_000019E4;
loc_000019E3:
    CF = 1;
loc_000019E4:
    return;
}

/*
 * Function at 0x000019E5
 */
void func_000019E5(CPU_REGS *regs)
{
    PUSH(regs->bx);
    PUSH(regs->cs);
    regs->ds = POP();
    regs->dl = 0x1;
    regs->ax = 0x3307;
    dos_int21(regs);  /* AH=33h: Get/set break flag */
    regs->dx = 0x106a;
    regs->ax = 0x3d00;
    dos_int21(regs);  /* AH=3Dh: Open file */
    regs->bx = regs->ax;
    PUSH(regs->flags);
    regs->dl = 0x0;
    regs->ax = 0x3307;
    dos_int21(regs);  /* AH=33h: Get/set break flag */
    regs->flags = POP();
    if (CF) goto loc_00001A45;
    regs->ax = 0x4400;
    dos_int21(regs);  /* AH=44h: I/O control */
    if (CF) goto loc_00001A40;
    TEST(regs->dx, 0x80);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00001A40;
    TEST(regs->dx, 0x4000);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00001A40;
    regs->dx = 0x1063;
    regs->cx = 0x6;
    regs->ax = 0x4402;
    dos_int21(regs);  /* AH=44h: I/O control */
    if (CF) goto loc_00001A40;
    CMP(regs->ax, regs->cx);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001A40;
    regs->si = regs->dx;
    regs->ax = MEM[regs->si + 0x4];
    XCHG(regs->ah, regs->al);
    CMP(regs->ax, 0x100);  /* COMPARISON: Testing condition for branch */
    if (CF) goto loc_00001A40;
    CMP(regs->ax, 0x10b);  /* COMPARISON: Testing condition for branch */
    if (!CF && !ZF) goto loc_00001A40;
    regs->ah = 0x3e;
    dos_int21(regs);  /* AH=3Eh: Close file */
    CF = 0;
    goto loc_00001A45;
loc_00001A40:
    regs->ah = 0x3e;
    dos_int21(regs);  /* AH=3Eh: Close file */
    CF = 1;
loc_00001A45:
    regs->bx = POP();
    return;
}

/*
 * Function at 0x00001A47
 */
void func_00001A47(CPU_REGS *regs)
{
    CF = 0;
    regs->ah = 0x1;
    regs->dx = 0xffff;
    func_00001D13(regs);
    if (CF) goto loc_00001A7C;
    CMP(MEM[0xed0], 0x0);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001A5C;
    func_00001967(regs);
loc_00001A5C:
    regs->ax |= regs->ax; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_00001A6A;
    regs->ah = 0x2;
    func_00001D13(regs);
    regs->cx = 0x40;
    goto loc_00001A6C;
loc_00001A6A:
    regs->cx = 0; CF = 0; ZF = 1;  /* ZERO CX: XOR with itself = 0 */
loc_00001A6C:
    regs->ah = 0x8;
    func_00001D13(regs);
    CMP(MEM[0xed0], 0x0);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001A7B;
    func_0000198E(regs);
loc_00001A7B:
    CF = 0;
loc_00001A7C:
    return;
}

/* String data at 0x00001A7D */
static const char str_00001A7D[] = "SMARTAAR";


/* Code at 0x00001A88 */
void code_00001A88(CPU_REGS *regs)
{
    regs->dl = 0x1;
    regs->ax = 0x3307;
    dos_int21(regs);  /* AH=33h: Get/set break flag */
    regs->dx = 0x1b7d;
    regs->ax = 0x3d02;
    dos_int21(regs);  /* AH=3Dh: Open file */
    regs->bx = regs->ax;
    PUSH(regs->flags);
    regs->dl = 0x0;
    regs->ax = 0x3307;
    dos_int21(regs);  /* AH=33h: Get/set break flag */
    regs->flags = POP();
    if (CF) goto loc_00001AE9;
    regs->ax = 0x4400;
    dos_int21(regs);  /* AH=44h: I/O control */
    if (CF) goto loc_00001AE5;
    TEST(regs->dx, 0x80);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00001AE5;
    TEST(regs->dx, 0x4000);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00001AE5;
    regs->dx = 0x103b;
    regs->cx = 0x28;
    regs->ax = 0x4402;
    dos_int21(regs);  /* AH=44h: I/O control */
    if (CF) goto loc_00001AE5;
    CMP(regs->ax, regs->cx);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001AE5;
    regs->si = regs->dx;
    regs->al = MEM[regs->si + 0x3];
    CMP(regs->al, 0x1);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001AE5;
    regs->ax = MEM[regs->si + 0x22];
    regs->ax -= MEM[regs->si + 0x26]; UPDATE_FLAGS_SUB();
    if (CF || ZF) goto loc_00001AE5;
    regs->cl = 0x4;
    regs->ax <<= regs->cl;
    PUSH(regs->ax);
    regs->ah = 0x3e;
    dos_int21(regs);  /* AH=3Eh: Close file */
    regs->ax = POP();
    goto loc_00001AEC;
loc_00001AE5:
    regs->ah = 0x3e;
    dos_int21(regs);  /* AH=3Eh: Close file */
loc_00001AE9:
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
    CF = 1;
loc_00001AEC:
    regs->dx = POP();
    regs->bx = POP();
    return;
}

/*
 * Function at 0x00001AEF
 */
void func_00001AEF(CPU_REGS *regs)
{
    PUSH(regs->bx);
    PUSH(regs->dx);
    regs->dl = 0x1;
    regs->ax = 0x3307;
    dos_int21(regs);  /* AH=33h: Get/set break flag */
    regs->dx = 0x106a;
    regs->ax = 0x3d00;
    dos_int21(regs);  /* AH=3Dh: Open file */
    regs->bx = regs->ax;
    PUSH(regs->flags);
    regs->dl = 0x0;
    regs->ax = 0x3307;
    dos_int21(regs);  /* AH=33h: Get/set break flag */
    regs->flags = POP();
    if (CF) goto loc_00001B30;
    regs->ax = 0x4400;
    dos_int21(regs);  /* AH=44h: I/O control */
    if (CF) goto loc_00001B2B;
    regs->dx &= 0x80; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_00001B2B;
    regs->ax = 0x4407;
    dos_int21(regs);  /* AH=44h: I/O control */
    if (CF) goto loc_00001B2B;
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_00001B2B;
    regs->ah = 0x3e;
    dos_int21(regs);  /* AH=3Eh: Close file */
    goto loc_00001B30;
loc_00001B2B:
    regs->ah = 0x3e;
    dos_int21(regs);  /* AH=3Eh: Close file */
    CF = 1;
loc_00001B30:
    regs->dx = POP();
    regs->bx = POP();
    return;
}

/*
 * Function at 0x00001B33
 */
void func_00001B33(CPU_REGS *regs)
{
    PUSH(regs->bx);
    regs->bx += 0x7; UPDATE_FLAGS_ADD();
    func_00001BE3(regs);
    if (!CF) goto loc_00001B63;
    regs->bx -= 0x7; UPDATE_FLAGS_SUB();
    func_00001BE3(regs);
    if (!CF) goto loc_00001B63;
    regs->bx += 0x7; UPDATE_FLAGS_ADD();
    func_00001C1F(regs);
    if (!CF) goto loc_00001B63;
    func_00001C78(regs);
    if (CF) goto loc_00001B57;
    func_00001B65(regs);
    CF = 0;
    if (!CF) goto loc_00001B63;
loc_00001B57:
    regs->bx -= 0x7; UPDATE_FLAGS_SUB();
    func_00001C78(regs);
    if (CF) goto loc_00001B63;
    func_00001B65(regs);
    CF = 0;
loc_00001B63:
    regs->bx = POP();
    return;
}

/*
 * Function at 0x00001B65
 */
void func_00001B65(CPU_REGS *regs)
{
    DF = 0;
    PUSH(regs->ds);
    regs->es = POP();
    regs->si = 0x6ef;
    regs->bl = 0; CF = 0; ZF = 1;  /* ZERO BL: XOR with itself = 0 */
    CMP(MEM[regs->si + 0x1], 0x3a);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001B79;
    regs->bl |= 0x1; UPDATE_FLAGS_LOGIC();
    regs->si += 0x2; UPDATE_FLAGS_ADD();
loc_00001B79:
    CMP(MEM[regs->si], 0x5c);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001B81;
    regs->bl |= 0x2; UPDATE_FLAGS_LOGIC();
loc_00001B81:
    regs->si = 0x6ef;
    regs->di = 0xe0a;
    TEST(regs->bl, 0x1);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00001B8F;
    STRING_MOVE_WORD(regs);
    goto loc_00001B96;
loc_00001B8F:
    regs->ah = 0x19;
    dos_int21(regs);  /* AH=19h: Get current disk */
    regs->ah = 0x3a;
    STRING_STORE_WORD(regs);
loc_00001B96:
    TEST(regs->bl, 0x2);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00001BC8;
    regs->dl = MEM[0xe0a];
    regs->dl -= 0x40; UPDATE_FLAGS_SUB();
    regs->ah = 0x47;
    MEM[regs->di] = 0x5c;
    regs->di++; UPDATE_FLAGS_INC();
    XCHG(regs->si, regs->di);
    dos_int21(regs);  /* AH=47h: Get current directory */
    XCHG(regs->si, regs->di);
    CMP(MEM[regs->di], 0x0);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001BC0;
    regs->cx = 0xffff;
    regs->al = 0; CF = 0; ZF = 1;  /* ZERO AL: XOR with itself = 0 */
    STRING_SCAN_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    MEM[regs->di - 0x1] = 0x5c;
loc_00001BC0:
    CMP(MEM[regs->si], 0x2e);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001BC8;
    regs->si += 0x2; UPDATE_FLAGS_ADD();
loc_00001BC8:
    STRING_LOAD_BYTE(regs);
    STRING_STORE_BYTE(regs);
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001BC8;
    regs->si = 0xe0a;
    regs->di = 0x6ef;
    regs->cx = 0; CF = 0; ZF = 1;  /* ZERO CX: XOR with itself = 0 */
loc_00001BD6:
    STRING_LOAD_BYTE(regs);
    STRING_STORE_BYTE(regs);
    regs->cx++; UPDATE_FLAGS_INC();
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001BD6;
    regs->cx--; UPDATE_FLAGS_DEC();
    MEM[0x430] = regs->cx;
    return;
}

/*
 * Function at 0x00001BE3
 */
void func_00001BE3(CPU_REGS *regs)
{
    PUSH(regs->di);
    PUSH(regs->si);
    PUSH(regs->ds);
    regs->ax = MEM[0xec9];
    regs->ds = regs->ax;
    regs->si = MEM[0xec7];
    regs->di = 0x6ef;
    regs->dx = regs->di;
loc_00001BF5:
    STRING_LOAD_BYTE(regs);
    STRING_STORE_BYTE(regs);
    CMP(regs->al, 0x5c);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001BFF;
    CMP(regs->al, 0x2f);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001C01;
loc_00001BFF:
    regs->dx = regs->di;
loc_00001C01:
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001BF5;
    regs->ds = POP();
    regs->di = regs->dx;
    regs->si = regs->bx;
loc_00001C0A:
    STRING_LOAD_BYTE(regs);
    STRING_STORE_BYTE(regs);
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001C0A;
    regs->di -= 0x6ef; UPDATE_FLAGS_SUB();
    regs->di--; UPDATE_FLAGS_DEC();
    MEM[0x430] = regs->di;
    func_00001C67(regs);
    regs->si = POP();
    regs->di = POP();
    return;
}

/*
 * Function at 0x00001C1F
 */
void func_00001C1F(CPU_REGS *regs)
{
    PUSH(regs->di);
    PUSH(regs->si);
    regs->ah = 0x19;
    dos_int21(regs);  /* AH=19h: Get current disk */
    regs->dl = regs->al;
    regs->dl++; UPDATE_FLAGS_INC();
    regs->al += 0x41; UPDATE_FLAGS_ADD();
    PUSH(regs->ds);
    regs->es = POP();
    regs->di = 0x6ef;
    STRING_STORE_BYTE(regs);
    regs->al = 0x3a;
    STRING_STORE_BYTE(regs);
    regs->al = 0x5c;
    STRING_STORE_BYTE(regs);
    regs->si = 0xe79;
    regs->ah = 0x47;
    dos_int21(regs);  /* AH=47h: Get current directory */
    if (CF) goto loc_00001C64;
loc_00001C40:
    STRING_LOAD_BYTE(regs);
    STRING_STORE_BYTE(regs);
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001C40;
    regs->di--; UPDATE_FLAGS_DEC();
    CMP(MEM[regs->di - 0x1], 0x5c);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001C50;
    regs->al = 0x5c;
    STRING_STORE_BYTE(regs);
loc_00001C50:
    regs->si = regs->bx;
loc_00001C52:
    STRING_LOAD_BYTE(regs);
    STRING_STORE_BYTE(regs);
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001C52;
    regs->di -= 0x6ef; UPDATE_FLAGS_SUB();
    regs->di--; UPDATE_FLAGS_DEC();
    MEM[0x430] = regs->di;
    func_00001C67(regs);
loc_00001C64:
    regs->si = POP();
    regs->di = POP();
    return;
}

/*
 * Function at 0x00001C67
 */
void func_00001C67(CPU_REGS *regs)
{
    regs->dx = 0x6ef;
    regs->ax = 0x3d00;
    dos_int21(regs);  /* AH=3Dh: Open file */
    if (CF) goto loc_00001C77;
    regs->bx = regs->ax;
    regs->ah = 0x3e;
    dos_int21(regs);  /* AH=3Eh: Close file */
loc_00001C77:
    return;
}

/*
 * Function at 0x00001C78
 */
void func_00001C78(CPU_REGS *regs)
{
    PUSH(regs->ds);
    PUSH(regs->ds);
    regs->es = POP();
    regs->ds = MEM[0x2c];
    regs->si = 0; CF = 0; ZF = 1;  /* ZERO SI: XOR with itself = 0 */
    DF = 0;
loc_00001C82:
    regs->di = 0xdf5;
    regs->cx = 0x4;
    STRING_CMP_BYTE(regs);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001C98;
loc_00001C8C:
    STRING_LOAD_BYTE(regs);
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001C8C;
    CMP(MEM[regs->si], 0x0);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001C82;
    goto loc_00001CE3;
loc_00001C98:
    STRING_LOAD_BYTE(regs);
    CMP(regs->al, 0x3d);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001C98;
loc_00001C9D:
    regs->di = 0x6ef;
    regs->dx = regs->di;
loc_00001CA2:
    STRING_LOAD_BYTE(regs);
    STRING_STORE_BYTE(regs);
    CMP(regs->al, 0x0);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001CAC;
    CMP(regs->al, 0x3b);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001CA2;
loc_00001CAC:
    MEM[0xec5] = regs->ds;
    MEM[0xec3] = regs->si;
    regs->di--; UPDATE_FLAGS_DEC();
    regs->di--; UPDATE_FLAGS_DEC();
    CMP(MEM[regs->di], 0x5c);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001CC3;
    regs->di++; UPDATE_FLAGS_INC();
    MEM[regs->di] = 0x5c;
loc_00001CC3:
    regs->di++; UPDATE_FLAGS_INC();
    PUSH(regs->es);
    regs->ds = POP();
    regs->si = regs->bx;
loc_00001CC8:
    STRING_LOAD_BYTE(regs);
    STRING_STORE_BYTE(regs);
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001CC8;
    func_00001C67(regs);
    if (!CF) goto loc_00001CE4;
    regs->si = MEM[0xec3];
    regs->ds = MEM[0xec5];
    CMP(MEM[regs->si - 0x1], 0x0);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001C9D;
loc_00001CE3:
    CF = 1;
loc_00001CE4:
    regs->ds = POP();
    return;
}

/*
 * Function at 0x00001CE6
 */
void func_00001CE6(CPU_REGS *regs)
{
    PUSH(regs->ds);
    regs->ds = MEM[0x2c];
    regs->si = 0; CF = 0; ZF = 1;  /* ZERO SI: XOR with itself = 0 */
loc_00001CED:
    STRING_LOAD_BYTE(regs);
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001CED;
    STRING_LOAD_BYTE(regs);
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001CED;
    regs->si++; UPDATE_FLAGS_INC();
    regs->si++; UPDATE_FLAGS_INC();
    MEM[0xec7] = regs->si;
    MEM[0xec9] = regs->ds;
    regs->ds = POP();
    return;
}

/*
 * Function at 0x00001D05
 */
void func_00001D05(CPU_REGS *regs)
{
    regs->ax = 0x3000;
    dos_int21(regs);  /* AH=30h: Get DOS version */
    XCHG(regs->al, regs->ah);
    CMP(regs->ax, 0x70a);
    regs->ax = 0x19;
    return;
}

/*
 * Function at 0x00001D13
 */
void func_00001D13(CPU_REGS *regs)
{
    PUSH(regs->cx);
    PUSH(regs->es);
    regs->dx = 0; CF = 0; ZF = 1;  /* ZERO DX: XOR with itself = 0 */
    regs->cx = regs->ax;
    regs->ax = 0x4300;
    dos_multiplex_int(regs);  /* AH=43h: XMS */
    CMP(regs->al, 0x80);
    CF = 1;
    if (!ZF) goto loc_00001D37;
    regs->ax = 0x4310;
    dos_multiplex_int(regs);  /* AH=43h: XMS */
    regs->ax = regs->cx;
    MEM[0xecd] = regs->es;
    MEM[0xecb] = regs->bx;
    CALL_INDIRECT(far [0xecb]);
    CF = 0;
loc_00001D37:
    regs->es = POP();
    regs->cx = POP();
    return;
}

/*
 * Function at 0x00001D3A
 */
void func_00001D3A(CPU_REGS *regs)
{
    PUSH(regs->es);
    PUSH(regs->ds);
    DF = 0;
    regs->si = MEM[0xec7];
    regs->ds = MEM[0xec9];
    PUSH(regs->ds);
    regs->es = POP();
    regs->di = 0; CF = 0; ZF = 1;  /* ZERO DI: XOR with itself = 0 */
loc_00001D49:
    STRING_LOAD_BYTE(regs);
    regs->di++; UPDATE_FLAGS_INC();
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001D49;
    DF = 1;
    regs->si--; UPDATE_FLAGS_DEC();
    regs->di--; UPDATE_FLAGS_DEC();
loc_00001D52:
    STRING_LOAD_BYTE(regs);
    regs->di--; UPDATE_FLAGS_DEC();
    regs->di |= regs->di; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_00001D81;
    CMP(regs->al, 0x5c);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001D52;
    regs->di = regs->si;
    regs->di += 0x8; UPDATE_FLAGS_ADD();
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
    STRING_STORE_BYTE(regs);
    STRING_STORE_BYTE(regs);
    STRING_STORE_BYTE(regs);
    STRING_STORE_BYTE(regs);
loc_00001D67:
    STRING_LOAD_BYTE(regs);
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_00001D6F;
    STRING_STORE_BYTE(regs);
    goto loc_00001D67;
loc_00001D6F:
    regs->si = 0xe5a;
    PUSH(regs->cs);
    regs->ds = POP();
    regs->di = MEM[0xec7];
    regs->di -= 0x3; UPDATE_FLAGS_SUB();
    DF = 0;
    regs->cx = 0x7;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
loc_00001D81:
    DF = 0;
    regs->ds = POP();
    regs->es = POP();
    return;
}

/*
 * Function at 0x00001D85
 */
void func_00001D85(CPU_REGS *regs)
{
    PUSH(regs->flags);
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
    PUSH(regs->ax);
    regs->flags = POP();
    PUSH(regs->flags);
    regs->ax = POP();
    TEST(regs->ax, 0x8000);
    regs->ax = 0x0;
    if (!ZF) goto loc_00001DA7;
    regs->ax = 0x7000;
    PUSH(regs->ax);
    regs->flags = POP();
    IF_FLAG = 1; /* enable interrupts */
    PUSH(regs->flags);
    regs->ax = POP();
    TEST(regs->ax, 0x7000);
    regs->ax = 0x286;
    if (ZF) goto loc_00001DA7;
    regs->ax = 0x386;
loc_00001DA7:
    regs->flags = POP();
    return;
}

/*
 * Function at 0x00001DA9
 */
void func_00001DA9(CPU_REGS *regs)
{
    PUSH(regs->ax);
    PUSH(regs->cx);
    regs->ax = 0x160a;
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
    regs->ax |= regs->ax; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001DC9;
    regs->dx = 0x3c;
    CMP(regs->cx, 0x3);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001E0E;
    regs->dx = 0x3e;
    CMP(regs->cx, 0x2);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001E0E;
    regs->dx = 0x3f;
    if (!ZF) goto loc_00001E0E;
loc_00001DC9:
    regs->ax = 0x1600;
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
    regs->dx = 0x40;
    TEST(regs->al, 0x7f);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00001DE9;
    regs->ax = 0x1683;
    regs->bx = 0; CF = 0; ZF = 1;  /* ZERO BX: XOR with itself = 0 */
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
    regs->dx = 0x40;
    CMP(regs->bx, 0x1);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001E0E;
    regs->dx = 0x41;
    goto loc_00001E0E;
loc_00001DE9:
    regs->ax = 0x4680;
    dos_multiplex_int(regs);  /* AH=46h: Windows startup */
    regs->dx = 0; CF = 0; ZF = 1;  /* ZERO DX: XOR with itself = 0 */
    regs->ax |= regs->ax; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001E0E;
    regs->ax = 0x4b02;
    PUSH(regs->bx);
    PUSH(regs->es);
    PUSH(regs->di);
    regs->bx = 0; CF = 0; ZF = 1;  /* ZERO BX: XOR with itself = 0 */
    regs->di = regs->bx;
    regs->es = regs->bx;
    dos_multiplex_int(regs);  /* AH=4Bh: Task switcher */
    regs->di = POP();
    regs->es = POP();
    regs->bx = POP();
    regs->dx = 0; CF = 0; ZF = 1;  /* ZERO DX: XOR with itself = 0 */
    regs->ax |= regs->ax; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_00001E0E;
    regs->dx = 0x40;
loc_00001E0E:
    regs->cx = POP();
    regs->ax = POP();
    return;
}

/*
 * Function at 0x00001E11
 */
void func_00001E11(CPU_REGS *regs)
{
    PUSH(regs->si);
    PUSH(regs->di);
    PUSH(regs->cx);
    PUSH(regs->bx);
    PUSH(regs->ax);
    regs->ds = MEM[0x2c];
    PUSH(regs->ds);
    regs->es = POP();
    regs->si = 0; CF = 0; ZF = 1;  /* ZERO SI: XOR with itself = 0 */
    DF = 0;
loc_00001E1F:
    STRING_LOAD_BYTE(regs);
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001E1F;
    STRING_LOAD_BYTE(regs);
    regs->al |= regs->al; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001E1F;
    regs->si++; UPDATE_FLAGS_INC();
    regs->si++; UPDATE_FLAGS_INC();
    regs->di = regs->si;
    regs->cx = 0x80;
    STRING_SCAN_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->di--; UPDATE_FLAGS_DEC();
    regs->di -= regs->si; UPDATE_FLAGS_SUB();
    regs->bx = regs->di;
    PUSH(regs->cs);
    regs->es = POP();
    regs->di = 0x551;
    regs->cx = regs->bx;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    PUSH(regs->cs);
    regs->ds = POP();
    regs->di = 0x551;
    regs->di += regs->bx; UPDATE_FLAGS_ADD();
    regs->cx = regs->bx;
loc_00001E49:
    regs->di--; UPDATE_FLAGS_DEC();
    regs->cx--; UPDATE_FLAGS_DEC();
    CMP(MEM[regs->di], 0x5c);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001E59;
    CMP(MEM[regs->di], 0x2f);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001E59;
    if (regs->cx == 0) goto loc_00001E64;
    goto loc_00001E49;
loc_00001E59:
    regs->di -= 0x551; UPDATE_FLAGS_SUB();
    MEM[0x100] = regs->di;
    CF = 0;
    goto loc_00001EBB;
loc_00001E64:
    regs->bx = 0x551;
    func_00001C1F(regs);
    if (CF) goto loc_00001E75;
    MEM[0x100] = 0x0;
    CF = 0;
    goto loc_00001EBB;
loc_00001E75:
    regs->bx = 0x551;
    func_00001C78(regs);
    if (CF) goto loc_00001EB5;
    regs->di = 0x6ef;
    regs->si = regs->di;
    regs->cx = 0x80;
    DF = 0;
    STRING_SCAN_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->di -= regs->si; UPDATE_FLAGS_SUB();
    regs->bx = regs->di;
    regs->cx = regs->bx;
    regs->di = 0x551;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->di = 0x551;
    regs->di += regs->bx; UPDATE_FLAGS_ADD();
    regs->cx = regs->bx;
loc_00001E9A:
    regs->di--; UPDATE_FLAGS_DEC();
    regs->cx--; UPDATE_FLAGS_DEC();
    CMP(MEM[regs->di], 0x5c);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001EAA;
    CMP(MEM[regs->di], 0x2f);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001EAA;
    if (regs->cx == 0) goto loc_00001EB5;
    goto loc_00001E9A;
loc_00001EAA:
    regs->di -= 0x551; UPDATE_FLAGS_SUB();
    MEM[0x100] = regs->di;
    CF = 0;
    goto loc_00001EBB;
loc_00001EB5:
    MEM[0x100] = 0x0;
loc_00001EBB:
    MEM[0x42a] = regs->ds;
    MEM[0x428] = 0x551;
    regs->ax = POP();
    regs->bx = POP();
    regs->cx = POP();
    regs->di = POP();
    regs->si = POP();
    return;
}

/*
 * Function at 0x00001ECB
 */
void func_00001ECB(CPU_REGS *regs)
{
    regs->ax = regs->di;
    regs->ax++; UPDATE_FLAGS_INC();
    regs->ax += regs->cx; UPDATE_FLAGS_ADD();
    CMP(regs->ax, 0x100);  /* COMPARISON: Testing condition for branch */
    if (!CF) goto loc_00001EE0;
    MEM[0x80] += regs->cl; UPDATE_FLAGS_ADD();
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    MEM[regs->di] = 0xd;
loc_00001EE0:
    return;
}

/* String data at 0x00001EE1 */
static const char str_00001EE1[] = "WOSAPPC:\\MSDOSSYS.STS";


/* Code at 0x00001EF6 */
void code_00001EF6(CPU_REGS *regs)
{
    MEM[regs->bp + regs->si] += regs->cl; UPDATE_FLAGS_ADD();
}

/* String data at 0x00001EF8 */
static const char str_00001EF8[] = "C:\\CONFIG.SYS";


/* Code at 0x00001F05 */
void code_00001F05(CPU_REGS *regs)
{
    MEM[regs->si] += regs->cl; UPDATE_FLAGS_ADD();
}

/* String data at 0x00001F07 */
static const char str_00001F07[] = "C:\\AUTOEXEC.BAT";


/* Code at 0x00001F16 */
void code_00001F16(CPU_REGS *regs)
{
    regs->bh += regs->dh; UPDATE_FLAGS_ADD();
    regs->ds = POP();
    PUSH(regs->es);
    MEM[regs->bx + regs->si] &= regs->al; UPDATE_FLAGS_LOGIC();
}

/* Zero-initialized data at 0x00001F1C (16 bytes) */
static uint8_t data_00001F1C[16] = {0};


/* Code at 0x00001F2C */
void code_00001F2C(CPU_REGS *regs)
{
    regs->ah += regs->bh; UPDATE_FLAGS_ADD();
    PUSH(regs->ds);
    regs->es = POP();
    func_00001DA9(regs);
    regs->dx |= regs->dx; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_00001F38;
    return;
loc_00001F38:
    PUSH(regs->ax);
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00001F66;
    TEST(regs->si, regs->si);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00001F66;
    STRING_LOAD_BYTE(regs);
    regs->al |= 0x20; UPDATE_FLAGS_LOGIC();
    CMP(regs->al, 0x78);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00001F66;
    regs->si--; UPDATE_FLAGS_DEC();
    regs->ah = 0xf;
    bios_video_int(regs);  /* AH=0Fh: Get current video mode */
    regs->ah = 0x3;
    bios_video_int(regs);  /* AH=03h: Get cursor position and shape */
    regs->dl |= regs->dh; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_00001F66;
    regs->ax = 0x44;
    func_000013D0(regs);
    regs->ax = 0xc08;
    dos_int21(regs);  /* AH=0Ch: Flush buffer and read keyboard */
    regs->ax = 0x68;
    func_000013D0(regs);
loc_00001F66:
    regs->ax = POP();
    regs->sp -= 0x4; UPDATE_FLAGS_SUB();
    regs->bp = regs->sp;
    PUSH(regs->si);
    regs->bx = 0x2017;
    MEM[regs->bp + 0x0] = 0x1fe1;
    MEM[regs->bp + 0x2] = 0x1fe4;
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00001F88;
    MEM[regs->bp + 0x0] = 0x1fe4;
    MEM[regs->bp + 0x2] = 0x1fe1;
loc_00001F88:
    regs->si = MEM[regs->bx];
    regs->si |= regs->si; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00001F91;
    goto loc_00002028;
loc_00001F91:
    STRING_LOAD_BYTE(regs);
    regs->ax = (int16_t)(int8_t)regs->al;
    XCHG(regs->ax, regs->cx);
    regs->ax = 0x3305;
    dos_int21(regs);  /* AH=33h: Get/set break flag */
    regs->dl += 0x40; UPDATE_FLAGS_ADD();
    MEM[regs->si] = regs->dl;
    regs->di = 0x201d;
    regs->dx = regs->di;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->si = MEM[regs->bp + 0x0];
    regs->cl = 0x3;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->al = 0x0;
    STRING_STORE_BYTE(regs);
    regs->ah = 0x43;
    dos_int21(regs);  /* AH=43h: Get/set file attributes */
    if (CF) goto loc_00002023;
    TEST(regs->cl, 0x2);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00001FBD;
    func_0000215B(regs);
loc_00001FBD:
    PUSH(regs->ax);
    PUSH(regs->cx);
    PUSH(regs->dx);
    PUSH(regs->di);
    PUSH(regs->bx);
    regs->dx = MEM[regs->bx];
    regs->dx++; UPDATE_FLAGS_INC();
    regs->si = MEM[regs->bp + 0x2];
    regs->di -= 0x4; UPDATE_FLAGS_SUB();
    regs->cx = 0x3;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->al = 0x0;
    STRING_STORE_BYTE(regs);
    regs->di = 0x201d;
    regs->ah = 0x56;
    dos_int21(regs);  /* AH=56h: Rename file */
    if (!CF) goto loc_00001FF8;
    CMP(regs->ax, 0x2);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00001FF8;
    regs->dx = regs->di;
    regs->ax = 0x4300;
    dos_int21(regs);  /* AH=43h: Get/set file attributes */
    if (!CF) goto loc_00001FF8;
    regs->cx = 0x2;
    regs->ah = 0x3c;
    dos_int21(regs);  /* AH=3Ch: Create file */
    if (CF) goto loc_00001FF8;
    XCHG(regs->ax, regs->bx);
    regs->ah = 0x3e;
    dos_int21(regs);  /* AH=3Eh: Close file */
loc_00001FF8:
    regs->bx = POP();
    regs->di = POP();
    regs->dx = POP();
    regs->si = MEM[regs->bp + 0x0];
    regs->di -= 0x4; UPDATE_FLAGS_SUB();
    regs->cx = 0x3;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->al = 0x0;
    STRING_STORE_BYTE(regs);
    regs->dx = 0x201d;
    regs->ax = POP();
    regs->cx = POP();
    TEST(regs->al, 0x2);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_0000201C;
    TEST(regs->cx, regs->cx);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_0000201C;
    regs->ah = 0x41;
    dos_int21(regs);  /* AH=41h: Delete file */
    goto loc_00002023;
loc_0000201C:
    regs->di = MEM[regs->bx];
    regs->di++; UPDATE_FLAGS_INC();
    regs->ah = 0x56;
    dos_int21(regs);  /* AH=56h: Rename file */
loc_00002023:
    regs->bx++; UPDATE_FLAGS_INC();
    regs->bx++; UPDATE_FLAGS_INC();
    goto loc_00001F88;
loc_00002028:
    PUSH(regs->ds);
    regs->ax = 0x4a33;
    dos_multiplex_int(regs);  /* AH=4Ah: HMA */
    regs->ds = POP();
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00002043;
    XCHG(regs->ax, regs->bx);
    TEST(regs->ah, regs->ah);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00002043;
    regs->bx = 0x1fe7;
    MEM[regs->bx] = regs->ah;
    regs->dx = regs->bx;
    regs->ah = 0x41;
    dos_int21(regs);  /* AH=41h: Delete file */
loc_00002043:
    func_0000011C(regs);
    regs->si = POP();
    STRING_LOAD_BYTE(regs);
    regs->al |= 0x20; UPDATE_FLAGS_LOGIC();
    CMP(regs->al, 0x71);
    regs->ax = 0x0;
    regs->ds = regs->ax;
    IF_FLAG = 0; /* disable interrupts */
    if (ZF) goto loc_0000205F;
loc_00002054:
    MEM[0x472] = 0x1234;
    goto loc_000FFFF0;
loc_0000205F:
    CMP(regs->si, 0x1);  /* COMPARISON: Testing condition for branch */
    if (CF || ZF) goto loc_00002054;
    regs->si = 0x53c;
    regs->cx = 0x61;
    regs->ax = 0; CF = 0; ZF = 1;
loc_0000206C:
    regs->ax += MEM[regs->si]; UPDATE_FLAGS_ADD();
    regs->si += 0x2; UPDATE_FLAGS_ADD();
    regs->cx--; if (regs->cx != 0) goto loc_0000206C;
    CMP(regs->ax, MEM[regs->si]);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00002054;
    regs->ax = MEM[0x53c];
    CMP(regs->ax, 0x27f);  /* COMPARISON: Testing condition for branch */
    if (!CF) goto loc_00002085;
    CMP(regs->ax, MEM[0x413]);  /* COMPARISON: Testing condition for branch */
    if (CF) goto loc_00002054;
loc_00002085:
    TEST(MEM[0x47b], 0x20);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00002098;
    PUSH(regs->flags);
    regs->eax = POP();
    regs->eax >>= 0x10;
    TEST(regs->al, 0x2);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_000020B5;
loc_00002098:
    MEM[0x467] = 0x21b5;
    MEM[0x469] = regs->cs;
    regs->al = 0x8f;
    PORT_OUT(0x70, regs->al);
    goto loc_000020A8;
loc_000020A8:
    goto loc_000020AA;
loc_000020AA:
    regs->al = 0xa;
    PORT_OUT(0x71, regs->al);
    regs->al = 0xfe;
    PORT_OUT(0x64, regs->al);
loc_000020B2:
    HLT(); /* halt until interrupt */
    goto loc_000020B2;
loc_000020B5:
    IF_FLAG = 0; /* disable interrupts */
    DF = 0;
    regs->ax = 0; CF = 0; ZF = 1;
    regs->ds = regs->ax;
    regs->es = regs->ax;
    regs->ss = regs->ax;
    regs->sp = 0x700;
    regs->di = 0x0;
    regs->si = 0x540;
    regs->cx = 0x40;
    STRING_MOVE_WORD(regs);  /* STRING OPERATION: Repeat CX times */
    regs->di = 0x100;
    regs->cx = 0x8;
    STRING_MOVE_WORD(regs);  /* STRING OPERATION: Repeat CX times */
    regs->di += 0x8; UPDATE_FLAGS_ADD();
    STRING_MOVE_WORD(regs);
    STRING_MOVE_WORD(regs);
    regs->di += 0x10; UPDATE_FLAGS_ADD();
    STRING_MOVE_WORD(regs);
    STRING_MOVE_WORD(regs);
    regs->di += 0xc; UPDATE_FLAGS_ADD();
    STRING_MOVE_WORD(regs);
    STRING_MOVE_WORD(regs);
    regs->di = 0x1c0;
    regs->cx = 0x10;
    STRING_MOVE_WORD(regs);  /* STRING OPERATION: Repeat CX times */
    regs->ax = 0; CF = 0; ZF = 1;
    regs->di = 0x19c;
    STRING_STORE_WORD(regs);
    STRING_STORE_WORD(regs);
    CMP(MEM[0x80f], 0x19);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00002106;
    regs->ax = MEM[0x810];
    MEM[0x64] = regs->ax;
    regs->ax = MEM[0x812];
    MEM[0x66] = regs->ax;
loc_00002106:
    MEM[0x47b] &= 0xdf; UPDATE_FLAGS_LOGIC();
    regs->ax = MEM[0x53c];
    MEM[0x413] = regs->ax;
    regs->cx = MEM[0x53e];
    if (regs->cx == 0) goto loc_00002139;
    PUSH(regs->ds);
    PUSH(regs->es);
    regs->es = regs->cx;
    regs->dx = MEM[0x40e];
    CMP(regs->cx, regs->dx);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00002137;
    MEM[0x40e] = regs->cx;
    regs->ds = regs->dx;
    regs->cx = 0x280;
    regs->cx -= regs->ax; UPDATE_FLAGS_SUB();
    regs->cx <<= 0x9;
    regs->si = 0; CF = 0; ZF = 1;
    regs->di = 0; CF = 0; ZF = 1;
    STRING_MOVE_WORD(regs);  /* STRING OPERATION: Repeat CX times */
loc_00002137:
    regs->es = POP();
    regs->ds = POP();
loc_00002139:
    regs->al = MEM[0x5fc];
    PORT_OUT(0x21, regs->al);
    regs->al = MEM[0x5fd];
    PORT_OUT(0xa1, regs->al);
    regs->ax = 0x201;
    regs->bx = 0x7c00;
    regs->cx = 0x1;
    regs->dx = 0x80;
    bios_disk_int(regs);  /* AH=02h: Read sectors */
    if (CF) goto loc_00002156;
    PUSH(regs->es);
    PUSH(regs->bx);
    return; /* far */
loc_00002156:
    software_interrupt_0x19(regs);
    goto loc_00002054;
}

/*
 * Function at 0x0000215B
 */
void func_0000215B(CPU_REGS *regs)
{
    regs->ax = 0x3d00;
    dos_int21(regs);  /* AH=3Dh: Open file */
    if (CF) goto loc_0000217F;
    PUSH(regs->bx);
    PUSH(regs->cx);
    PUSH(regs->dx);
    XCHG(regs->ax, regs->bx);
    regs->cx = 0; CF = 0; ZF = 1;
    regs->dx = 0; CF = 0; ZF = 1;
    regs->ax = 0x4202;
    dos_int21(regs);  /* AH=42h: Move file pointer */
    regs->dx += byte -0x1; UPDATE_FLAGS_ADD();
    regs->dx -= regs->dx + CF; UPDATE_FLAGS_SBB();
    regs->ax |= regs->dx; UPDATE_FLAGS_LOGIC();
    XCHG(regs->ax, regs->cx);
    regs->ah = 0x3e;
    dos_int21(regs);  /* AH=3Eh: Close file */
    XCHG(regs->ax, regs->cx);
    regs->dx = POP();
    regs->cx = POP();
    regs->bx = POP();
loc_0000217F:
    return;
}

/*
 * Function at 0x00002180
 */
void func_00002180(CPU_REGS *regs)
{
    regs->bx = 0x3d1e;
loc_00002183:
    regs->ah = 0x2c;
    dos_int21(regs);  /* AH=2Ch: Get system time */
    regs->ah = regs->dh;
    regs->dh -= regs->bh; UPDATE_FLAGS_SUB();
    regs->bh = regs->ah;
    if (!CF) goto loc_00002191;
    regs->dh = 0x1;
loc_00002191:
    regs->bl -= regs->dh; UPDATE_FLAGS_SUB();
    if (ZF || SF != OF) goto loc_0000219E;
    regs->ah = 0x6;
    regs->dl = 0xff;
    dos_int21(regs);  /* AH=06h: Direct console I/O */
    if (ZF) goto loc_00002183;
    return;
loc_0000219E:
    regs->al = 0; CF = 0; ZF = 1;  /* ZERO AL: XOR with itself = 0 */
    return;
}

/* Zero-initialized data at 0x000021A1 (12 bytes) */
static uint8_t data_000021A1[12] = {0};


/* Code at 0x000021AD */
void code_000021AD(CPU_REGS *regs)
{
    /* data: ['0xff'] */
    /* data: ['0xff'] */
    /* data: ['0xff'] */
    MEM[regs->bx + regs->si]++; UPDATE_FLAGS_INC();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    regs->bh += regs->bh; UPDATE_FLAGS_ADD();
    /* data: ['0xff'] */
    /* data: ['0xff'] */
    MEM[regs->bx + regs->si]++; UPDATE_FLAGS_INC();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    regs->bh += regs->bh; UPDATE_FLAGS_ADD();
    /* data: ['0xff'] */
    /* data: ['0xff'] */
    MEM[regs->bx + regs->si]++; UPDATE_FLAGS_INC();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    regs->bh += regs->bh; UPDATE_FLAGS_ADD();
    /* data: ['0xff'] */
    /* data: ['0xff'] */
    /* data: ['0xff'] */
    /* data: ['0xff'] */
    /* data: ['0xff'] */
    /* data: ['0xff'] */
    MEM[regs->bx + regs->si]++; UPDATE_FLAGS_INC();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    regs->ax |= 0xa; UPDATE_FLAGS_LOGIC();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bp + regs->si] += regs->cl; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->si] += regs->ch; UPDATE_FLAGS_ADD();
    MEM[0x2d00] += regs->ch; UPDATE_FLAGS_ADD();
    MEM[regs->bp + regs->si] += regs->bh; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->di] += regs->al; UPDATE_FLAGS_ADD();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x24; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x0; UPDATE_FLAGS_LOGIC();
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->di + 0x4e] += regs->al; UPDATE_FLAGS_ADD();
    PUSH(regs->bp);
}

/* Zero-initialized data at 0x0000223D (8 bytes) */
static uint8_t data_0000223D[8] = {0};


/* Code at 0x00002245 */
void code_00002245(CPU_REGS *regs)
{
    regs->sp--; UPDATE_FLAGS_DEC();
    regs->cx++; UPDATE_FLAGS_INC();
    regs->si--; UPDATE_FLAGS_DEC();
    regs->di++; UPDATE_FLAGS_INC();
    CMP(regs->ax, 0x414c);
    regs->si--; UPDATE_FLAGS_DEC();
    regs->di++; UPDATE_FLAGS_INC();
    PUSH(regs->bx);
    PUSH(regs->ax);
    regs->bp++; UPDATE_FLAGS_INC();
    regs->bx++; UPDATE_FLAGS_INC();
    CMP(regs->ax, 0x0);
}

/* Zero-initialized data at 0x00002255 (6168 bytes) */
static uint8_t data_00002255[6168] = {0};

/* String data at 0x00003A6D */
static const char str_00003A6D[] = "MS-DOS Version 7 (C)Copyright 1981-1996 Microsoft Corp Licensed Material - Property of Microsoft All rights reserved PSR";


/* Code at 0x00003AE5 */
void code_00003AE5(CPU_REGS *regs)
{
    PUSH(regs->es);
    PUSH(regs->di);
    regs->ax = 0x5100;
    dos_int21(regs);  /* AH=51h: Get current PSP */
    regs->cx = 0; CF = 0; ZF = 1;  /* ZERO CX: XOR with itself = 0 */
    regs->es = regs->cx;
loc_00003AF0:
    regs->di = 0; CF = 0; ZF = 1;  /* ZERO DI: XOR with itself = 0 */
    regs->ax = 0x122e;
    regs->dl = 0x0;
    dos_multiplex_int(regs);  /* AH=12h: DOS internal */
    MEM[0x22a7] = regs->es;
    MEM[0x22a5] = regs->di;
    regs->dl = 0x6;
    dos_multiplex_int(regs);
    MEM[0x22ab] = regs->es;
    MEM[0x22a9] = regs->di;
    regs->ax = 0x122e;
loc_00003B10:
    regs->dl = 0x2;
    dos_multiplex_int(regs);  /* AH=12h: DOS internal */
    MEM[0x22b3] = regs->es;
    MEM[0x22b1] = regs->di;
loc_00003B1C:
    regs->ax = 0x122e;
    regs->dl = 0x4;
    dos_multiplex_int(regs);  /* AH=12h: DOS internal */
    MEM[0x22c3] = regs->es;
    MEM[0x22c1] = regs->di;
    regs->es = regs->bx;
    regs->es = MEM[0x2c];
    regs->di = 0x0;
    func_00003D0F(regs);
    PUSH(regs->ds);
    PUSH(regs->es);
loc_00003B3A:
    regs->ds = POP();
    regs->dx = regs->di;
    regs->dx += 0x3; UPDATE_FLAGS_ADD();
    regs->ax = 0x3d00;
    dos_int21(regs);  /* AH=3Dh: Open file */
    regs->ds = POP();
    if (CF) goto loc_00003B94;
    regs->bx = regs->ax;
    MEM[0x2338] = regs->bx;
    func_00003BA0(regs);
    PUSH(regs->flags);
    regs->ax = 0x3e00;
loc_00003B55:
    regs->bx = MEM[0x2338];
    dos_int21(regs);  /* AH=3Eh: Close file */
    regs->flags = POP();
    if (CF) goto loc_00003B9A;
    regs->di = 0xffff;
    regs->ax = 0x122e;
    regs->dl = 0x8;
    dos_multiplex_int(regs);  /* AH=12h: DOS internal */
    MEM[0x22d7] = regs->es;
    MEM[0x22d5] = regs->di;
    CF = 0;
    MEM[0x22e0] = 0xa0d;
    MEM[0x2335] = 0x24;
    MEM[0x22e4] = 0x0;
    MEM[0x22e8] = 0xa;
    PUSH(regs->cx);
    func_00003D77(regs);
    if (!CF) goto loc_00003B93;
    regs->sp += 0x2; UPDATE_FLAGS_ADD();
    goto loc_00003B9A;
loc_00003B93:
    regs->cx = POP();
loc_00003B94:
    regs->di = POP();
    regs->es = POP();
    regs->dx = POP();
    regs->bx = POP();
    regs->ax = POP();
loc_00003B99:
    return;
loc_00003B9A:
    regs->sp += 0xa; UPDATE_FLAGS_ADD();
    CF = 1;
    goto loc_00003B99;
}

/*
 * Function at 0x00003BA0
 */
void func_00003BA0(CPU_REGS *regs)
{
    PUSH(regs->es);
    regs->cx = 0; CF = 0; ZF = 1;  /* ZERO CX: XOR with itself = 0 */
    regs->dx = 0; CF = 0; ZF = 1;  /* ZERO DX: XOR with itself = 0 */
    regs->dx -= 0x7; UPDATE_FLAGS_SUB();
    regs->cx -= 0x0 + CF; UPDATE_FLAGS_SBB();
    regs->ax = 0x4202;
    dos_int21(regs);  /* AH=42h: Move file pointer */
    regs->cx = 0x7;
    regs->ax += regs->cx; UPDATE_FLAGS_ADD();
    regs->dx += 0x0 + CF; UPDATE_FLAGS_ADC();
    MEM[0x2341] = regs->ax;
    MEM[0x2343] = regs->dx;
    regs->ax = 0x3f00;
    regs->dx = 0x2353;
    dos_int21(regs);  /* AH=3Fh: Read from file/device */
    if (CF) goto loc_00003BE4;
    CMP(MEM[0x2356], 0x534e);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003BE4;
    regs->ax = MEM[0x2358];
    regs->dx = MEM[0x2341];
    regs->cx = MEM[0x2343];
    regs->dx -= regs->ax; UPDATE_FLAGS_SUB();
    regs->cx -= 0x0 + CF; UPDATE_FLAGS_SBB();
    goto loc_00003C28;
loc_00003BE4:
    regs->cx = 0; CF = 0; ZF = 1;  /* ZERO CX: XOR with itself = 0 */
    regs->dx = 0; CF = 0; ZF = 1;  /* ZERO DX: XOR with itself = 0 */
    regs->ax = 0x4200;
    dos_int21(regs);  /* AH=42h: Move file pointer */
    regs->cx = 0x1a;
    regs->ax = 0x3f00;
    regs->dx = 0x2353;
    dos_int21(regs);  /* AH=3Fh: Read from file/device */
    if (CF) goto loc_00003C4A;
    regs->ax = MEM[0x2353];
    CMP(regs->ax, 0x5a4d);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003C4A;
    regs->ax = MEM[0x2359];
    regs->ax <<= 1;
    regs->ax <<= 1;
    regs->ax += MEM[0x236b]; UPDATE_FLAGS_ADD();
    CMP(regs->ax, 0x3f);  /* COMPARISON: Testing condition for branch */
    if (CF || ZF) goto loc_00003C23;
    regs->ax += 0xf; UPDATE_FLAGS_ADD();
    regs->cx = 0x4;
    regs->ax >>= regs->cl;
    regs->ax <<= regs->cl;
    regs->cx = 0; CF = 0; ZF = 1;  /* ZERO CX: XOR with itself = 0 */
    regs->dx = regs->ax;
    goto loc_00003C28;
loc_00003C23:
    regs->cx = 0; CF = 0; ZF = 1;  /* ZERO CX: XOR with itself = 0 */
    regs->dx = 0x40;
loc_00003C28:
    MEM[0x2341] = regs->cx;
    MEM[0x2343] = regs->dx;
    regs->si = 0x1;
    func_00003C4C(regs);
    if (!CF) goto loc_00003C47;
    regs->cx = MEM[0x2341];
    regs->dx = MEM[0x2343];
    regs->si = 0; CF = 0; ZF = 1;  /* ZERO SI: XOR with itself = 0 */
    func_00003C4C(regs);
    if (CF) goto loc_00003C4A;
loc_00003C47:
    func_00003CC9(regs);
loc_00003C4A:
    regs->es = POP();
    return;
}

/*
 * Function at 0x00003C4C
 */
void func_00003C4C(CPU_REGS *regs)
{
loc_00003C4C:
    PUSH(regs->cx);
    PUSH(regs->dx);
    regs->ax = 0x4200;
    dos_int21(regs);  /* AH=42h: Move file pointer */
    regs->cx = 0x10;
    regs->ah = 0x3f;
    regs->dx = 0x2353;
    dos_int21(regs);  /* AH=3Fh: Read from file/device */
    if (CF) goto loc_00003C97;
    CMP(regs->ax, regs->cx);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003C97;
    regs->ax = MEM[0x235e];
    CMP(regs->ax, 0x534e);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003C97;
    regs->si |= regs->si; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_00003C9C;
    regs->si = 0x2357;
    PUSH(regs->es);
    PUSH(regs->ds);
    regs->es = POP();
    regs->di = 0x233a;
    regs->cx = 0x3;
    STRING_CMP_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->es = POP();
    if (ZF) goto loc_00003C9C;
    regs->dx = POP();
    regs->cx = POP();
    regs->dx += MEM[0x2353]; UPDATE_FLAGS_ADD();
    regs->cx += 0x0 + CF; UPDATE_FLAGS_ADC();
    regs->dx += 0xf; UPDATE_FLAGS_ADD();
    regs->cx += 0x0 + CF; UPDATE_FLAGS_ADC();
    regs->dl &= 0xf0; UPDATE_FLAGS_LOGIC();
    goto loc_00003C4C;
loc_00003C97:
    regs->dx = POP();
    regs->cx = POP();
    CF = 1;
    goto loc_00003CC5;
loc_00003C9C:
    regs->dx = POP();
    regs->cx = POP();
    PUSH(regs->bx);
    regs->bx = MEM[0x2355];
    regs->bx -= 0x10; UPDATE_FLAGS_SUB();
    regs->ax = 0x1800;
    regs->ax -= regs->bx; UPDATE_FLAGS_SUB();
    regs->bx = POP();
    if (SF) goto loc_00003CC6;
    regs->cx = MEM[0x2353];
    regs->cx -= 0x10; UPDATE_FLAGS_SUB();
    PUSH(regs->ds);
    regs->ax = regs->ds;
    regs->es = regs->ax;
    regs->dx = 0x236d;
    regs->ah = 0x3f;
    dos_int21(regs);  /* AH=3Fh: Read from file/device */
    regs->ds = POP();
    if (CF) goto loc_00003CC6;
loc_00003CC5:
    return;
loc_00003CC6:
    CF = 1;
    goto loc_00003CC5;
}

/*
 * Function at 0x00003CC9
 */
void func_00003CC9(CPU_REGS *regs)
{
    regs->di = regs->dx;
    regs->cl = MEM[regs->di];
    regs->cl -= 0x2; UPDATE_FLAGS_SUB();
    regs->di++; UPDATE_FLAGS_INC();
    regs->ax = MEM[regs->di];
    regs->ax += regs->di; UPDATE_FLAGS_ADD();
    MEM[0x22a1] = regs->ax;
    MEM[0x22a3] = regs->es;
    MEM[0x22bf] = regs->es;
    MEM[0x22bd] = regs->ax;
    regs->di += 0x2; UPDATE_FLAGS_ADD();
    regs->ax = MEM[regs->di];
    regs->ax += regs->di; UPDATE_FLAGS_ADD();
    MEM[0x22b7] = regs->es;
    MEM[0x22b5] = regs->ax;
    regs->si = 0x0;
loc_00003CF7:
    regs->di += 0x2; UPDATE_FLAGS_ADD();
    regs->ax = MEM[regs->di];
    regs->ax += regs->di; UPDATE_FLAGS_ADD();
    MEM[regs->si + 0x22c9] = regs->ax;
    MEM[regs->si + 0x22cb] = regs->es;
    regs->si += 0x4; UPDATE_FLAGS_ADD();
    regs->cl--; UPDATE_FLAGS_DEC();
    if (!ZF) goto loc_00003CF7;
    return;
}

/*
 * Function at 0x00003D0F
 */
void func_00003D0F(CPU_REGS *regs)
{
    PUSH(regs->si);
    PUSH(regs->di);
    regs->si = 0x2345;
    regs->bx = 0x5;
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
loc_00003D1A:
    regs->cx = regs->bx;
    PUSH(regs->si);
    STRING_CMP_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->si = POP();
    if (ZF) goto loc_00003D2F;
    regs->di--; UPDATE_FLAGS_DEC();
loc_00003D23:
    regs->cx = 0xffff;
    STRING_SCAN_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    CMP(MEM[regs->di], regs->al);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00003D45;
    goto loc_00003D1A;
loc_00003D2F:
    regs->si = 0x233a;
    regs->ax = MEM[regs->di];
    MEM[regs->si] = regs->ax;
    regs->si += 0x2; UPDATE_FLAGS_ADD();
    regs->al = MEM[regs->di + 0x2];
    MEM[regs->si] = regs->al;
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
    goto loc_00003D23;
loc_00003D45:
    regs->di = POP();
    regs->si = 0x234a;
    regs->bx = 0x9;
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
loc_00003D4F:
    regs->cx = regs->bx;
    PUSH(regs->si);
    STRING_CMP_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->si = POP();
    if (ZF) goto loc_00003D64;
    regs->di--; UPDATE_FLAGS_DEC();
loc_00003D58:
    regs->cx = 0xffff;
    STRING_SCAN_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    CMP(MEM[regs->di], regs->al);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00003D75;
    goto loc_00003D4F;
loc_00003D64:
    regs->si = 0x233d;
    MEM[regs->si] = regs->di;
    regs->si += 0x2; UPDATE_FLAGS_ADD();
    regs->ax = regs->es;
    MEM[regs->si] = regs->ax;
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
    goto loc_00003D58;
loc_00003D75:
    regs->si = POP();
    return;
}

/*
 * Function at 0x00003D77
 */
void func_00003D77(CPU_REGS *regs)
{
    regs->ah = 0x30;
    dos_int21(regs);  /* AH=30h: Get DOS version */
    CMP(regs->ax, 0xa07);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00003D98;
    CMP(regs->ax, 0x2);  /* COMPARISON: Testing condition for branch */
    if (!CF) goto loc_00003D8A;
    regs->bx = 0xffff;
    goto loc_00003D8D;
loc_00003D8A:
    regs->bx = 0x2;
loc_00003D8D:
    regs->ax = 0x1;
    regs->cx = 0x0;
    regs->dl = 0x0;
    regs->dh = 0x3;
    CF = 1;
loc_00003D98:
    return;
}

/*
 * Function at 0x00003D99
 */
void func_00003D99(CPU_REGS *regs)
{
    PUSH(regs->ax);
    PUSH(regs->es);
    PUSH(regs->di);
    PUSH(regs->bp);
    func_00003DB2(regs);
    if (CF) goto loc_00003DAD;
    PUSH(regs->es);
    regs->ds = POP();
    regs->si = regs->di;
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
loc_00003DA8:
    regs->bp = POP();
    regs->di = POP();
    regs->es = POP();
    regs->ax = POP();
    return;
loc_00003DAD:
    regs->ax = 0xffff;
    goto loc_00003DA8;
}

/*
 * Function at 0x00003DB2
 */
void func_00003DB2(CPU_REGS *regs)
{
    PUSH(regs->si);
    PUSH(regs->bx);
    regs->si = 0; CF = 0; ZF = 1;  /* ZERO SI: XOR with itself = 0 */
    regs->cx = 0; CF = 0; ZF = 1;  /* ZERO CX: XOR with itself = 0 */
    MEM[0x22e4] = 0x0;
    CMP(regs->dh, 0x0);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003DC5;
    goto loc_00003E34;
loc_00003DC5:
    CMP(regs->dh, 0x3);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003DCF;
    regs->si = 0x28;
    goto loc_00003DE4;
loc_00003DCF:
    TEST(regs->dh, 0x2);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00003DD7;
    regs->si = 0x10;
loc_00003DD7:
    CMP(regs->ax, 0x13);  /* COMPARISON: Testing condition for branch */
    if (CF) goto loc_00003DE4;
    CMP(regs->ax, 0x27);  /* COMPARISON: Testing condition for branch */
    if (!CF && !ZF) goto loc_00003DE4;
    regs->si = 0x1c;
loc_00003DE4:
    regs->bx = 0x22a1;
    regs->si += regs->bx; UPDATE_FLAGS_ADD();
loc_00003DEA:
    LOAD_FAR_PTR(&regs->es, &regs->di, MEM[regs->si]);
    regs->bx = regs->es;
    CMP(regs->bx, byte -0x1);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003E21;
    CMP(regs->dh, 0x3);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003E00;
    CF = 1;
    goto loc_00003E34;
loc_00003DFB:
    CMP(regs->ax, byte -0x1);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00003E34;
loc_00003E00:
    CMP(regs->dh, 0x1);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003E0C;
    func_00003E37(regs);
    regs->cx |= regs->cx; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_00003E33;
loc_00003E0C:
    CMP(MEM[0x22e4], 0x0);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003E34;
    MEM[0x22e4] = regs->ax;
    regs->ax = 0xffff;
    regs->bp = 0x1;
    regs->si = 0; CF = 0; ZF = 1;  /* ZERO SI: XOR with itself = 0 */
    CF = 0;
    goto loc_00003DC5;
loc_00003E21:
    CMP(regs->bx, 0x0);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00003E29;
    func_00003E69(regs);
loc_00003E29:
    regs->si += 0x4; UPDATE_FLAGS_ADD();
    if (regs->cx == 0) goto loc_00003DEA;
    CMP(regs->dh, 0x1);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00003DFB;
loc_00003E33:
    CF = 0;
loc_00003E34:
    regs->bx = POP();
    regs->si = POP();
    return;
}

/*
 * Function at 0x00003E37
 */
void func_00003E37(CPU_REGS *regs)
{
    PUSH(regs->dx);
    PUSH(regs->bp);
    PUSH(regs->cx);
    PUSH(regs->es);
    PUSH(regs->di);
    PUSH(regs->ax);
    regs->ax = 0x500;
    dos_multiplex_int(regs);  /* AH=05h: Unknown multiplex function 0x05 */
    CMP(regs->al, 0xff);
    regs->ax = POP();
    if (!ZF) goto loc_00003E63;
    regs->bx = regs->ax;
    regs->ax = 0x502;
    dos_multiplex_int(regs);  /* AH=05h: Unknown multiplex function 0x05 */
    if (CF) goto loc_00003E63;
    PUSH(regs->di);
    PUSH(regs->ax);
    regs->cx = 0xffff;
    regs->al = 0; CF = 0; ZF = 1;  /* ZERO AL: XOR with itself = 0 */
    STRING_SCAN_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->cx = ~regs->cx;
    regs->cx--; UPDATE_FLAGS_DEC();
    regs->ax = POP();
    regs->di = POP();
    regs->sp += 0x6; UPDATE_FLAGS_ADD();
    goto loc_00003E66;
loc_00003E63:
    regs->di = POP();
    regs->es = POP();
    regs->cx = POP();
loc_00003E66:
    regs->bp = POP();
    regs->dx = POP();
    return;
}

/*
 * Function at 0x00003E69
 */
void func_00003E69(CPU_REGS *regs)
{
    CMP(regs->bx, 0x1);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003E85;
    CMP(MEM[0x22d5], byte -0x1);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00003E85;
    CMP(regs->ax, byte -0x1);
    PUSH(regs->ax);
    if (!ZF) goto loc_00003E7E;
    regs->ax = MEM[0x22e4];
loc_00003E7E:
    CALL_INDIRECT(far [0x22d5]);
    regs->ax = POP();
    goto loc_00003E99;
loc_00003E85:
    regs->cx = 0; CF = 0; ZF = 1;  /* ZERO CX: XOR with itself = 0 */
    CMP(regs->dh, 0x3);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003E91;
    CMP(MEM[regs->di], regs->dh);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003E95;
loc_00003E91:
    regs->cl = MEM[regs->di + 0x1];
loc_00003E95:
    regs->di += 0x2; UPDATE_FLAGS_ADD();
    CF = 1;
loc_00003E99:
    if (!CF) goto loc_00003EAF;
    CF = 0;
loc_00003E9C:
    if (regs->cx == 0) goto loc_00003EBB;
    CMP(regs->ax, MEM[regs->di]);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00003EAB;
    regs->cx--; UPDATE_FLAGS_DEC();
    if (ZF) goto loc_00003EBB;
    regs->di += 0x4; UPDATE_FLAGS_ADD();
    goto loc_00003E9C;
loc_00003EAB:
    regs->di += MEM[regs->di + 0x2]; UPDATE_FLAGS_ADD();
loc_00003EAF:
    regs->ch = 0; CF = 0; ZF = 1;  /* ZERO CH: XOR with itself = 0 */
    regs->cl = MEM[regs->di];
    regs->di++; UPDATE_FLAGS_INC();
loc_00003EB5:
    MEM[0x22df] = 0x0;
    return;
loc_00003EBB:
    CF = 1;
    goto loc_00003EB5;
    MEM[regs->bx + regs->si] += regs->al; UPDATE_FLAGS_ADD();
    regs->di = 0x7;
    regs->di = 0x4;
    PUSH(regs->ds);
    PUSH(regs->es);
    regs->si = regs->cs;
    regs->ax = 0x50b0;
    regs->cl = 0x4;
    regs->ax >>= regs->cl;
    regs->si += regs->ax; UPDATE_FLAGS_ADD();
    regs->ds = regs->si;
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
    regs->si = 0; CF = 0; ZF = 1;  /* ZERO SI: XOR with itself = 0 */
    CMP(MEM[regs->si], 0x4f4c);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003EEE;
    CMP(MEM[regs->si + 0x2], 0x4f47);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003EEE;
    regs->ax = 0x3fee;
    PUSH(regs->cs);
    PUSH(regs->ax);
    PUSH(regs->ds);
    PUSH(regs->di);
    return; /* far */
loc_00003EEE:
    regs->es = POP();
    regs->ds = POP();
    return;
}

/* Zero-initialized data at 0x00003EF1 (38 bytes) */
static uint8_t data_00003EF1[38] = {0};

/*
 * Function at 0x00003F17
 */
void func_00003F17(CPU_REGS *regs)
{
    PUSH(regs->cx);
    regs->cx = regs->cs;
    regs->es = regs->cx;
    regs->cx = 0; CF = 0; ZF = 1;
    regs->ds = regs->cx;
    regs->di = 0x3ff1;
    DF = 0;
    regs->si = 0x410;
    STRING_MOVE_BYTE(regs);
    regs->si = 0x449;
    regs->cl = 0x1e;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->si = 0x484;
    regs->cl = 0x7;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->cx = POP();
    return;
}

/*
 * Function at 0x00003F38
 */
void func_00003F38(CPU_REGS *regs)
{
    regs->cx = regs->cs;
    regs->ds = regs->cx;
    regs->cx = 0; CF = 0; ZF = 1;
    regs->es = regs->cx;
    regs->si = 0x3ff1;
    DF = 0;
    regs->di = 0x410;
    STRING_MOVE_BYTE(regs);
    regs->di = 0x449;
    regs->cl = 0x1e;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->di = 0x484;
    regs->cl = 0x7;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    return;
}

/*
 * Function at 0x00003F57
 */
void func_00003F57(CPU_REGS *regs)
{
    func_00003F17(regs);
    regs->ax = 0x93;
    bios_video_int(regs);  /* AH=00h: Set video mode */
    regs->dx = 0x3da;
    regs->al = PORT_IN(regs->dx);
    regs->dl = 0xc0;
    regs->al = 0; CF = 0; ZF = 1;  /* ZERO AL: XOR with itself = 0 */
    PORT_OUT(regs->dx, regs->al);
    regs->dx = 0x3c4;
    regs->ax = 0xf02;
    PORT_OUT(regs->dx, regs->ax);
    regs->al = 0x4;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->al = PORT_IN(regs->dx);
    regs->al &= 0xf7; UPDATE_FLAGS_LOGIC();
    regs->al |= 0x4; UPDATE_FLAGS_LOGIC();
    PORT_OUT(regs->dx, regs->al);
    regs->dl = 0xce;
    regs->al = 0x5;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->al = PORT_IN(regs->dx);
    regs->al &= 0xe7; UPDATE_FLAGS_LOGIC();
    PORT_OUT(regs->dx, regs->al);
    regs->dx--; UPDATE_FLAGS_DEC();
    regs->al = 0x6;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->al = PORT_IN(regs->dx);
    regs->al &= 0xfd; UPDATE_FLAGS_LOGIC();
    PORT_OUT(regs->dx, regs->al);
    regs->ax = 0xa000;
    regs->es = regs->ax;
    if (regs->cx == 0) goto loc_00003F9B;
    regs->ax = 0; CF = 0; ZF = 1;  /* ZERO AX: XOR with itself = 0 */
    regs->di = 0x8000;
    DF = 0;
    STRING_STORE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
loc_00003F9B:
    regs->dx = 0x3d4;
    regs->ax = 0x800c;
    PORT_OUT(regs->dx, regs->ax);
    regs->al = 0x9;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->al = PORT_IN(regs->dx);
    regs->al &= 0xe0; UPDATE_FLAGS_LOGIC();
    PORT_OUT(regs->dx, regs->al);
    regs->dx--; UPDATE_FLAGS_DEC();
    regs->al = 0x14;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->al = PORT_IN(regs->dx);
    regs->al &= 0xbf; UPDATE_FLAGS_LOGIC();
    PORT_OUT(regs->dx, regs->al);
    regs->dx--; UPDATE_FLAGS_DEC();
    regs->al = 0x17;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->al = PORT_IN(regs->dx);
    regs->al |= 0x40; UPDATE_FLAGS_LOGIC();
    PORT_OUT(regs->dx, regs->al);
    return;
}

/*
 * Function at 0x00003FBD
 */
void func_00003FBD(CPU_REGS *regs)
{
    regs->dx = 0x3c4;
    regs->al = 0x2;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->al = PORT_IN(regs->dx);
    regs->al &= 0xf3; UPDATE_FLAGS_LOGIC();
    regs->al |= 0x3; UPDATE_FLAGS_LOGIC();
    PORT_OUT(regs->dx, regs->al);
    regs->dx--; UPDATE_FLAGS_DEC();
    regs->al = 0x4;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->al = PORT_IN(regs->dx);
    regs->al &= 0xfb; UPDATE_FLAGS_LOGIC();
    PORT_OUT(regs->dx, regs->al);
    regs->dl = 0xce;
    regs->ax = 0x4;
    PORT_OUT(regs->dx, regs->ax);
    regs->al = 0x5;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->al = PORT_IN(regs->dx);
    regs->al |= 0x10; UPDATE_FLAGS_LOGIC();
    PORT_OUT(regs->dx, regs->al);
    regs->dx--; UPDATE_FLAGS_DEC();
    regs->al = 0x6;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->al = PORT_IN(regs->dx);
    regs->al |= 0xe; UPDATE_FLAGS_LOGIC();
    regs->si = 0xb800;
    CMP(MEM[0x3ff2], 0x7);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00003FF9;
    regs->al &= 0xfb; UPDATE_FLAGS_LOGIC();
    regs->si = 0xb000;
loc_00003FF9:
    PORT_OUT(regs->dx, regs->al);
    regs->cx = 0x1e;
loc_00003FFD:
    regs->cx--; if (regs->cx != 0) goto loc_00003FFD;
    regs->es = regs->si;
    regs->si = 0; CF = 0; ZF = 1;
    regs->ah = MEM[regs->si + 0x3];
    regs->al = MEM[regs->si + 0x2];
    regs->eax <<= 0x10;
    regs->ah = MEM[regs->si + 0x1];
    regs->al = MEM[regs->si];
    PUSH(regs->eax);
    MEM[regs->si + 0x3] = 0x5a;
    MEM[regs->si + 0x2] = 0xa5;
    MEM[regs->si + 0x1] = 0x12;
    MEM[regs->si] = 0xef;
    regs->dl = 0xd4;
    regs->al = 0x17;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->al = PORT_IN(regs->dx);
    regs->al ^= 0x40; UPDATE_FLAGS_LOGIC();
    PORT_OUT(regs->dx, regs->al);
    regs->bh = MEM[regs->si + 0x3];
    regs->bl = MEM[regs->si + 0x2];
    regs->ebx <<= 0x10;
    regs->bh = MEM[regs->si + 0x1];
    regs->bl = MEM[regs->si];
    regs->al ^= 0x40; UPDATE_FLAGS_LOGIC();
    PORT_OUT(regs->dx, regs->al);
    regs->eax = POP();
    MEM[regs->si] = regs->al;
    MEM[regs->si + 0x1] = regs->ah;
    regs->eax >>= 0x10;
    MEM[regs->si + 0x2] = regs->al;
    MEM[regs->si + 0x3] = regs->ah;
    CMP(regs->ebx, 0x5aa512ef);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00004073;
    regs->dl = 0xd4;
    regs->al = 0x17;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->al = PORT_IN(regs->dx);
    regs->al &= 0xbf; UPDATE_FLAGS_LOGIC();
    PORT_OUT(regs->dx, regs->al);
loc_00004073:
    regs->dx = 0x3da;
    regs->al = PORT_IN(regs->dx);
    regs->dl = 0xc0;
    regs->al = 0x20;
    PORT_OUT(regs->dx, regs->al);
    return;
}

/*
 * Function at 0x0000407D
 */
void func_0000407D(CPU_REGS *regs)
{
    regs->ax = 0x1a00;
    bios_video_int(regs);  /* AH=1Ah: Get/set display combination code */
    CMP(regs->al, 0x1a);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_00004098;
    regs->bl |= regs->bl; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_0000408C;
    regs->bl = regs->bh;
loc_0000408C:
    CMP(regs->bl, 0x7);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_00004098;
    CMP(regs->bl, 0x8);
    CF = 1;
    if (!ZF) goto loc_00004098;
    CF = 0;
loc_00004098:
    return;
}

/*
 * Function at 0x00004099
 */
void func_00004099(CPU_REGS *regs)
{
    regs->ax = regs->cs;
    regs->ds = regs->ax;
    func_0000407D(regs);
    if (CF) goto loc_00004098;
    regs->ax = regs->cs;
    regs->ds = regs->ax;
    regs->es = regs->ax;
    func_00001E11(regs);
    regs->cx = 0x9;
    regs->si = 0x50a6;
    regs->di = 0x6ef;
    func_000002B8(regs);
    regs->ax = 0x3d00;
    regs->dx = 0x6ef;
    dos_int21(regs);  /* AH=3Dh: Open file */
    if (CF) goto loc_00004098;
    MEM[0x472e] = regs->ax;
    regs->bx = regs->ax;
    regs->ah = 0x3f;
    regs->cx = 0x800;
    regs->dx = 0x4730;
    dos_int21(regs);  /* AH=3Fh: Read from file/device */
    if (CF) goto loc_00004098;
    regs->bx = 0x4730;
    CMP(MEM[regs->bx], 0x4d42);
loc_000040DC:
    CF = 1;
    if (!ZF) goto loc_00004098;
    regs->bx = 0x473e;
    CMP(MEM[regs->bx], 0x28);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000040DC;
    CMP(MEM[regs->bx + 0xc], 0x1);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000040DC;
    CMP(MEM[regs->bx + 0xe], 0x8);  /* COMPARISON: Testing condition for branch */
    if (!ZF) goto loc_000040DC;
    PUSH_ALL(regs);
    regs->dx = 0x3ce;
    regs->al = 0x6;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->al = PORT_IN(regs->dx);
    TEST(regs->al, 0x1);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_0000413F;
    TEST(regs->al, 0x8);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_0000413F;
    regs->ah = 0xf;
    bios_video_int(regs);  /* AH=0Fh: Get current video mode */
    regs->ah = 0x3;
    bios_video_int(regs);  /* AH=03h: Get cursor position and shape */
    regs->dl |= regs->dh; UPDATE_FLAGS_LOGIC();
    if (ZF) goto loc_0000413F;
    regs->ax = 0x44;
    func_000013D0(regs);
    regs->ah = 0x2c;
    dos_int21(regs);  /* AH=2Ch: Get system time */
    regs->bx = regs->dx;
loc_0000411C:
    regs->ah = 0xb;
    dos_int21(regs);  /* AH=0Bh: Check keyboard status */
    TEST(regs->al, regs->al);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00004138;
    regs->ah = 0x2c;
    dos_int21(regs);  /* AH=2Ch: Get system time */
    regs->dl = regs->dh;
    regs->dl -= regs->bh; UPDATE_FLAGS_SUB();
    if (SF == OF) goto loc_00004131;
    regs->dl += 0x3c; UPDATE_FLAGS_ADD();
loc_00004131:
    CMP(regs->dl, 0x1e);  /* COMPARISON: Testing condition for branch */
    if (SF != OF) goto loc_0000411C;
    goto loc_0000413F;
loc_00004138:
    regs->ax = 0xc06;
    regs->dl = 0xff;
    dos_int21(regs);  /* AH=0Ch: Flush buffer and read keyboard */
loc_0000413F:
    regs->ax = 0x3;
    bios_video_int(regs);  /* AH=00h: Set video mode */
    regs->cx = 0x8000;
    func_00003F57(regs);
    regs->ax = regs->cs;
    regs->ds = regs->ax;
    regs->es = regs->ax;
    POP_ALL(regs);
    regs->si = regs->bx + 0x28;
    regs->bx = 0; CF = 0; ZF = 1;  /* ZERO BX: XOR with itself = 0 */
    regs->cx = 0x100;
    func_000042C2(regs);
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_0000416E;
    regs->di = regs->ax;
    regs->dx = 0x3da;
    regs->al = PORT_IN(regs->dx);
    regs->dl = 0xc0;
    regs->al = 0x11;
    PORT_OUT(regs->dx, regs->al);
    regs->ax = regs->di;
    PORT_OUT(regs->dx, regs->al);
loc_0000416E:
    regs->ax = 0xa000;
    regs->es = regs->ax;
    regs->di = 0xfcb0;
    regs->bx = 0x4b66;
    regs->si = 0x3ca;
loc_0000417C:
    regs->ax = regs->si;
    regs->dx = 0; CF = 0; ZF = 1;  /* ZERO DX: XOR with itself = 0 */
    regs->cx = 0x140;
    DIV_UNSIGNED(regs->cx);
    regs->dx = regs->si;
    regs->cx = regs->ax;
    PUSH(regs->cx);
    PUSH(regs->dx);
loc_0000418B:
    PUSH(regs->cx);
    func_0000424C(regs);
    regs->cx = POP();
    regs->bx += MEM[0x4742]; UPDATE_FLAGS_ADD();
    regs->di -= 0x50; UPDATE_FLAGS_SUB();
    regs->cx--; if (regs->cx != 0) goto loc_0000418B;
    regs->cx = POP();
    regs->ax = POP();
    MEM[0x4746] -= regs->ax; UPDATE_FLAGS_SUB();
    if (ZF || SF != OF) goto loc_000041D6;
    regs->si = regs->bx;
    regs->bx = 0x140;
    MUL_UNSIGNED(regs->bx);
    regs->cx -= regs->ax; UPDATE_FLAGS_SUB();
    PUSH(regs->di);
    regs->ax = regs->cs;
    regs->es = regs->ax;
    regs->di = 0x4766;
    PUSH(regs->cx);
    DF = 0;
    STRING_MOVE_BYTE(regs);  /* STRING OPERATION: Repeat CX times */
    regs->dx = regs->di;
    regs->bx = MEM[0x472e];
    regs->ah = 0x3f;
    regs->cx = 0x800;
    dos_int21(regs);  /* AH=3Fh: Read from file/device */
    regs->si = POP();
    regs->di = POP();
    regs->ax = 0xa000;
    regs->es = regs->ax;
    regs->si += 0x800; UPDATE_FLAGS_ADD();
    regs->bx = 0x4766;
    goto loc_0000417C;
loc_000041D6:
    regs->bx = MEM[0x472e];
    regs->ah = 0x3e;
    dos_int21(regs);  /* AH=3Eh: Close file */
    CF = 0;
    return;
}

/*
 * Function at 0x000041E1
 */
void func_000041E1(CPU_REGS *regs)
{
    PUSH(regs->ds);
    PUSH(regs->es);
    regs->bl = 0x0;
    regs->ax = 0x160e;
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
    TEST(regs->ax, regs->ax);  /* BIT TEST: Checking flags for branch */
    if (!ZF) goto loc_00004249;
    TEST(regs->dx, regs->dx);  /* BIT TEST: Checking flags for branch */
    if (ZF) goto loc_00004249;
    PUSH(regs->dx);
    regs->cx = 0; CF = 0; ZF = 1;
    func_00003F57(regs);
    regs->dx = POP();
    regs->cx = 0x190;
    regs->bx = 0; CF = 0; ZF = 1;
    regs->si = 0x8000;
loc_00004201:
    func_0000429A(regs);
    regs->cx--; if (regs->cx != 0) goto loc_00004201;
    CMP(regs->bx, regs->dx);  /* COMPARISON: Testing condition for branch */
    if (ZF) goto loc_0000422F;
    func_00003F38(regs);
    regs->bl = MEM[0x462];
    regs->bh = 0x0;
    regs->di = regs->bx;
    regs->dx = MEM[regs->bx + regs->di + 0x450];
    PUSH(regs->dx);
    regs->ax = 0x80;
    regs->al |= MEM[0x449]; UPDATE_FLAGS_LOGIC();
    bios_video_int(regs);  /* AH=00h: Set video mode */
    regs->dx = POP();
    regs->bh = regs->bl;
    regs->ah = 0x2;
    bios_video_int(regs);  /* AH=02h: Set cursor position */
    goto loc_00004249;
loc_0000422F:
    PUSH(regs->es);
    regs->ds = POP();
    regs->ax = 0; CF = 0; ZF = 1;
    regs->si = 0xfd00;
    regs->cx = 0x100;
    func_00004617(regs);
    func_00003FBD(regs);
    func_00003F38(regs);
    regs->bl = 0x4;
    regs->ax = 0x160e;
    dos_multiplex_int(regs);  /* AH=16h: Windows Enhanced mode */
loc_00004249:
    regs->es = POP();
    regs->ds = POP();
    return;
}

/*
 * Function at 0x0000424C
 */
void func_0000424C(CPU_REGS *regs)
{
    PUSH(regs->bp);
    DF = 0;
    regs->dx = 0x3c4;
    regs->cx = MEM[0x4742];
    regs->cx >>= 0x2;
    regs->bp = regs->cx;
    regs->ax = 0x102;
    PORT_OUT(regs->dx, regs->ax);
    regs->si = regs->bx;
    PUSH(regs->di);
loc_00004262:
    STRING_LOAD_DWORD(regs);
    STRING_STORE_BYTE(regs);
    regs->cx--; if (regs->cx != 0) goto loc_00004262;
    regs->di = POP();
    regs->ax = 0x202;
    PORT_OUT(regs->dx, regs->ax);
    regs->si = regs->bx + 0x1;
    regs->cx = regs->bp;
    PUSH(regs->di);
loc_00004272:
    STRING_LOAD_DWORD(regs);
    STRING_STORE_BYTE(regs);
    regs->cx--; if (regs->cx != 0) goto loc_00004272;
    regs->di = POP();
    regs->ax = 0x402;
    PORT_OUT(regs->dx, regs->ax);
    regs->si = regs->bx + 0x2;
    regs->cx = regs->bp;
    PUSH(regs->di);
loc_00004282:
    STRING_LOAD_DWORD(regs);
    STRING_STORE_BYTE(regs);
    regs->cx--; if (regs->cx != 0) goto loc_00004282;
    regs->di = POP();
    regs->ax = 0x802;
    PORT_OUT(regs->dx, regs->ax);
    regs->si = regs->bx + 0x3;
    regs->cx = regs->bp;
    PUSH(regs->di);
loc_00004292:
    STRING_LOAD_DWORD(regs);
    STRING_STORE_BYTE(regs);
    regs->cx--; if (regs->cx != 0) goto loc_00004292;
    regs->di = POP();
    regs->bp = POP();
    return;
}

/*
 * Function at 0x0000429A
 */
void func_0000429A(CPU_REGS *regs)
{
    DF = 0;
    PUSH(regs->cx);
    PUSH(regs->dx);
    regs->cx = 0x50;
    regs->dx = 0x3ce;
    regs->ax = 0x4;
loc_000042A6:
    PORT_OUT(regs->dx, regs->ax);
    PUSH(regs->ax);
    PUSH(regs->cx);
    PUSH(regs->si);
    regs->ah = 0x0;
loc_000042AC:
    STRING_LOAD_BYTE(regs);
    regs->bx += regs->ax; UPDATE_FLAGS_ADD();
    regs->cx--; UPDATE_FLAGS_DEC();
    if (!ZF) goto loc_000042AC;
    regs->si = POP();
    regs->cx = POP();
    regs->ax = POP();
    regs->ah++; UPDATE_FLAGS_INC();
    CMP(regs->ah, 0x4);  /* COMPARISON: Testing condition for branch */
    if (CF) goto loc_000042A6;
    regs->si += regs->cx; UPDATE_FLAGS_ADD();
    regs->dx = POP();
    regs->cx = POP();
    return;
}

/*
 * Function at 0x000042C2
 */
void func_000042C2(CPU_REGS *regs)
{
    PUSH(regs->si);
    PUSH(regs->di);
    PUSH(regs->ds);
    regs->ax = regs->bx;
    regs->ax += regs->cx; UPDATE_FLAGS_ADD();
    regs->ax -= 0x100; UPDATE_FLAGS_SUB();
    if (ZF || SF != OF) goto loc_000042D0;
    regs->cx -= regs->ax; UPDATE_FLAGS_SUB();
loc_000042D0:
    PUSH(regs->bx);
    PUSH(regs->cx);
    regs->di = 0x4417;
    regs->ax = regs->cs;
    regs->es = regs->ax;
    regs->bx |= byte -0x1; UPDATE_FLAGS_LOGIC();
    DF = 0;
loc_000042DE:
    STRING_LOAD_WORD(regs);
    regs->dx = regs->ax;
    STRING_LOAD_WORD(regs);
    regs->al >>= 0x2;
    regs->dl >>= 0x2;
    regs->dh >>= 0x2;
    STRING_STORE_BYTE(regs);
    XCHG(regs->dl, regs->dh);
    XCHG(regs->ax, regs->dx);
    STRING_STORE_WORD(regs);
    TEST(regs->bx, regs->bx);  /* BIT TEST: Checking flags for branch */
    if (!SF) goto loc_000042FC;
    regs->dl |= regs->al; UPDATE_FLAGS_LOGIC();
    regs->dl |= regs->ah; UPDATE_FLAGS_LOGIC();
    if (!ZF) goto loc_000042FC;
    regs->bx = regs->cx;
loc_000042FC:
    regs->cx--; if (regs->cx != 0) goto loc_000042DE;
    regs->si = 0x4417;
    regs->ax = regs->cs;
    regs->ds = regs->ax;
    regs->cx = POP();
    regs->di = regs->cx;
    regs->di -= regs->bx; UPDATE_FLAGS_SUB();
    regs->bx = POP();
    regs->di += regs->bx; UPDATE_FLAGS_ADD();
    XCHG(regs->ax, regs->bx);
    func_00004617(regs);
    XCHG(regs->ax, regs->di);
    regs->ds = POP();
    regs->di = POP();
    regs->si = POP();
    return;
}

/* Zero-initialized data at 0x00004317 (768 bytes) */
static uint8_t data_00004317[768] = {0};

/*
 * Function at 0x00004617
 */
void func_00004617(CPU_REGS *regs)
{
    regs->dx = 0x3c8;
    PORT_OUT(regs->dx, regs->al);
    regs->dx++; UPDATE_FLAGS_INC();
    regs->bx = regs->cx;
    regs->cx += regs->cx; UPDATE_FLAGS_ADD();
    regs->cx += regs->bx; UPDATE_FLAGS_ADD();
loc_00004622:
    PUSH(regs->cx);
    regs->cx = 0x14;
loc_00004626:
    regs->cx--; if (regs->cx != 0) goto loc_00004626;
    regs->cx = POP();
    STRING_LOAD_BYTE(regs);
    PORT_OUT(regs->dx, regs->al);
    regs->cx--; if (regs->cx != 0) goto loc_00004622;
    return;
}

/* Zero-initialized data at 0x0000462E (2424 bytes) */
static uint8_t data_0000462E[2424] = {0};

/* String data at 0x00004FA6 */
static const char str_00004FA6[] = "logos.sys";


/* Code block at 0x00004FB0 */
void code_00004FB0(CPU_REGS *regs)
{
loc_00004FB0:
    regs->ds = POP();
    MEM[regs->bx] += regs->bx + CF; UPDATE_FLAGS_ADC();
    MEM[regs->di + 0x4e] += regs->ax + CF; UPDATE_FLAGS_ADC();
    PUSH(regs->bp);
    MEM[regs->bx + regs->si] += regs->ax; UPDATE_FLAGS_ADD();
    regs->ch = 0x1;
    regs->si--; UPDATE_FLAGS_DEC();
    PUSH(regs->bx);
    PUSH(regs->di);
    regs->cx--; UPDATE_FLAGS_DEC();
    MEM[regs->bp + regs->di] += regs->al; UPDATE_FLAGS_ADD();
    PUSH(regs->es);
    MEM[regs->bp + regs->si] += regs->cl; UPDATE_FLAGS_ADD();
    MEM[0x100] += regs->cl; UPDATE_FLAGS_ADD();
    regs->di += regs->di; UPDATE_FLAGS_ADD();
    MEM[regs->si + 0x1]++; UPDATE_FLAGS_INC();
    regs->al += MEM[regs->bx + regs->di]; UPDATE_FLAGS_ADD();
    /* data: ['0xff'] */
    CALL_INDIRECT(MEM[regs->bx + regs->si + 0x1]);
    regs->cx += MEM[regs->bp + 0x64]; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->di + 0x1] += regs->bl; UPDATE_FLAGS_ADD();
    MEM[regs->bp + regs->si + 0x1] += regs->dh; UPDATE_FLAGS_ADD();
    MEM[regs->si + 0x1] += regs->dh; UPDATE_FLAGS_ADD();
    MEM[regs->ebp + 0x1] += regs->dh; UPDATE_FLAGS_ADD();
    PUSH(0x7600);
    MEM[regs->bx + regs->di + 0x0] += regs->bp; UPDATE_FLAGS_ADD();
    if (CF || ZF) goto loc_00004FEE;
    PUSH(0x0);
    regs->sp = 0x6b01;
    regs->dl += regs->bl; UPDATE_FLAGS_ADD();
    MEM[regs->si + 0x0] += regs->bp; UPDATE_FLAGS_ADD();
    FPU_FLD(MEM[regs->bx + regs->di]);
    /* 00004FF9  6D                insw                   ; Input string word from port DX to ES:[DI] */
    regs->dl += regs->ah; UPDATE_FLAGS_ADD();
    MEM[regs->bp + 0x0] += regs->bp; UPDATE_FLAGS_ADD();
    func_0000BF03(regs);
    regs->ah += regs->ch; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si + 0x0] += regs->si; UPDATE_FLAGS_ADD();
    goto loc_0000500A;
    if (!OF) goto loc_0000500B;
loc_0000500B:
    MEM[regs->bp + regs->si + 0x0] += regs->si; UPDATE_FLAGS_ADD();  /* STRING OPERATION: Repeat CX times */
    CF = 1;
    MEM[regs->bp + regs->di + 0x0] += regs->si; UPDATE_FLAGS_ADD();
    DF = 1;
    MEM[regs->si + 0x0] += regs->si; UPDATE_FLAGS_ADD();
    regs->al += MEM[regs->bp + regs->si]; UPDATE_FLAGS_ADD();
    if (!ZF) goto loc_0000501B;
loc_0000501B:
    regs->ax += 0x7602 + CF; UPDATE_FLAGS_ADC();
    MEM[regs->bx + regs->si] += regs->bh; UPDATE_FLAGS_ADD();
    regs->dh += MEM[regs->bx + 0x0]; UPDATE_FLAGS_ADD();
    regs->bh += MEM[regs->bx + regs->si + 0x0]; UPDATE_FLAGS_ADD();
loc_00005027:
    regs->di--; UPDATE_FLAGS_DEC();
    regs->bh += MEM[regs->bx + regs->di + 0x0]; UPDATE_FLAGS_ADD();
    regs->cx = POP();
    regs->bh += MEM[regs->bp + regs->si + 0x0]; UPDATE_FLAGS_ADD();
    PUSH_ALL(regs);
    regs->bh += MEM[regs->bp + regs->di + 0x0]; UPDATE_FLAGS_ADD();
    if (ZF) goto loc_00005037;
    if (SF != OF) goto loc_00005037;
loc_00005037:
    if (SF != OF) goto loc_0000503B;
    if (SF == OF) goto loc_0000503B;
loc_0000503B:
    /* fwait */
    MEM[0x7f02] = regs->ax;
    MEM[regs->bp + regs->di - 0x7ffe] += regs->dh; UPDATE_FLAGS_ADD();
    regs->cl += regs->al; UPDATE_FLAGS_ADD();
    regs->al += MEM[regs->bx + regs->di - 0x2700]; UPDATE_FLAGS_ADD();
    regs->al += MEM[regs->bp + regs->si - 0x1800]; UPDATE_FLAGS_ADD();
    regs->al += MEM[regs->bp + regs->di - 0xa00]; UPDATE_FLAGS_ADD();
    regs->al += MEM[regs->si + 0x300]; UPDATE_FLAGS_ADD();
    regs->ax += MEM[regs->di + 0x1200]; UPDATE_FLAGS_ADD();
    regs->ax += MEM[regs->bp + 0x1e00]; UPDATE_FLAGS_ADD();
    regs->ax += MEM[regs->bx + 0x2f00]; UPDATE_FLAGS_ADD();
    regs->cx += MEM[regs->bx + regs->si + 0x3c00]; UPDATE_FLAGS_ADD();
    regs->cx += MEM[regs->bx + regs->di + 0x5300]; UPDATE_FLAGS_ADD();
    regs->cx += MEM[regs->bp + regs->si + 0x6300]; UPDATE_FLAGS_ADD();
    regs->cx += MEM[regs->bp + regs->di + 0x6d00]; UPDATE_FLAGS_ADD();
    regs->cx += MEM[regs->si - 0x7e00]; UPDATE_FLAGS_ADD();
    regs->dx += MEM[regs->si]; UPDATE_FLAGS_ADD();
    regs->bh += regs->ah; UPDATE_FLAGS_ADD();
    regs->dx += MEM[0x4800]; UPDATE_FLAGS_ADD();
    regs->al += 0x17; UPDATE_FLAGS_ADD();
    MEM[regs->bp + regs->di + 0x1804] += regs->dh; UPDATE_FLAGS_ADD();
    regs->dl += regs->bh; UPDATE_FLAGS_ADD();
    regs->al += 0x19; UPDATE_FLAGS_ADD();
    MEM[regs->bp + 0x5] += regs->al; UPDATE_FLAGS_ADD();
    regs->al -= MEM[regs->bx + regs->si] + CF; UPDATE_FLAGS_SBB();
    TEST(MEM[regs->di], regs->ax);
    PUSH(regs->ds);
    regs->dl += regs->dh; UPDATE_FLAGS_ADD();
    regs->ax += 0x1f; UPDATE_FLAGS_ADD();
    regs->al ^= MEM[0x20]; UPDATE_FLAGS_LOGIC();
    regs->bp++; UPDATE_FLAGS_INC();
    PUSH(regs->es);
    MEM[regs->bx + regs->si] &= regs->ax; UPDATE_FLAGS_LOGIC();
    regs->di = POP();
    PUSH(regs->es);
    regs->al &= MEM[regs->bx + regs->si]; UPDATE_FLAGS_LOGIC();
    STRING_MOVE_BYTE(regs);
    PUSH(regs->es);
    regs->ax &= MEM[regs->bx + regs->si]; UPDATE_FLAGS_LOGIC();
    regs->al |= 0x7; UPDATE_FLAGS_LOGIC();
    regs->al &= 0x0; UPDATE_FLAGS_LOGIC();
    PORT_OUTPUT_STRING_BYTE(regs);
    regs->es = POP();
    regs->ax &= 0xe000; UPDATE_FLAGS_LOGIC();
    regs->es = POP();
    MEM[regs->di] += regs->ah; UPDATE_FLAGS_ADD();
    MEM[regs->bx] |= regs->ah; UPDATE_FLAGS_LOGIC();
    MEM[regs->bx + regs->si + 0x8] += regs->dl; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] -= regs->al; UPDATE_FLAGS_SUB();
    XCHG(regs->ax, regs->di);
    MEM[regs->bx + regs->di] |= regs->ch; UPDATE_FLAGS_LOGIC();
    regs->al += regs->ah; UPDATE_FLAGS_ADD();
    MEM[regs->bp + regs->si] |= regs->ch; UPDATE_FLAGS_LOGIC();
    regs->dh += regs->dh; UPDATE_FLAGS_ADD();
    MEM[regs->bp + regs->di] |= regs->ch; UPDATE_FLAGS_LOGIC();
    MEM[0x2c09] += regs->dh; UPDATE_FLAGS_ADD();
    MEM[regs->bp + regs->si + 0x2d09] += regs->al; UPDATE_FLAGS_ADD();
    MEM[regs->bp + regs->di + 0x2f09] += regs->ah; UPDATE_FLAGS_ADD();
    regs->bh += regs->ah; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] |= regs->si; UPDATE_FLAGS_LOGIC();
    MEM[regs->bp + 0xa] += regs->ch; UPDATE_FLAGS_ADD();
    MEM[regs->bx + regs->si] ^= regs->ax; UPDATE_FLAGS_LOGIC();
    IF_FLAG = 1; /* enable interrupts */
    regs->bh |= MEM[regs->si]; UPDATE_FLAGS_LOGIC();
    MEM[regs->bx + 0x3d0b] += regs->ch; UPDATE_FLAGS_ADD();
    MEM[0x3e0c] += regs->ch; UPDATE_FLAGS_ADD();
    MEM[regs->si + 0x3f0c] += regs->bh; UPDATE_FLAGS_ADD();
    regs->dl += regs->ch; UPDATE_FLAGS_ADD();
    regs->al |= 0x40; UPDATE_FLAGS_LOGIC();
    MEM[regs->si] += regs->dl; UPDATE_FLAGS_ADD();
    regs->ax |= 0x41; UPDATE_FLAGS_LOGIC();
    regs->al ^= 0xd; UPDATE_FLAGS_LOGIC();
    regs->dx++; UPDATE_FLAGS_INC();
    regs->cl += regs->ch; UPDATE_FLAGS_ADD();
    regs->ax |= 0x43; UPDATE_FLAGS_LOGIC();
    PORT_INPUT_STRING_BYTE(regs);
    PUSH(regs->cs);
    regs->sp++; UPDATE_FLAGS_INC();
    regs->bh += regs->ah; UPDATE_FLAGS_ADD();
    PUSH(regs->cs);
    regs->si++; UPDATE_FLAGS_INC();
    MEM[regs->bp + regs->di] += regs->al; UPDATE_FLAGS_ADD();
    if (!CF && !ZF) regs->ax = MEM[regs->bx + regs->si];
    regs->cl -= MEM[regs->bx]; UPDATE_FLAGS_SUB();
    ARPL(MEM[regs->bx + regs->si], regs->ax);
    STRING_CMP_WORD(regs);
    SSE_MOVUPS(MEM[regs->di + 0x78], xmm0);
}

/* String data at 0x00005110 */
static const char str_00005110[] = "tended Error ";


/* Code at 0x0000511D */
void code_0000511D(CPU_REGS *regs)
{
    regs->ax &= 0xe31; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005120 */
static const char str_00005120[] = "Parse Error ";


/* Code at 0x0000512C */
void code_0000512C(CPU_REGS *regs)
{
    regs->ax &= 0x1c31; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x0000512F */
static const char str_0000512F[] = ": Missing/unable to loa";


/* Code at 0x00005146 */
void code_00005146(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
    regs->ax += 0x5241; UPDATE_FLAGS_ADD();
    regs->cx--; UPDATE_FLAGS_DEC();
    regs->si++; UPDATE_FLAGS_INC();
    regs->ax -= 0x5904; UPDATE_FLAGS_SUB();
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
    regs->al += 0x4e; UPDATE_FLAGS_ADD();
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
    regs->cx += MEM[regs->di]; UPDATE_FLAGS_ADD();
    regs->ah |= MEM[regs->si]; UPDATE_FLAGS_LOGIC();
    regs->cx--; UPDATE_FLAGS_DEC();
    regs->ax |= 0x570a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005163 */
static const char str_00005163[] = "indows has stopped. Press CTRL+ALT+DELETE to restart your computer.";


/* Code at 0x000051A6 */
void code_000051A6(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
loc_000051A9:
    MEM[regs->di] &= regs->cx; UPDATE_FLAGS_LOGIC();
    regs->dl |= MEM[regs->bx + 0x69]; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000051AE */
static const char str_000051AE[] = "ndows is now restarting..";


/* Code at 0x000051C7 */
void code_000051C7(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
    PUSH(regs->es);
}

/* String data at 0x000051CC */
static const char str_000051CC[] = "Abort$";


/* Code at 0x000051D2 */
void code_000051D2(CPU_REGS *regs)
{
    MEM[regs->si] |= regs->ch; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000051D4 */
static const char str_000051D4[] = " Retry$";


/* Code block at 0x000051DB */
void code_000051DB(CPU_REGS *regs)
{
loc_000051DB:
    MEM[regs->si] |= regs->bp; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000051DD */
static const char str_000051DD[] = " Ignore";


/* Code at 0x000051E4 */
void code_000051E4(CPU_REGS *regs)
{
    regs->al &= 0x7; UPDATE_FLAGS_LOGIC();
    regs->al -= 0x20; UPDATE_FLAGS_SUB();
    regs->si++; UPDATE_FLAGS_INC();
    POP_ALL(regs);
    regs->bp = MEM[regs->si + 0x24] * 0x3f02;
    regs->al &= 0xa; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000051F1 */
static const char str_000051F1[] = " reading $";


/* Code at 0x000051FB */
void code_000051FB(CPU_REGS *regs)
{
    regs->ah |= MEM[regs->bx + regs->si]; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000051FD */
static const char str_000051FD[] = "writing $";


/* Code at 0x00005206 */
void code_00005206(CPU_REGS *regs)
{
    regs->es = POP();
}

/* String data at 0x00005207 */
static const char str_00005207[] = "drive $";


/* Code block at 0x0000520E */
void code_0000520E(CPU_REGS *regs)
{
loc_0000520E:
    MEM[regs->si + 0x65] |= regs->ah; UPDATE_FLAGS_LOGIC();
    if (CF || ZF) goto loc_0000527C;
    ARPL(MEM[regs->di + 0x20], regs->sp);
    regs->al &= 0x16; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005218 */
static const char str_00005218[] = "Please insert volume $&File allocation table bad, drive %";


/* Code at 0x00005251 */
void code_00005251(CPU_REGS *regs)
{
    MEM[regs->di] ^= regs->cx; UPDATE_FLAGS_LOGIC();
    regs->ah |= MEM[regs->si]; UPDATE_FLAGS_LOGIC();
    MEM[regs->bx + regs->si] |= regs->sp; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005257 */
static const char str_00005257[] = "serial $";


/* Code at 0x0000525F */
void code_0000525F(CPU_REGS *regs)
{
    regs->al += 0x57 + CF; UPDATE_FLAGS_ADC();
}

/* String data at 0x00005261 */
static const char str_00005261[] = "rite protect error$";


/* Code at 0x00005274 */
void code_00005274(CPU_REGS *regs)
{
    regs->ax |= 0x6e49; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005277 */
static const char str_00005277[] = "valid un";


/* Code at 0x0000527F */
void code_0000527F(CPU_REGS *regs)
{
    regs->si = MEM[regs->si + 0x24] * 0x4e0a;
}

/* String data at 0x00005284 */
static const char str_00005284[] = "ot ready$";


/* Code at 0x0000528D */
void code_0000528D(CPU_REGS *regs)
{
    regs->ss = POP();
}

/* String data at 0x0000528E */
static const char str_0000528E[] = "Invalid device request";


/* Code at 0x000052A4 */
void code_000052A4(CPU_REGS *regs)
{
    regs->al &= 0xb; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000052A6 */
static const char str_000052A6[] = "Data error$\"Invalid device request parameters";


/* Code at 0x000052D3 */
void code_000052D3(CPU_REGS *regs)
{
    regs->al &= 0xb; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000052D5 */
static const char str_000052D5[] = "Seek error$";


/* Code at 0x000052E0 */
void code_000052E0(CPU_REGS *regs)
{
    regs->cx += MEM[regs->bx + regs->di + 0x6e] + CF; UPDATE_FLAGS_ADC();
}

/* String data at 0x000052E3 */
static const char str_000052E3[] = "valid media type";


/* Code block at 0x000052F3 */
void code_000052F3(CPU_REGS *regs)
{
loc_000052F3:
    regs->al &= 0x11; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000052F5 */
static const char str_000052F5[] = "Sector not foun";


/* Code block at 0x00005304 */
void code_00005304(CPU_REGS *regs)
{
loc_00005304:
    regs->al &= 0x1b; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005307 */
static const char str_00005307[] = "Printer out of paper error$";


/* Code at 0x00005322 */
void code_00005322(CPU_REGS *regs)
{
    regs->dl += MEM[regs->bx + 0x72] + CF; UPDATE_FLAGS_ADC();
}

/* String data at 0x00005325 */
static const char str_00005325[] = "ite fault error$";


/* Code at 0x00005335 */
void code_00005335(CPU_REGS *regs)
{
    MEM[regs->bp + regs->si + 0x65] += regs->dx + CF; UPDATE_FLAGS_ADC();
}

/* String data at 0x00005338 */
static const char str_00005338[] = "ad fault error$";


/* Code at 0x00005347 */
void code_00005347(CPU_REGS *regs)
{
    MEM[regs->bx + 0x65] += regs->al + CF; UPDATE_FLAGS_ADC();
}

/* String data at 0x0000534A */
static const char str_0000534A[] = "neral failure";


/* Code at 0x00005357 */
void code_00005357(CPU_REGS *regs)
{
    regs->al &= 0x12; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005359 */
static const char str_00005359[] = "Sharing violat";


/* Code at 0x00005367 */
void code_00005367(CPU_REGS *regs)
{
    regs->bp = MEM[regs->bx + 0x6e] * 0xf24;
}

/* String data at 0x0000536C */
static const char str_0000536C[] = "Lock violation";


/* Code at 0x0000537A */
void code_0000537A(CPU_REGS *regs)
{
    regs->al &= 0x14; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x0000537C */
static const char str_0000537C[] = "Invalid disk chan";


/* Code at 0x0000538D */
void code_0000538D(CPU_REGS *regs)
{
    regs->al &= 0x10; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005391 */
static const char str_00005391[] = "FCB unavailabl";


/* Code at 0x0000539F */
void code_0000539F(CPU_REGS *regs)
{
    regs->al &= 0x1a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000053A2 */
static const char str_000053A2[] = "System resource exhauste";


/* Code at 0x000053BA */
void code_000053BA(CPU_REGS *regs)
{
    regs->al &= 0x13; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000053BD */
static const char str_000053BD[] = "Code page mismatc";


/* Code at 0x000053CE */
void code_000053CE(CPU_REGS *regs)
{
    PUSH(0xd24);
}

/* String data at 0x000053D1 */
static const char str_000053D1[] = "Out of input$";


/* Code at 0x000053DE */
void code_000053DE(CPU_REGS *regs)
{
    MEM[regs->bx + regs->di + 0x6e] -= regs->cl + CF; UPDATE_FLAGS_SBB();
}

/* String data at 0x000053E1 */
static const char str_000053E1[] = "sufficientdisk space$hYou can now safely turn off your computer.";


/* Code at 0x00005422 */
void code_00005422(CPU_REGS *regs)
{
    regs->ax |= 0x490a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005425 */
static const char str_00005425[] = "f you want to restart your computer, press CTRL+ALT+DEL";


/* Code at 0x0000545C */
void code_0000545C(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005460 */
static const char str_00005460[] = "dCannot run Windows on this computer.";


/* Code block at 0x00005485 */
void code_00005485(CPU_REGS *regs)
{
loc_00005485:
    regs->ax |= 0x570a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005488 */
static const char str_00005488[] = "indows requires a computer with a 386 processor or better.";


/* Code at 0x000054C2 */
void code_000054C2(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000054C5 */
static const char str_000054C5[] = "nVMM32.VXD is required to run Windows";


/* Code at 0x000054EA */
void code_000054EA(CPU_REGS *regs)
{
    regs->ax |= 0x490a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000054EE */
static const char str_000054EE[] = "f this file is not in your PATH, you may need to reinstall Windows";


/* Code at 0x00005530 */
void code_00005530(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005534 */
static const char str_00005534[] = "JHIMEM.SYS is inval";


/* Code at 0x00005547 */
void code_00005547(CPU_REGS *regs)
{
    regs->sp = MEM[regs->si + 0x2e] * 0xa0d;
}

/* String data at 0x0000554C */
static const char str_0000554C[] = "Install HIMEM.SYS from your Windows Setup disks.";


/* Code at 0x0000557C */
void code_0000557C(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x0000557F */
static const char str_0000557F[] = "OHIMEM.SYS is miss";


/* Code at 0x00005591 */
void code_00005591(CPU_REGS *regs)
{
    regs->bp = MEM[regs->bp + 0x67] * 0xd2e;
loc_00005596:
    regs->cl |= MEM[regs->di + 0x61]; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005599 */
static const char str_00005599[] = "ke sure that the file is in your Windows directory";


/* Code at 0x000055CB */
void code_000055CB(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000055CF */
static const char str_000055CF[] = "BThis version of Windows does not run on MS-DOS 7.00 or earl";


/* Code at 0x0000560B */
void code_0000560B(CPU_REGS *regs)
{
    regs->sp = MEM[regs->di + 0x72] * 0xd2e;
loc_00005610:
    regs->ah |= MEM[regs->si]; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005612 */
static const char str_00005612[] = "pInsufficientconventional memory to run Windows";


/* Code at 0x00005642 */
void code_00005642(CPU_REGS *regs)
{
    regs->ax |= 0x520a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005646 */
static const char str_00005646[] = "econfigure your system to have at least 335KB free memory";


/* Code at 0x0000567F */
void code_0000567F(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
    regs->bx++; UPDATE_FLAGS_INC();
    regs->ax |= 0x540a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005687 */
static const char str_00005687[] = "his version of Windows does not run in real or standard mo";


/* Code at 0x000056C1 */
void code_000056C1(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
loc_000056C7:
    PUSH(regs->ss);
    regs->ax |= 0x530a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000056CB */
static const char str_000056CB[] = "tarts Windows.";


/* Code at 0x000056D9 */
void code_000056D9(CPU_REGS *regs)
{
    regs->ax |= 0xd0a; UPDATE_FLAGS_LOGIC();
    regs->ah |= MEM[regs->si]; UPDATE_FLAGS_LOGIC();
    regs->ax -= 0x4957 + CF; UPDATE_FLAGS_SBB();
}

/* String data at 0x000056E1 */
static const char str_000056E1[] = "N [/D:[F][M][S][V][X]]";


/* Code at 0x000056F7 */
void code_000056F7(CPU_REGS *regs)
{
    regs->ax |= 0xd0a; UPDATE_FLAGS_LOGIC();
    regs->ah |= MEM[regs->si]; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000056FC */
static const char str_000056FC[] = "H/D    Used for troubleshooting when Windows does not start correctly.";


/* Code at 0x00005742 */
void code_00005742(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005745 */
static const char str_00005745[] = "k  :F  Turns off 32-bit disk access.";


/* Code at 0x00005769 */
void code_00005769(CPU_REGS *regs)
{
    regs->ax |= 0x200a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x0000576C */
static const char str_0000576C[] = "     Equivalent to SYSTEM.INI file setting: 32BitDiskAccess=FALSE";


/* Code at 0x000057AD */
void code_000057AD(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000057B1 */
static const char str_000057B1[] = "e  :M  Enables Safe mo";


/* Code at 0x000057C7 */
void code_000057C7(CPU_REGS *regs)
{
    regs->ax |= 0x200a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000057CD */
static const char str_000057CD[] = "     This is automatically enabled during Safe start (function key F5).";


/* Code at 0x00005814 */
void code_00005814(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005817 */
static const char str_00005817[] = "u  :N  Enables Safe mode with network";


/* Code at 0x0000583C */
void code_0000583C(CPU_REGS *regs)
{
    regs->bp = MEM[regs->bp + 0x67] * 0xd2e;
    regs->ah |= MEM[regs->bx + regs->si]; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005843 */
static const char str_00005843[] = "     This is automatically enabled during Safe start (function key F";


/* Code at 0x00005887 */
void code_00005887(CPU_REGS *regs)
{
    MEM[0xa0d] -= regs->bp; UPDATE_FLAGS_SUB();
}

/* String data at 0x0000588C */
static const char str_0000588C[] = "$H  :S  Specifies that Windows should not use ROM address space between";


/* Code block at 0x000058D3 */
void code_000058D3(CPU_REGS *regs)
{
loc_000058D3:
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000058D6 */
static const char str_000058D6[] = ".      F000:0000 and 1 MB for a break po";


/* Code at 0x000058FE */
void code_000058FE(CPU_REGS *regs)
{
    regs->bp = MEM[regs->bp + 0x74] * 0xd2e;
    regs->ah |= MEM[regs->si]; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005905 */
static const char str_00005905[] = "J      Equivalent to SYSTEM.INI file setting: SystemROMBreakPoint=FALSE";


/* Code at 0x0000594C */
void code_0000594C(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005950 */
static const char str_00005950[] = "L  :V  Specifies that the ROM routine will handle interrupts from the hard";


/* Code at 0x0000599A */
void code_0000599A(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
loc_0000599D:
    MEM[regs->bx + regs->si] -= regs->sp + CF; UPDATE_FLAGS_SBB();
}

/* String data at 0x0000599F */
static const char str_0000599F[] = "     disk controller.";


/* Code at 0x000059B4 */
void code_000059B4(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000059B7 */
static const char str_000059B7[] = "C      Equivalent to SYSTEM.INI file setting: VirtualHDIRQ=FALSE";


/* Code at 0x000059F7 */
void code_000059F7(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000059FB */
static const char str_000059FB[] = "O  :X  Excludes all of the adapter area from the range of memory that Window";


/* Code at 0x00005A47 */
void code_00005A47(CPU_REGS *regs)
{
    if (!CF) goto loc_00005A56;
    regs->ah |= MEM[regs->si]; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005A4B */
static const char str_00005A4B[] = "$      scans to find unused space.";


/* Code at 0x00005A6D */
void code_00005A6D(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005A70 */
static const char str_00005A70[] = "G      Equivalent to SYSTEM.INI file setting: EMMExclude=A000-FFFF";


/* Code at 0x00005AB2 */
void code_00005AB2(CPU_REGS *regs)
{
    regs->ax |= 0xd0a; UPDATE_FLAGS_LOGIC();
    regs->ah |= MEM[regs->si]; UPDATE_FLAGS_LOGIC();
    regs->cl = MEM[regs->di];
    regs->cl |= MEM[regs->bx + 0x6e]; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005ABD */
static const char str_00005ABD[] = "e or more of your disk drives may have developed bad sectors";


/* Code at 0x00005AF9 */
void code_00005AF9(CPU_REGS *regs)
{
    regs->ax |= 0x500a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005AFD */
static const char str_00005AFD[] = "ress any key to run ScanDisk with surface analysis on these drives.";


/* Code block at 0x00005B40 */
void code_00005B40(CPU_REGS *regs)
{
loc_00005B40:
    regs->al &= 0x90; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0x530a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005B47 */
static const char str_00005B47[] = "CANDISK.EXE could not be found. You may have problems on your disk(s) tha";


/* Code at 0x00005B90 */
void code_00005B90(CPU_REGS *regs)
{
    if (ZF) goto loc_00005B9F;
    regs->dh |= MEM[regs->bp + regs->si + 0x65]; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005B95 */
static const char str_00005B95[] = "quire repairing. Press any key to continue starting Windows.";


/* Code at 0x00005BD1 */
void code_00005BD1(CPU_REGS *regs)
{
    regs->al &= 0xb7; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0x540a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005BD8 */
static const char str_00005BD8[] = "here was an error running SCANDISK.EXE, or it was canceled. Run ScanD";


/* Code at 0x00005C1D */
void code_00005C1D(CPU_REGS *regs)
{
    regs->si = MEM[regs->bp + regs->di + 0x6b] * 0xa0d;
}

/* String data at 0x00005C22 */
static const char str_00005C22[] = "for Windows, as you may still have errors on your disk(s). Press any key to";


/* Code at 0x00005C6D */
void code_00005C6D(CPU_REGS *regs)
{
    regs->ax |= 0x630a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005C70 */
static const char str_00005C70[] = "ontinue starting Windows.";


/* Code at 0x00005C89 */
void code_00005C89(CPU_REGS *regs)
{
    regs->al &= 0x82; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005C8D */
static const char str_00005C8D[] = "You are already running Windows.";


/* Code at 0x00005CAD */
void code_00005CAD(CPU_REGS *regs)
{
    regs->ax |= 0xd0a; UPDATE_FLAGS_LOGIC();
loc_00005CB0:
    regs->bh |= regs->dh; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005CB2 */
static const char str_00005CB2[] = " Press ALT+ENTER to switch this MS-DOS prompt between";


/* Code at 0x00005CE7 */
void code_00005CE7(CPU_REGS *regs)
{
    regs->ax |= 0x200a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005CEA */
static const char str_00005CEA[] = " windowed and full-screen display.";


/* Code at 0x00005D0C */
void code_00005D0C(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
    XCHG(regs->ax, regs->cx);
    /* data: ['0xfe'] */
}

/* String data at 0x00005D11 */
static const char str_00005D11[] = " Type Exit and press Enter to quit this MS-DOS prompt an";


/* Code at 0x00005D49 */
void code_00005D49(CPU_REGS *regs)
{
    regs->ax |= 0x200a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005D4D */
static const char str_00005D4D[] = " return to Windows";


/* Code at 0x00005D5F */
void code_00005D5F(CPU_REGS *regs)
{
    regs->ax |= 0xfe0a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005D63 */
static const char str_00005D63[] = " Press ALT+TAB to switch to Windows or another application";


/* Code block at 0x00005D9D */
void code_00005D9D(CPU_REGS *regs)
{
loc_00005D9D:
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005DA1 */
static const char str_00005DA1[] = "1You are already running Standard mode Windows";


/* Code at 0x00005DCF */
void code_00005DCF(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005DD3 */
static const char str_00005DD3[] = "-You are already running Real mode Windows";


/* Code at 0x00005DFD */
void code_00005DFD(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005E01 */
static const char str_00005E01[] = "#You are already running Windows.";


/* Code at 0x00005E22 */
void code_00005E22(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
    regs->ax = 0x6854;
}

/* String data at 0x00005E28 */
static const char str_00005E28[] = "e MS-DOS Protected Mode Interface (DPMI) is running on this computer.";


/* Code at 0x00005E6D */
void code_00005E6D(CPU_REGS *regs)
{
    regs->ax |= 0x590a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005E70 */
static const char str_00005E70[] = "ou cannot start Windows when it is running.  To exit to your DPMI program";


/* Code at 0x00005EB9 */
void code_00005EB9(CPU_REGS *regs)
{
    regs->al -= 0xd; UPDATE_FLAGS_SUB();
    regs->dh |= MEM[regs->si + 0x79]; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005EBE */
static const char str_00005EBE[] = "pe Exit and then press Enter.";


/* Code at 0x00005EDB */
void code_00005EDB(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
loc_00005EDE:
    XCHG(regs->cl, MEM[regs->di]);
    regs->bl |= MEM[regs->bx + regs->di + 0x6f]; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005EE3 */
static const char str_00005EE3[] = "u are currently running in MS-DOS mode. Do you want to";


/* Code block at 0x00005F19 */
void code_00005F19(CPU_REGS *regs)
{
loc_00005F19:
    regs->ax |= 0x720a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005F1C */
static const char str_00005F1C[] = "eturn to normal mode, to run Windows applications again [Enter=Y,Esc=N]?$~";


/* Code at 0x00005F66 */
void code_00005F66(CPU_REGS *regs)
{
    regs->ax |= 0x590a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005F69 */
static const char str_00005F69[] = "ou are still running in MS-DOS mode. To return to normal";


/* Code at 0x00005FA1 */
void code_00005FA1(CPU_REGS *regs)
{
    regs->ax |= 0x6d0a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005FA4 */
static const char str_00005FA4[] = "ode, exit the application you are running, or type WIN aga";


/* Code at 0x00005FDE */
void code_00005FDE(CPU_REGS *regs)
{
    regs->bp = MEM[regs->bp + 0x2e] * 0xa0d;
    regs->al &= 0x1f; UPDATE_FLAGS_LOGIC();
    regs->ax |= 0x500a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00005FE8 */
static const char str_00005FE8[] = "ress any key to continue...$*Load all Windows drivers [Enter=Y,Esc=N]?";


/* Code at 0x0000602E */
void code_0000602E(CPU_REGS *regs)
{
    regs->al &= 0x80; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x00006030 */
static const char str_00006030[] = "Windows is still running one or more MSDOS-based programs.";


/* Code at 0x0000606A */
void code_0000606A(CPU_REGS *regs)
{
    regs->ax |= 0x590a; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x0000606D */
static const char str_0000606D[] = "ou need to exit your program(s) before Windows can be restart";


/* Code at 0x000060AA */
void code_000060AA(CPU_REGS *regs)
{
    regs->ax |= 0x240a; UPDATE_FLAGS_LOGIC();
    PUSH(regs->ds);
}

/* String data at 0x000060B1 */
static const char str_000060B1[] = "Internal structure overflo";


/* Code at 0x000060CB */
void code_000060CB(CPU_REGS *regs)
{
    if (!CF && !ZF) goto loc_000060DA;
    regs->ah |= MEM[regs->si]; UPDATE_FLAGS_LOGIC();
}

/* String data at 0x000060CF */
static const char str_000060D0[] = "ENUNS'";


/* Code at 0x000060D6 */
void code_000060D6(CPU_REGS *regs)
{
    /* data: ['0x11'] */
}

