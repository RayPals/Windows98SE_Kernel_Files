# Windows 95 Core Components — Assembly to C Reconstruction

## Overview

This package contains C source code reconstructed from annotated disassembly of six
core Windows 95 binary modules. The original ~885,000 lines of flat x86 assembly have
been converted to ~943,000 lines of structured C code with **99.7% conversion rate**.

## Files

| Source File     | Header File   | Original Binary  | Description                                    | Functions |
|----------------|---------------|------------------|------------------------------------------------|-----------|
| `win_com.c`    | `win_com.h`   | WIN.COM          | DOS startup loader — bootstraps Windows 95     | 69        |
| `io_sys.c`     | `io_sys.h`    | IO.SYS           | Boot loader & real-mode DOS kernel             | 983       |
| `krnl386.c`    | `krnl386.h`   | KRNL386.EXE      | 16-bit Windows kernel (memory, tasks, modules) | 1,021     |
| `gdi.c`        | `gdi.h`       | GDI.EXE          | 16-bit Graphics Device Interface               | 2,824     |
| `user.c`       | `user.h`      | USER.EXE         | 16-bit User Interface subsystem                | 5,413     |
| `vmm32.c`      | `vmm32.h`     | VMM32.VXD        | 32-bit Virtual Machine Manager (ring 0)        | 1,547     |
| `w95types.h`   | —             | —                | Common types, CPU model, macros, DOS/BIOS stubs| —         |

**Total: 11,857 functions identified and converted.**

## Architecture

### CPU Register Model (`w95types.h`)

The `CPU_REGS` struct models the full x86 register set with overlapping unions for
8/16/32-bit access (e.g., `regs->eax`, `regs->ax`, `regs->al`, `regs->ah`). All
converted functions take a `CPU_REGS *regs` parameter.

### Memory Model

A flat 16MB memory array (`g_memory[]`) with segment-to-linear translation macros:
- `MEM[addr]` — direct byte access
- `MEM_WORD(addr)` / `MEM_DWORD(addr)` — 16/32-bit access
- `FLAT(seg, off)` — segment:offset to linear address

### Interrupt Services

DOS and BIOS interrupt calls are converted to C function calls:
- `dos_int21(regs)` — DOS services (INT 21h)
- `bios_video_int(regs)` — BIOS video (INT 10h)
- `bios_disk_int(regs)` — BIOS disk (INT 13h)
- `dos_multiplex_int(regs)` — Multiplex (INT 2Fh)
- And others for INT 15h, 16h, 1Ah, 31h (DPMI), 33h (mouse), 67h (EMS)

### Control Flow

Assembly jumps are converted to C `goto` with address-based labels:
```c
CMP(regs->ax, 0x42);
if (ZF) goto loc_00000058;
```

Function calls use address-based names:
```c
func_0000011C(regs);  // call to code at offset 0x11C
```

### Data Sections

The converter detects and separates:
- **Zero-initialized data** → `static uint8_t data_XXXXXXXX[size] = {0};`
- **String data** → `static const char str_XXXXXXXX[] = "...";`
- **Raw data** → `static const uint8_t data_XXXXXXXX[] = {...};`

## Important Notes

1. **This is a mechanical reconstruction**, not a hand-written reimplementation. The
   original binaries were flat-disassembled without symbol information, so function
   names are address-based and data/code boundaries are heuristically detected.

2. **NE executable headers, relocation tables, and import tables** in the 16-bit
   modules (GDI, USER, KRNL386) are partially disassembled as code. The converter
   detects and marks these as data regions where possible.

3. **The 16-bit modules** (WIN.COM, IO.SYS, KRNL386, GDI, USER) use real-mode and
   16-bit protected-mode x86. The 32-bit module (VMM32.VXD) uses 32-bit protected
   mode at ring 0.

4. **FPU, SSE, and MMX instructions** are stubbed as macros. Implement the
   corresponding functions in `w95types.h` for actual floating-point support.

5. **2,672 instructions** (0.3%) that couldn't be converted are retained as C comments
   with their original disassembly for reference.

## Building

These files are structured C but use `goto`-based control flow and macro-based
CPU emulation. To compile, you need a C compiler supporting:
- Anonymous structs/unions (C11 or GCC extensions)
- `typeof` (GCC/Clang extension, or replace with explicit types)
- Variadic macros

```bash
# Example compilation check (won't link without implementing stubs)
gcc -c -std=gnu11 -Wall win_com.c -I.
gcc -c -std=gnu11 -Wall krnl386.c -I.
gcc -c -std=gnu11 -Wall gdi.c -I.
gcc -c -std=gnu11 -Wall user.c -I.
gcc -c -std=gnu11 -Wall io_sys.c -I.
gcc -c -std=gnu11 -Wall vmm32.c -I.
```
