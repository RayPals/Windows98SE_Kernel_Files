/*
 * Windows Startup Loader (WIN.COM)
 * DOS stub that loads Windows 95. Initializes environment, checks memory, and launches the Windows kernel.
 *
 * AUTO-GENERATED from annotated disassembly - not hand-written source.
 * This is a structural reconstruction from flat binary disassembly.
 */

#ifndef WIN_COM_H
#define WIN_COM_H

#include "w95types.h"

/* === Function Declarations (69 detected) === */

void func_0000011C(CPU_REGS *regs);
void func_00000134(CPU_REGS *regs);
void func_00000241(CPU_REGS *regs);
void func_00000272(CPU_REGS *regs);
void func_0000027A(CPU_REGS *regs);
void func_000002A1(CPU_REGS *regs);
void func_000002B8(CPU_REGS *regs);
void func_0000096E(CPU_REGS *regs);
void func_00000991(CPU_REGS *regs);
void func_000009A7(CPU_REGS *regs);
void func_000009AB(CPU_REGS *regs);
void func_000009B2(CPU_REGS *regs);
void func_000009C5(CPU_REGS *regs);
void func_000009E8(CPU_REGS *regs);
void func_0000108E(CPU_REGS *regs);
void func_000013D0(CPU_REGS *regs);
void func_00001474(CPU_REGS *regs);
void func_000016CB(CPU_REGS *regs);
void func_00001752(CPU_REGS *regs);
void func_000017B1(CPU_REGS *regs);
void func_00001808(CPU_REGS *regs);
void func_0000181A(CPU_REGS *regs);
void func_0000182B(CPU_REGS *regs);
void func_000018CE(CPU_REGS *regs);
void func_0000190B(CPU_REGS *regs);
void func_0000192A(CPU_REGS *regs);
void func_0000193F(CPU_REGS *regs);
void func_00001967(CPU_REGS *regs);
void func_0000198E(CPU_REGS *regs);
void func_000019A8(CPU_REGS *regs);
void func_000019E5(CPU_REGS *regs);
void func_00001A47(CPU_REGS *regs);
void func_00001AEF(CPU_REGS *regs);
void func_00001B33(CPU_REGS *regs);
void func_00001B65(CPU_REGS *regs);
void func_00001BE3(CPU_REGS *regs);
void func_00001C1F(CPU_REGS *regs);
void func_00001C67(CPU_REGS *regs);
void func_00001C78(CPU_REGS *regs);
void func_00001CE6(CPU_REGS *regs);
void func_00001D05(CPU_REGS *regs);
void func_00001D13(CPU_REGS *regs);
void func_00001D3A(CPU_REGS *regs);
void func_00001D85(CPU_REGS *regs);
void func_00001DA9(CPU_REGS *regs);
void func_00001E11(CPU_REGS *regs);
void func_00001ECB(CPU_REGS *regs);
void func_0000215B(CPU_REGS *regs);
void func_00002180(CPU_REGS *regs);
void func_00003BA0(CPU_REGS *regs);
void func_00003C4C(CPU_REGS *regs);
void func_00003CC9(CPU_REGS *regs);
void func_00003D0F(CPU_REGS *regs);
void func_00003D77(CPU_REGS *regs);
void func_00003D99(CPU_REGS *regs);
void func_00003DB2(CPU_REGS *regs);
void func_00003E37(CPU_REGS *regs);
void func_00003E69(CPU_REGS *regs);
void func_00003F17(CPU_REGS *regs);
void func_00003F38(CPU_REGS *regs);
void func_00003F57(CPU_REGS *regs);
void func_00003FBD(CPU_REGS *regs);
void func_0000407D(CPU_REGS *regs);
void func_00004099(CPU_REGS *regs);
void func_000041E1(CPU_REGS *regs);
void func_0000424C(CPU_REGS *regs);
void func_0000429A(CPU_REGS *regs);
void func_000042C2(CPU_REGS *regs);
void func_00004617(CPU_REGS *regs);
void func_00001A86(CPU_REGS *regs);
void func_00001F2D(CPU_REGS *regs);
void func_00003AE2(CPU_REGS *regs);
void func_0000BF03(CPU_REGS *regs);

#endif /* WIN_COM_H */
